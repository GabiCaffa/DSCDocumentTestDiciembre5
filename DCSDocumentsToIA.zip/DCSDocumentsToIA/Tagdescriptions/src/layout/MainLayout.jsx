// src/layout/MainLayout.jsx
import React, { Fragment } from 'react';
import HeaderMenu from './headerMenu';

const MainLayout = ({ children, sidebar = null, sidebarWidth = 300 }) => {
    const [isMobile, setIsMobile] = React.useState(window.innerWidth < 768);

    React.useEffect(() => {
        const handleResize = () => {
            setIsMobile(window.innerWidth < 768);
        };

        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    return (
        <Fragment>
            {/* Header/Sidebar izquierdo principal */}
            <HeaderMenu />

            <div
                style={{
                    display: 'flex',
                    marginLeft: isMobile ? '0' : '240px', // Espacio para headerMenu
                    marginTop: isMobile ? '70px' : '0',
                    minHeight: '100vh',
                    background: '#FFFFFF',
                }}
            >
                {/* Sidebar adicional (si existe) */}
                {sidebar && !isMobile && (
                    <div
                        style={{
                            width: `${sidebarWidth}px`,
                            background: '#FFFFFF',
                            borderRight: '1px solid #d1d3d4',
                            position: 'fixed',
                            left: '240px', // Después del headerMenu
                            top: 0,
                            bottom: 0,
                            height: '100vh',
                            overflow: 'auto',
                            zIndex: 10,
                        }}
                    >
                        {sidebar}
                    </div>
                )}

                {/* Contenido principal */}
                <div
                    style={{
                        flex: 1,
                        marginLeft: sidebar && !isMobile ? `${sidebarWidth}px` : '0',
                        padding: isMobile ? '20px' : '30px',
                        width: '100%',
                        maxWidth: '100%',
                        transition: 'margin 0.3s',
                    }}
                >
                    {children}
                </div>
            </div>
        </Fragment>
    );
};

export default MainLayout;