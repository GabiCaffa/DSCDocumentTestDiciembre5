//tagdescriptions/src/layout/headerMenu.jsx
import React, { useContext, useEffect, useState } from 'react';
import { Layout, Button, Space, Typography, Drawer } from 'antd';
import {
    SearchOutlined,
    LockOutlined,
    LogoutOutlined,
    UserOutlined,
    MenuOutlined,
    CloseOutlined,
} from '@ant-design/icons';
import authContext from '../context/auth/authContext';

const { Sider } = Layout;
const { Text, Title } = Typography;

const HeaderMenu = () => {
    const auContext = useContext(authContext);
    const { user, logOff } = auContext;
    const [showSearch, setShowSearch] = useState(false);
    const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
    const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

    useEffect(() => {
        const url = window.location.href;
        if (url) {
            const arrayURL = url.split('/');
            setShowSearch(arrayURL[arrayURL.length - 1] === 'tagsalldescriptors');
        }

        const handleResize = () => {
            setIsMobile(window.innerWidth < 768);
            if (window.innerWidth >= 768) {
                setMobileMenuOpen(false);
            }
        };

        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    const changePassword = () => {
        window.open("/changePassword", "_self");
        setMobileMenuOpen(false);
    };

    const search = () => {
        window.open('/tagsalldescriptors', '_self');
        setMobileMenuOpen(false);
    };

    const handleLogOff = () => {
        logOff();
        setMobileMenuOpen(false);
    };

    const MenuContent = () => (
        <>
            {/* Header */}
                <div 
                        style={{
                            padding: '24px 20px',
                            borderBottom: '1px solid #d1d3d4',
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                            gap: '8px'
                        }}
                                >
                        <img 
                            src="/mdplogo.png"
                            alt="logo"
                            style={{
                                width: '140px',
                                height: 'auto',
                                objectFit: 'contain'
                            }}
                                />

                        <Title 
                            level={5} 
                            style={{ 
                                color: '#006838', 
                                margin: 0, 
                                fontSize: '18px', 
                                fontWeight: 600,
                                textAlign: 'center'
                            }}
                        >
                            Sistema DCS    
                                </Title>

                </div>


            {/* Usuario */}
            {user && (
                <div style={{ padding: '20px', borderBottom: '1px solid #d1d3d4' }}>
                    <Space size="middle" align="center">
                        <UserOutlined style={{ fontSize: '24px', color: '#006838' }} />
                        <div>
                            <Text style={{ color: '#58595B', fontSize: '11px', display: 'block' }}>
                                Bienvenido
                            </Text>
                            <Text strong style={{ color: '#58595B', fontSize: '15px', display: 'block' }}>
                                {user.name.charAt(0).toUpperCase() + user.name.slice(1)}                           
                            </Text>
                             <Text strong style={{ color: '#58595B', fontSize: '13px' }}>
                                {user.rol.toUpperCase() === 'SYSADMIN' ? 'Admin' : 'Ingeniero'}                           
                            </Text>
                        </div>
                    </Space>
                </div>
            )}

            {/* Botones */}
            <div style={{ padding: '20px' }}>
                <Space direction="vertical" size="middle" style={{ width: '100%' }}>
                    
                    {/* Búsqueda Avanzada */}
                    {!showSearch && (
                        <Button
                            onClick={search}
                            block
                            style={{
                                height: '60px',
                                background: '#FFFFFF',
                                border: '1px solid #d1d3d4',
                                color: '#58595B',
                                display: 'flex',
                                flexDirection: 'column',
                                alignItems: 'center',
                                justifyContent: 'center',
                                gap: '6px',
                                padding: '12px',
                                transition: 'all 0.2s',
                                borderRadius: '8px',
                            }}
                            onMouseEnter={(e) => {
                                e.currentTarget.style.borderColor = '#006838';
                                e.currentTarget.style.boxShadow = '0 2px 8px rgba(0, 104, 56, 0.15)';
                                e.currentTarget.style.transform = 'translateY(-2px)';
                            }}
                            onMouseLeave={(e) => {
                                e.currentTarget.style.borderColor = '#d1d3d4';
                                e.currentTarget.style.boxShadow = 'none';
                                e.currentTarget.style.transform = 'translateY(0)';
                            }}
                        >
                            <SearchOutlined style={{ fontSize: '24px', color: '#006838' }} />
                            <span style={{ fontSize: '13px', fontWeight: 500, color: '#58595B' }}>Búsqueda Avanzada</span>
                        </Button>
                    )}

                    {/* Cambiar contraseña */}
                    {user && user.domain && user.domain !== "PRD" && (
                        <Button
                            onClick={changePassword}
                            block
                            style={{
                                height: '60px',
                                background: '#FFFFFF',
                                border: '1px solid #d1d3d4',
                                color: '#58595B',
                                display: 'flex',
                                flexDirection: 'column',
                                alignItems: 'center',
                                justifyContent: 'center',
                                gap: '6px',
                                padding: '12px',
                                transition: 'all 0.2s',
                                borderRadius: '8px',
                            }}
                            onMouseEnter={(e) => {
                                e.currentTarget.style.borderColor = '#006838';
                                e.currentTarget.style.boxShadow = '0 2px 8px rgba(0, 104, 56, 0.15)';
                                e.currentTarget.style.transform = 'translateY(-2px)';
                            }}
                            onMouseLeave={(e) => {
                                e.currentTarget.style.borderColor = '#d1d3d4';
                                e.currentTarget.style.boxShadow = 'none';
                                e.currentTarget.style.transform = 'translateY(0)';
                            }}
                        >
                            <LockOutlined style={{ fontSize: '24px', color: '#006838' }} />
                            <span style={{ fontSize: '13px', fontWeight: 500, color: '#58595B' }}>Cambiar contraseña</span>
                        </Button>
                    )}

                    {/* Cerrar Sesión */}
                    <Button
                        danger
                        onClick={handleLogOff}
                        block
                        style={{
                            height: '60px',
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                            justifyContent: 'center',
                            gap: '6px',
                            padding: '12px',
                            marginTop: '12px',
                            transition: 'all 0.2s',
                            borderRadius: '8px',
                            background: '#FFFFFF',
                            borderColor: '#c41e3a',
                            color: '#c41e3a',
                        }}
                        onMouseEnter={(e) => {
                            e.currentTarget.style.transform = 'translateY(-2px)';
                            e.currentTarget.style.boxShadow = '0 2px 8px rgba(196, 30, 58, 0.3)';
                            e.currentTarget.style.background = '#c41e3a';
                            e.currentTarget.style.color = '#FFFFFF';
                        }}
                        onMouseLeave={(e) => {
                            e.currentTarget.style.transform = 'translateY(0)';
                            e.currentTarget.style.boxShadow = 'none';
                            e.currentTarget.style.background = '#FFFFFF';
                            e.currentTarget.style.color = '#c41e3a';
                        }}
                    >
                        <LogoutOutlined style={{ fontSize: '24px' }} />
                        <span style={{ fontSize: '13px', fontWeight: 500 }}>Cerrar Sesión</span>
                    </Button>
                </Space>
            </div>
        </>
    );

    return (
        <>
            {/* Botón hamburguesa móvil */}
            {isMobile && (
                <Button
                    icon={mobileMenuOpen ? <CloseOutlined /> : <MenuOutlined />}
                    onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                    style={{
                        position: 'fixed',
                        top: '16px',
                        left: '16px',
                        zIndex: 1001,
                        width: '48px',
                        height: '48px',
                        background: '#FFFFFF',
                        border: '1px solid #006838',
                        color: '#006838',
                        borderRadius: '8px',
                    }}
                />
            )}

            {/* Sidebar desktop */}
            {!isMobile && (
                <Sider
                    width={240}
                    style={{
                        background: '#FFFFFF',
                        borderRight: '1px solid #d1d3d4',
                        position: 'fixed',
                        left: 0,
                        top: 0,
                        bottom: 0,
                        height: '100vh',
                        overflow: 'auto',
                    }}
                >
                    <MenuContent />
                </Sider>
            )}

            {/* Drawer móvil */}
            {isMobile && (
                <Drawer
                    placement="left"
                    open={mobileMenuOpen}
                    onClose={() => setMobileMenuOpen(false)}
                    closeIcon={<CloseOutlined style={{ color: '#58595B' }} />}
                    width={240}
                    styles={{
                        body: { padding: 0, background: '#FFFFFF' },
                        header: { background: '#FFFFFF', borderBottom: '1px solid #d1d3d4' },
                    }}
                >
                    <MenuContent />
                </Drawer>
            )}
        </>
    );
};

export default HeaderMenu;