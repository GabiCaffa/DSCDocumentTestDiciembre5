//tagdescriptions/src/layout/sidebarDevices.jsx
import React, {useContext, useEffect} from 'react';
import { Link } from 'react-router-dom'
import assetContext from '../context/asset/assetContext'
import { CSSTransition, TransitionGroup } from 'react-transition-group';
import Asset from '../components/assets/asset'



const SidebarDevices = () => {
    

    const aContext = useContext(assetContext)
    const {assets, getAssets} = aContext

    
    useEffect(() => {
        const initAssetTree = () =>{
            getAssets();
        }
        initAssetTree()
        // eslint-disable-next-line
    }, [])

    return ( 
        <aside style={{
            background: '#FFFFFF',
            borderRight: '1px solid #d1d3d4'
        }}>
            <h1 style={{ color: '#58595B' }}>
                Devices<span style={{ color: '#006838' }}>DCS</span>
            </h1>
           
            <div className="proyectos">
                
                <h2 style={{ color: '#58595B' }}>Assets</h2>  
                <ul className ="list-assets">
            
                    <TransitionGroup>
                        {assets.map(asset => (
                            <CSSTransition
                                key={asset._id}
                                timeout={200}
                                classNames="asset"
                            >
                                <Asset 
                                    asset={asset}
                                />
                            </CSSTransition>
                        ))}
                    </TransitionGroup>
                            
                                
                </ul>
            </div>  
            <div className="link-menu-div">
                <Link 
                    to={'/menu'}
                    className="link-menu"
                    style={{
                        color: '#006838',
                        transition: 'all 0.2s'
                    }}
                    onMouseEnter={(e) => {
                        e.currentTarget.style.color = '#008847';
                    }}
                    onMouseLeave={(e) => {
                        e.currentTarget.style.color = '#006838';
                    }}
                >
                &#60;
                    Menu
                </Link>
            </div>
        </aside>

     );
}
 
export default SidebarDevices;