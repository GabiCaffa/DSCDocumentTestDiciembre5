//tagdescriptions/src/layout/sidebarReportsSearch.jsx
import React, { useContext, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import assetContext from '../context/asset/assetContext';
import reportContext from '../context/report/reportContext';
import systemContext from '../context/system/systemContext';
import TreeMenu from 'react-simple-tree-menu';

const SidebarReportsSearch = () => {

    const aContext = useContext(assetContext);
    const { assetsTree, getAssetTree } = aContext;

    const rContext = useContext(reportContext);
    const { deselectReport } = rContext;

    const sContext = useContext(systemContext);
    const { selectSystem, deselectSystem } = sContext;

    const hasLoaded = useRef(false);

    useEffect(() => {
        if (!hasLoaded.current) {
            hasLoaded.current = true;
            getAssetTree();
        }
        // eslint-disable-next-line
    }, []);

    const selectSystemOnClick = (system) => {
        selectSystem(system);
        deselectReport();
    };

    return (
        <aside style={{
            background: '#FFFFFF',
            borderRight: '1px solid #d1d3d4'
        }}>
            <h1 style={{ color: '#58595B' }}>
                Reportes<span style={{ color: '#006838' }}>DCS</span>
            </h1>

            <div className="proyectos">
                <h2 style={{ color: '#58595B' }}>Assets</h2>
                <TreeMenu
                    data={assetsTree}
                    selected={false}
                    debounceTime={125}
                    disableKeyboard={true}
                    hasSearch={false}
                    onClickItem={({ _id, level, label }) => {
                        if (level === 1) {
                            let system = {
                                _id,
                                name: label,
                                active: true
                            };
                            selectSystemOnClick(system);
                        } else {
                            deselectSystem();
                        }
                    }}
                    resetOpenNodesOnDataUpdate={false}
                />
            </div>

            <div className="link-menu-div">
                <Link 
                    to={'/menu'}
                    className="link-menu"
                    style={{
                        color: '#006838',
                        transition: 'all 0.2s'
                    }}
                    onMouseEnter={(e) => {
                        e.currentTarget.style.color = '#008847';
                    }}
                    onMouseLeave={(e) => {
                        e.currentTarget.style.color = '#006838';
                    }}
                >
                    &#60; Menu
                </Link>
            </div>
        </aside>
    );
};

export default SidebarReportsSearch;