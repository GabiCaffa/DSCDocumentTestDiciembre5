//src/components/layout/Spinner.js
import React from 'react';

const Spinner = () => {
  return (
    <div style={{ 
      textAlign: 'center', 
      padding: '2rem',
      background: '#FFFFFF'
    }}>
      <div 
        className="spinner-border" 
        role="status"
        style={{
          width: '3rem',
          height: '3rem',
          border: '0.25rem solid rgba(0, 104, 56, 0.2)',
          borderRightColor: '#006838',
          borderRadius: '50%',
          display: 'inline-block',
          animation: 'spinner-border 0.75s linear infinite'
        }}
      >
        <span 
          className="visually-hidden"
          style={{
            position: 'absolute',
            width: '1px',
            height: '1px',
            padding: 0,
            margin: '-1px',
            overflow: 'hidden',
            clip: 'rect(0,0,0,0)',
            whiteSpace: 'nowrap',
            border: 0
          }}
        >
          Cargando...
        </span>
      </div>
      <style>{`
        @keyframes spinner-border {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};

export default Spinner;