// src/layout/sidebarDescriptorsSearch.jsx
import React, { useContext, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button, Typography } from 'antd';
import { ArrowLeftOutlined } from '@ant-design/icons';
import assetContext from '../context/asset/assetContext';
import TreeMenu from 'react-simple-tree-menu';
import tagDescriptorContext from '../context/tagdescriptor/tagDescriptorContext';
import systemContext from '../context/system/systemContext';
import 'react-simple-tree-menu/dist/main.css';

const { Title } = Typography;

const SidebarDescriptorsSearch = () => {
    const navigate = useNavigate();
    
    const aContext = useContext(assetContext);
    const { assetsTree, getAssetTree } = aContext;

    const tContext = useContext(tagDescriptorContext);
    const { deselectTagDescriptor } = tContext;

    const sContext = useContext(systemContext);
    const { selectSystem, deselectSystem } = sContext;

    const hasLoaded = useRef(false);
    
    useEffect(() => {
        if (!hasLoaded.current) {
            hasLoaded.current = true;
            getAssetTree();
        }
    }, []);

    const selectSystemOnClick = (system) => {
        selectSystem(system);
        deselectTagDescriptor();
    };

    return (
        <div style={{ 
            height: '100%', 
            display: 'flex', 
            flexDirection: 'column',
            background: '#FFFFFF'
        }}>
            {/* Header */}
            <div style={{ 
                padding: '20px', 
                borderBottom: '1px solid #d1d3d4' 
            }}>
                <Title level={5} style={{ 
                    color: '#006838', 
                    margin: 0, 
                    fontSize: '18px',
                    fontWeight: 600 
                }}>
                    Descriptores <span style={{ color: '#58595B' }}>DCS</span>
                </Title>
            </div>

            {/* Sección Assets */}
            <div style={{ 
                flex: 1, 
                padding: '20px',
                overflowY: 'auto'
            }}>
                <div style={{ 
                    marginBottom: '12px',
                    color: '#58595B',
                    fontSize: '14px',
                    fontWeight: 500
                }}>
                    Assets
                </div>

                {/* TreeMenu con estilos customizados */}
                <div className="custom-tree-menu">
                    <TreeMenu 
                        data={assetsTree} 
                        selected={false}
                        debounceTime={125}
                        disableKeyboard={true}
                        hasSearch={false}
                        onClickItem={({ _id, level, label }) => {
                            if (level === 1) {
                                let system = {
                                    _id,
                                    name: label,
                                    active: true
                                };
                                selectSystemOnClick(system);
                            } else {
                                deselectSystem();
                            }
                        }}
                        resetOpenNodesOnDataUpdate={false}    
                    />
                </div>
            </div>

            {/* Botón volver al menú */}
            <div style={{ 
                padding: '20px', 
                borderTop: '1px solid #d1d3d4' 
            }}>
                <Button
                    icon={<ArrowLeftOutlined />}
                    onClick={() => navigate('/menu')}
                    block
                    style={{
                        height: '42px',
                        background: '#FFFFFF',
                        border: '1px solid #d1d3d4',
                        color: '#58595B',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        gap: '8px',
                        transition: 'all 0.2s',
                        borderRadius: '8px',
                    }}
                    onMouseEnter={(e) => {
                        e.currentTarget.style.borderColor = '#006838';
                        e.currentTarget.style.color = '#006838';
                        e.currentTarget.style.transform = 'translateX(-4px)';
                    }}
                    onMouseLeave={(e) => {
                        e.currentTarget.style.borderColor = '#d1d3d4';
                        e.currentTarget.style.color = '#58595B';
                        e.currentTarget.style.transform = 'translateX(0)';
                    }}
                >
                    Volver al Menú
                </Button>
            </div>

            {/* Estilos CSS para el TreeMenu */}
            <style jsx>{`
                .custom-tree-menu {
                    color: #58595B;
                }

                /* Estilos para react-simple-tree-menu */
                :global(.rstm-tree-item) {
                    padding: 8px 12px;
                    cursor: pointer;
                    border-radius: 6px;
                    margin-bottom: 4px;
                    transition: all 0.2s;
                    color: #58595B;
                    font-size: 13px;
                }

                :global(.rstm-tree-item:hover) {
                    background: #f5f5f5;
                    border-left: 2px solid #006838;
                    padding-left: 10px;
                }

                :global(.rstm-tree-item--active) {
                    background: #f5f5f5;
                    border-left: 2px solid #006838;
                    padding-left: 10px;
                }

                :global(.rstm-tree-item-level0) {
                    font-weight: 600;
                    color: #006838;
                }

                :global(.rstm-tree-item-level1) {
                    color: #58595B;
                    padding-left: 24px;
                }

                :global(.rstm-toggle-icon) {
                    color: #006838;
                }

                :global(.rstm-toggle-icon-symbol) {
                    color: #006838;
                }
            `}</style>
        </div>
    );
};

export default SidebarDescriptorsSearch;