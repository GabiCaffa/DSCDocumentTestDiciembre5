// tagdescriptions/src/layout/menu.jsx
import React, { Fragment, useContext, useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Card } from 'antd';
import {
    DatabaseOutlined,
    TeamOutlined,
    TagsOutlined,
    GlobalOutlined,
    MobileOutlined,
    LinkOutlined,
    ApartmentOutlined,
    InboxOutlined,
    CreditCardOutlined,
    FileTextOutlined,
} from '@ant-design/icons';
import HeaderMenu from './headerMenu';
import authContext from '../context/auth/authContext';

const Menu = () => {
    const auContext = useContext(authContext);
    const { user } = auContext;
    const [isMobile, setIsMobile] = useState(window.innerWidth < 768);

    useEffect(() => {
        const handleResize = () => {
            setIsMobile(window.innerWidth < 768);
        };

        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    if (!user) return null;

    const MenuButton = ({ to, icon, title }) => (
        <Link to={to} style={{ textDecoration: 'none', height: '100%', display: 'block' }}>
            <Card
                hoverable
                style={{
                    background: '#FFFFFF',
                    border: '1px solid #d1d3d4',
                    height: '100%',
                    minHeight: '140px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    textAlign: 'center',
                    transition: 'all 0.2s',
                    boxShadow: '0 2px 8px rgba(0, 0, 0, 0.08)',
                    borderRadius: '8px',
                }}
                bodyStyle={{
                    padding: '24px',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    width: '100%',
                    height: '100%',
                }}
                onMouseEnter={(e) => {
                    e.currentTarget.style.boxShadow = '0 4px 16px rgba(0, 104, 56, 0.15)';
                    e.currentTarget.style.borderColor = '#006838';
                    e.currentTarget.style.transform = 'translateY(-4px)';
                }}
                onMouseLeave={(e) => {
                    e.currentTarget.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.08)';
                    e.currentTarget.style.borderColor = '#d1d3d4';
                    e.currentTarget.style.transform = 'translateY(0)';
                }}
            >
                <div style={{ fontSize: '40px', color: '#006838', marginBottom: '12px' }}>
                    {icon}
                </div>
                <div style={{ color: '#58595B', fontSize: '15px', fontWeight: 500 }}>
                    {title}
                </div>
            </Card>
        </Link>
    );

    // Array con todas las cards para renderizar dinámicamente
    const menuItems = [
        ...(user.rol === "SYSADMIN" ? [
            { key: 'assets', to: '/assets', icon: <DatabaseOutlined />, title: 'Estructura MdP' },
            { key: 'users', to: '/users', icon: <TeamOutlined />, title: 'Usuarios' },
        ] : []),
        { key: 'tagsdescriptors', to: '/tagsdescriptors', icon: <TagsOutlined />, title: 'Descriptores DCS' },
        { key: 'network', to: '/network', icon: <GlobalOutlined />, title: 'Network DCS' },
        { key: 'devices', to: '/devices', icon: <MobileOutlined />, title: 'Dispositivos DCS' },
        { key: 'connections', to: '/connections', icon: <LinkOutlined />, title: 'Conexiones' },
        { key: 'architecture', to: '/architecture', icon: <ApartmentOutlined />, title: 'Arquitectura Redes' },
        { key: 'cabinets', to: '/cabinets', icon: <InboxOutlined />, title: 'Gabinetes' },
        { key: 'iocards', to: '/iocards', icon: <CreditCardOutlined />, title: 'Tarjetas I/O' },
        { key: 'reports', to: '/reports', icon: <FileTextOutlined />, title: 'Reportes' },
    ];

    return (
        <Fragment>
            <HeaderMenu />

            <div
                style={{
                    marginLeft: isMobile ? '0' : '240px',
                    marginTop: isMobile ? '70px' : '0',
                    minHeight: '100vh',
                    background: '#FFFFFF',
                    padding: isMobile ? '20px' : '30px',
                }}
            >
                {/* Grid CSS nativo que ocupa todo el espacio */}
                <div
                    style={{
                        display: 'grid',
                        gridTemplateColumns: isMobile 
                            ? '1fr' 
                            : 'repeat(auto-fit, minmax(200px, 1fr))',
                        gap: '20px',
                        maxWidth: '100%',
                        height: isMobile ? 'auto' : 'calc(100vh - 60px)',
                        gridAutoRows: isMobile ? 'auto' : '1fr',
                    }}
                >
                    {menuItems.map((item) => (
                        <MenuButton
                            key={item.key}
                            to={item.to}
                            icon={item.icon}
                            title={item.title}
                        />
                    ))}
                </div>
            </div>
        </Fragment>
    );
};

export default Menu;