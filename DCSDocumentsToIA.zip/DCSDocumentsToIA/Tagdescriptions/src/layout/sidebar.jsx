//tagdescriptions/src/layout/sidebar.jsx
import React from 'react';
import AssetList from '../components/assets/assetList'
import AssetFrom from '../components/assets/assetFrom'
import { Link } from 'react-router-dom'


const Sidebar = () => {
    return ( 
        <aside style={{
            background: '#FFFFFF',
            borderRight: '1px solid #d1d3d4'
        }}>
            <h1 style={{ color: '#58595B' }}>
                Estructura<span style={{ color: '#006838' }}>MdP</span>
            </h1>
            <AssetFrom/>
            <div className="proyectos">
                
                <h2 style={{ color: '#58595B' }}>Assets</h2>  
                <AssetList/>
            </div>  
            <div className="link-menu-div">
                <Link 
                    to={'/menu'}
                    className="link-menu"
                    style={{
                        color: '#006838',
                        transition: 'all 0.2s'
                    }}
                    onMouseEnter={(e) => {
                        e.currentTarget.style.color = '#008847';
                    }}
                    onMouseLeave={(e) => {
                        e.currentTarget.style.color = '#006838';
                    }}
                >
                &#60;
                    Menu
                </Link>
            </div>
        </aside>

     );
}
 
export default Sidebar;