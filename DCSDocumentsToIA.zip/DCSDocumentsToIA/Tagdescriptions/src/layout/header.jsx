//tagdescriptions/src/layout/header.jsx
import React, { useContext, useEffect, useState } from 'react';
import authContext from '../context/auth/authContext'

const Header = () => {
    const auContext = useContext(authContext)
    const { user, getUser, logOff } = auContext;
    const [showSearch, setShowSearch] = useState(false)

  
    
    useEffect(() => {
        getUser()
        // eslint-disable-next-line
          //get current url 
        const url = window.location.href
        if(url){
            const arrayURL = url.split('/')
            setShowSearch(arrayURL[arrayURL.length-1]==='tagsalldescriptors')
        }
    }, [getUser])
    
    const search =()=>{
        window.open('/tagsalldescriptors', '_self') 
    }
    
    return (
        <header className="app-header" style={{
            background: '#FFFFFF',
            borderBottom: '1px solid #d1d3d4'
        }}>
            {user ? <p className="nombre-usuario" style={{ color: '#58595B' }}>Hola {' '}
                <span style={{ color: '#006838' }}>
                    {user.name}
                </span></p> : null}

            <nav className="nav-principal">
                {!showSearch &&
                    <button 
                        className = "btn btn-blank cerrar-sesion"
                        onClick={search}
                        style={{
                            color: '#006838',
                            transition: 'all 0.2s'
                        }}
                        onMouseEnter={(e) => {
                            e.currentTarget.style.color = '#008847';
                        }}
                        onMouseLeave={(e) => {
                            e.currentTarget.style.color = '#006838';
                        }}
                    >Búsqueda Avanzada</button>
                }
                <button
                    className="btn btn-blank cerrar-sesion"
                    onClick={logOff}
                    style={{
                        color: '#c41e3a',
                        transition: 'all 0.2s'
                    }}
                    onMouseEnter={(e) => {
                        e.currentTarget.style.color = '#d62e49';
                    }}
                    onMouseLeave={(e) => {
                        e.currentTarget.style.color = '#c41e3a';
                    }}
                >Cerrar Sesión</button>
            </nav>
        </header>
    );
}

export default Header;