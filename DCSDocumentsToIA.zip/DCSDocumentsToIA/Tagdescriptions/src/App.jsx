// src/App.jsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { TransitionGroup, CSSTransition } from 'react-transition-group';
import { ConfigProvider, theme } from 'antd'; 

import Login from './components/auth/login';
import Newuser from './components/users/newUser';
import Users from './components/users/users';
import Tagsdescriptors from './components/tagsdescriptors/tagsDescriptors';
import TagsAlldescriptors from './components/advanceSearch/tagsAllDescriptors';
import Network from './components/network/network';
import NetworkStatus from './components/network/networkStatus';
import ImportDevices from './components/files/importDevices';
import devices from './components/devices/devices';
import deviceStatus from './components/devices/deviceStatus';
import Reports from './components/reports/reports';
import ExecuteReport from './components/reports/executeReports';

import AlertState from './context/alerts/alertState';
import AuthState from './context/auth/authState';
import AssetState from './context/asset/assetState';
import SystemState from './context/system/systemState';
import NetworkState from './context/network/networkState';
import DeviceState from './context/devices/devicesState';
import ImportState from './context/import/importState';
import ConnectionState from './context/connection/connectionState';
import UserState from './context/user/userState';
import CabinetState from './context/cabinets/cabinetsState';
import IOCardState from './context/iocards/iocardsState';
import ReportState from './context/report/reportState';
import ChatAssistantState from './context/chatAssistant/chatAssistantState';
import TagDescriptorState from './context/tagdescriptor/tagDescriptorState';

import ChatAssistant from './components/chatAssistant/ChatAssistants';
import ConectionsC300 from './components/devices/ConnectionsC300';
import Menu from './layout/menu';
import Connections from './components/architecture/connections';
import Cabinets from './components/cabinets/Cabinets';
import CabinetStatus from './components/cabinets/CabinetStatus';
import IOCards from './components/iocards/IOCards';
import Eventlist from './components/alarmasyeventos/eventlist';
import Assets from './components/assets/assets';
import PrivateRoute from './components/routes/privateRoute';
import Diagram_Networking from './components/architecture/diagram_networking';
import Diagram_Devices from './components/architecture/diagram_devices';
import ChangePassword from './components/users/changePassword';

import authToken from './config/token';

import './transitions.css';

const token = localStorage.getItem('token');
authToken(token);

const SecondaryProviders = ({ children }) => (
  <AssetState>
    <SystemState>
      <TagDescriptorState>
        <CabinetState>
          <NetworkState>
            <ConnectionState>
              <DeviceState>
                <IOCardState>
                  <ImportState>
                    <UserState>
                      <ChatAssistantState>
                        <ReportState>
                          {children}
                        </ReportState>
                      </ChatAssistantState>
                    </UserState>
                  </ImportState>
                </IOCardState>
              </DeviceState>
            </ConnectionState>
          </NetworkState>
        </CabinetState>
      </TagDescriptorState>
    </SystemState>
  </AssetState>
);

const AnimatedRoutes = () => {
  const location = useLocation();

  return (
    <TransitionGroup component={null}>
      <CSSTransition
        key={location.pathname}
        timeout={400}
        classNames="page"
        unmountOnExit
      >
        <div className="page-wrapper">
          <Routes location={location}>
            <Route path="/" element={<Login />} />
            <Route path="/newuser" element={<Newuser />} />
            <Route path="/tagsdescriptors" element={<PrivateRoute><Tagsdescriptors /></PrivateRoute>} />
            <Route path="/tagsalldescriptors" element={<PrivateRoute><TagsAlldescriptors /></PrivateRoute>} />
            <Route path="/assets" element={<PrivateRoute><Assets /></PrivateRoute>} />
            <Route path="/menu" element={<PrivateRoute><Menu /></PrivateRoute>} />
            <Route path="/events" element={<PrivateRoute><Eventlist /></PrivateRoute>} />
            <Route path="/network" element={<PrivateRoute><Network /></PrivateRoute>} />
            <Route path="/networkstatus" element={<PrivateRoute><NetworkStatus /></PrivateRoute>} />
            <Route path="/devices" element={<PrivateRoute>{React.createElement(devices)}</PrivateRoute>} />
            <Route path="/devicestatus" element={<PrivateRoute>{React.createElement(deviceStatus)}</PrivateRoute>} />
            <Route path="/conections300/:idMongo" element={<PrivateRoute><ConectionsC300 /></PrivateRoute>} />
            <Route path="/importDevices" element={<PrivateRoute><ImportDevices /></PrivateRoute>} />
            <Route path="/architecture" element={<PrivateRoute><Diagram_Networking /></PrivateRoute>} />
            <Route path="/architectureDevices" element={<PrivateRoute><Diagram_Devices /></PrivateRoute>} />
            <Route path="/users" element={<PrivateRoute><Users /></PrivateRoute>} />
            <Route path="/changePassword" element={<PrivateRoute><ChangePassword /></PrivateRoute>} />
            <Route path="/connections" element={<PrivateRoute><Connections /></PrivateRoute>} />
            <Route path="/cabinets" element={<PrivateRoute><Cabinets /></PrivateRoute>} />
            <Route path="/cabinetStatus/:cabinetNameParam" element={<CabinetStatus />} />
            <Route path="/iocards" element={<PrivateRoute><IOCards /></PrivateRoute>} />
            <Route path="/reports" element={<PrivateRoute><Reports /></PrivateRoute>} />
            <Route path="/executeReports/:nameReport" element={<ExecuteReport />} />
          </Routes>
        </div>
      </CSSTransition>
    </TransitionGroup>
  );
};

function App() {
  return (
    <ConfigProvider
      theme={{
        algorithm: theme.darkAlgorithm, //  Activa el tema oscuro
        token: {
          // Colores principales para look industrial/corporativo
          colorPrimary: '#1890ff', // Azul corporativo
          colorBgBase: '#141414',  // Fondo negro principal
          colorBgContainer: '#1f1f1f', // Fondo de contenedores (cards, modals)
          colorBorder: '#434343', // Bordes
          borderRadius: 6, // Bordes redondeados sutiles
          fontSize: 14, // Tamaño de fuente base
        },
        components: {
          // Configuración específica para botones
          Button: {
            controlHeight: 40, // Altura de botones
            fontWeight: 500,
          },
          // Configuración para el layout
          Layout: {
            headerBg: '#1f1f1f',
            bodyBg: '#141414',
            siderBg: '#1f1f1f',
          },
        },
      }}
    >
      <AuthState>
        <AlertState>
          <Router>
            <SecondaryProviders>
              <AnimatedRoutes />
              <ChatAssistant />
            </SecondaryProviders>
          </Router>
        </AlertState>
      </AuthState>
    </ConfigProvider>
  );
}

export default App;