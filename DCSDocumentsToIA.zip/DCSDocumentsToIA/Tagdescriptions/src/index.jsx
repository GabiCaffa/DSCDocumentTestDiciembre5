import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import './index.css';

// Service workers no son necesarios con Vite, pero si los quieres mantener:
// import * as serviceWorker from './serviceWorker.jsx';

const root = createRoot(document.getElementById('root'));

root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

// Si quieres mantener service workers, descomenta esto:
// serviceWorker.unregister();