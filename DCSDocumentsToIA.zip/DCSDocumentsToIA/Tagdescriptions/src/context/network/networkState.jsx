//  src/context/network/networkState.js
import React, { useReducer, useMemo, useRef, useCallback } from 'react';
import networkContext from './networkContext';
import networkReducer from './networkReducer';
import {
    CREATE_NETWORK_NODE,
    SHOW_FORM_NETWORK,
    GET_NETWORK_NODES,
    GET_AREAS,
    SHOW_ERROR,
    UPDATE_NETWORK_NODE,
    DELETE_NETWORK_NODE,
    SELECT_NETWORK_NODE,
    GET_NETWORK_NODE,
    GET_NETWORK_MODELS,
    GET_NETWORK_MODEL,
    RESET_MESSAGE,
    CREATE_NETWORK_SHOW_RUN,
    GET_ARCHITECTURE_NODES,
    GET_ARCHITECTURE_DEVICES,
    GET_NETWORK_NODE_ID,
    DESELECT_NETWORK_NODE_ID
} from '../../types/index';

import axiosClient from '../../config/axios';

const NetworkState = props => {

    const initialState = {
        form: false,
        networkNodes: [],
        networkNodeSelected: null,
        message: null,
        networkNodeID: null,
        networkmodels: [],
        areas: [],
        networkmodel: null,
        urlDoc: null,
        architectureDevices: {},
        architectureNetworkNodes: []
    };

    const [state, dispatch] = useReducer(networkReducer, initialState);

    const cache = useRef({
        networkNodes: null,
        networkmodels: null,
        areas: null,
        lastFetchNodes: null,
        lastFetchModels: null,
        lastFetchAreas: null,
        asset: null
    });

    const fetchingNodes = useRef(null);
    const fetchingModels = useRef(false);
    const fetchingAreas = useRef(false);

    const showForm = useCallback(() => {
        dispatch({ type: SHOW_FORM_NETWORK });
    }, []);

    const createNetworkNode = useCallback(async (network_node) => {
        try {
            const res = await axiosClient.post('/api/network', network_node);
            
            // Invalidar caché
            cache.current.networkNodes = null;
            cache.current.lastFetchNodes = null;

            dispatch({
                type: CREATE_NETWORK_NODE,
                payload: res.data
            });
            getNetworkNodes(network_node.asset);
        } catch (error) {
            const alert = {
                msg: error.response.data.msg,
                category: 'alerta-error'
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        }
    }, []);

    const getNetworkNode = useCallback(async (idNetworkNode) => {
        try {
            const res = await axiosClient.get(`/api/network/${idNetworkNode}`);
            dispatch({
                type: GET_NETWORK_NODE,
                payload: res.data.network_get
            });
        } catch (error) {
            const alert = {
                msg: "hubo un error con el node de red",
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        }
    }, []);

    const resetMessage = useCallback(() => {
        dispatch({ type: RESET_MESSAGE });
    }, []);

    const getNetworkNodes = useCallback(async (asset, forceRefresh = false) => {
        if (!asset) return;

        const now = Date.now();
        const cacheValid = cache.current.lastFetchNodes && 
                          cache.current.asset === asset &&
                          (now - cache.current.lastFetchNodes < 5 * 60 * 1000);

        if (!forceRefresh && cacheValid && cache.current.networkNodes) {
            dispatch({
                type: GET_NETWORK_NODES,
                payload: cache.current.networkNodes
            });
            return;
        }

        if (fetchingNodes.current === asset) {
            return;
        }

        fetchingNodes.current = asset;

        try {
            const res = await axiosClient.get('/api/network', { params: { asset } });
            
            cache.current.networkNodes = res.data.networkNodes;
            cache.current.lastFetchNodes = now;
            cache.current.asset = asset;

            dispatch({
                type: GET_NETWORK_NODES,
                payload: res.data.networkNodes
            });
        } catch (error) {
            const alert = {
                msg: error.response.data.msg,
                category: 'alerta-error'
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        } finally {
            fetchingNodes.current = null;
        }
    }, []);

    const getNetworkNodesAll = useCallback(async () => {
        try {
            const res = await axiosClient.get('/api/network/all');
            dispatch({
                type: GET_NETWORK_NODES,
                payload: res.data.networkNodes
            });
        } catch (error) {
            const alert = {
                msg: error.response.data.msg,
                category: 'alerta-error'
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        }
    }, []);

    const showError = useCallback(() => {
        dispatch({ type: SHOW_ERROR });
    }, []);

    const getNetworkModels = useCallback(async (forceRefresh = false) => {
        const now = Date.now();
        const cacheValid = cache.current.lastFetchModels && 
                          (now - cache.current.lastFetchModels < 5 * 60 * 1000);

        if (!forceRefresh && cacheValid && cache.current.networkmodels) {
            dispatch({
                type: GET_NETWORK_MODELS,
                payload: cache.current.networkmodels
            });
            return;
        }

        if (fetchingModels.current) {
            return;
        }

        fetchingModels.current = true;

        try {
            const res = await axiosClient.get('/api/networkmodels');
            
            cache.current.networkmodels = res.data.networkNodeModels;
            cache.current.lastFetchModels = now;

            dispatch({
                type: GET_NETWORK_MODELS,
                payload: res.data.networkNodeModels
            });
        } catch (error) {
            const alert = {
                msg: error.response.data.msg,
                category: 'alerta-error'
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        } finally {
            fetchingModels.current = false;
        }
    }, []);

    const getAreas = useCallback(async (forceRefresh = false) => {
        const now = Date.now();
        const cacheValid = cache.current.lastFetchAreas && 
                          (now - cache.current.lastFetchAreas < 5 * 60 * 1000);

        if (!forceRefresh && cacheValid && cache.current.areas) {
            dispatch({
                type: GET_AREAS,
                payload: cache.current.areas
            });
            return;
        }

        if (fetchingAreas.current) {
            return;
        }

        fetchingAreas.current = true;

        try {
            const res = await axiosClient.get('/api/areas');
            
            cache.current.areas = res.data.areas;
            cache.current.lastFetchAreas = now;

            dispatch({
                type: GET_AREAS,
                payload: res.data.areas
            });
        } catch (error) {
            const alert = {
                msg: error.response.data.msg,
                category: 'alerta-error'
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        } finally {
            fetchingAreas.current = false;
        }
    }, []);

    const getNetworkModel = useCallback(async (idNetworkModel) => {
        try {
            const res = await axiosClient.get(`/api/networkmodels/${idNetworkModel}`);
            dispatch({
                type: GET_NETWORK_MODEL,
                payload: res.data.networkModel_get
            });
        } catch (error) {
            // Silencioso
        }
    }, []);

    const selectNetworkNode = useCallback((idNetworkNode) => {
        dispatch({
            type: SELECT_NETWORK_NODE,
            payload: idNetworkNode
        });
    }, []);

    const deleteNetworkNode = useCallback(async (idNetworkNode) => {
        try {
            await axiosClient.delete(`/api/network/${idNetworkNode}`);
            
            // Invalidar caché
            cache.current.networkNodes = null;
            cache.current.lastFetchNodes = null;

            dispatch({
                type: DELETE_NETWORK_NODE,
                payload: idNetworkNode
            });
        } catch (error) {
            const alert = {
                msg: "hubo un error eliminando el nodo de red",
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        }
    }, []);

    const updateNetworkNode = useCallback(async (network_node) => {
        try {
            const id = network_node._id;
            const res = await axiosClient.put(`/api/network/${id}`, network_node);
            
            // Invalidar caché
            cache.current.networkNodes = null;
            cache.current.lastFetchNodes = null;

            dispatch({
                type: UPDATE_NETWORK_NODE,
                payload: res.data.network_node_modified
            });
        } catch (error) {
            console.log(error);
        }
    }, []);

    const createNetworkNodeShowRun = useCallback(async (ip, tipo) => {
        const data = {
            ip: ip,
            tipo: tipo
        };

        try {
            const res = await axiosClient.get('/api/networkShow', { params: { data } });
            console.log(res);
            if (res.data.filename) {
                dispatch({
                    type: CREATE_NETWORK_SHOW_RUN,
                    payload: res.data.filename
                });
            }
        } catch (error) {
            console.log(error);
        }
    }, []);

    const getArchitectureDevices = useCallback(async (networkNode) => {
        try {
            const res = await axiosClient.get('/api/architecture/getArchitectureDevices', { params: { networkNode } });
            dispatch({
                type: GET_ARCHITECTURE_DEVICES,
                payload: res.data.accessArchitecture
            });
        } catch (error) {
            console.log(error);
        }
    }, []);

    const getArchitectureNetworkNodes = useCallback(async () => {
        try {
            const res = await axiosClient.get('/api/architecture/getArchitectureNodes');
            dispatch({
                type: GET_ARCHITECTURE_NODES,
                payload: res.data.coreArchitecture
            });
        } catch (error) {
            console.log(error);
        }
    }, []);

    const getNetworkNodeID = useCallback(async (networknode) => {
        try {
            const res = await axiosClient.get('/api/architecture/getNetworkNodeID', { params: { networknode } });
            dispatch({
                type: GET_NETWORK_NODE_ID,
                payload: res.data.idnetworknode
            });
        } catch (error) {
            const alert = {
                msg: "hubo un error con el nodo de red",
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        }
    }, []);

    const deselectNetworkNodeId = useCallback(() => {
        dispatch({ type: DESELECT_NETWORK_NODE_ID });
    }, []);

    const value = useMemo(
        () => ({
            form: state.form,
            networkNodes: state.networkNodes,
            networkNodeSelected: state.networkNodeSelected,
            error: state.error,
            networkmodels: state.networkmodels,
            networkmodel: state.networkmodel,
            urlDoc: state.urlDoc,
            areas: state.areas,
            architectureDevices: state.architectureDevices,
            architectureNetworkNodes: state.architectureNetworkNodes,
            networkNodeID: state.networkNodeID,
            showForm,
            createNetworkNode,
            getNetworkNodes,
            getNetworkNode,
            getNetworkNodesAll,
            updateNetworkNode,
            showError,
            selectNetworkNode,
            deleteNetworkNode,
            getNetworkModels,
            getNetworkModel,
            resetMessage,
            createNetworkNodeShowRun,
            getAreas,
            getArchitectureDevices,
            getArchitectureNetworkNodes,
            getNetworkNodeID,
            deselectNetworkNodeId
        }),
        [
            state,
            showForm,
            createNetworkNode,
            getNetworkNodes,
            getNetworkNode,
            getNetworkNodesAll,
            updateNetworkNode,
            showError,
            selectNetworkNode,
            deleteNetworkNode,
            getNetworkModels,
            getNetworkModel,
            resetMessage,
            createNetworkNodeShowRun,
            getAreas,
            getArchitectureDevices,
            getArchitectureNetworkNodes,
            getNetworkNodeID,
            deselectNetworkNodeId
        ]
    );

    return (
        <networkContext.Provider value={value}>
            {props.children}
        </networkContext.Provider>
    );
};

export default NetworkState;