// src/context/network/networkContext.js
import {createContext} from 'react'

const networkContext = createContext();

export default networkContext;