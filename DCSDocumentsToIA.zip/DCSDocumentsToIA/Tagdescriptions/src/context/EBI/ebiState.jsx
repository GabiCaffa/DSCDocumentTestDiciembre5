// tagdescriptions/src/context/EBI/ebiState.jsx
import React, { useReducer } from 'react';
import ebiReducer from './ebiReducer';
import EbiContext from './ebiContext';


import {
    GET_ALL_EVENTS,

} from '../../types/index'

import axiosClient from '../../config/axios'

const EbiState = ({ children }) => {

    const initialState = {
        events: [],
        message: null,
        areas: [],
        error: false
    }

    //Dispatch para ejecutar las acciones
    const [state, dispatch] = useReducer(ebiReducer, initialState)

    

    const getEvents = async () => {
        try {
            const result = await axiosClient.get('/api/EBIevents')

            dispatch({
                type: GET_ALL_EVENTS,
                payload: result.data.areas

            })
        } catch (error) {
            console.log(error)
        }
    }
    

    return (

        <EbiContext.Provider value={{
            events: state.events,
            form: state.form,
            message: state.message,
            areas: state.areas,
            error: state.error,
            getEvents,
        }}>
            {children}
        </EbiContext.Provider>
    )
}

export default EbiState;