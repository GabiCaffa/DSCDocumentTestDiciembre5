import {
    GET_ALL_EVENTS,
    
} from '../../types';


export default (state, action) => {
    switch (action.type) {
        
        case GET_ALL_EVENTS:
            return {
                ...state,
                events: action.payload,
                error: false,
                message: null
            }
        
        default:
            return state;
    }
}// Compare this snippet from src\context\network\networkContext.js: