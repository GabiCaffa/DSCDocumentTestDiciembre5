import { createContext } from "react";

const EbiContext = createContext();

export default EbiContext;