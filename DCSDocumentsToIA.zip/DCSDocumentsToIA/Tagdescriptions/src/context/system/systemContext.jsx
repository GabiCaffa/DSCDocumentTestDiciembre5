import {createContext} from 'react'

const systemContext = createContext();

export default systemContext;