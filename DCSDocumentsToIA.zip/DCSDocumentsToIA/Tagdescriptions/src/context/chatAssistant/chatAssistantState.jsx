// tagdescriptions/src/context/chatAssistant/chatAssistantState.jsx
import React, { useReducer, useCallback } from 'react';
import ChatAssistantContext from './chatAssistantContext';
import chatAssistantReducer from './chatAssistantReducer';
import axiosClient from '../../config/axios';
import {
  ADD_MESSAGE,
  CLEAR_MESSAGES,
  SET_LOADING,
  SET_SERVER_STATUS,
  TOGGLE_CHAT,
  SET_NAVIGATION
} from '../../types/index';

const ChatAssistantState = ({ children }) => {
  const initialState = {
    messages: [
      {
        role: 'assistant',
        content: '¡Hola! Soy tu asistente virtual. ¿En qué puedo ayudarte hoy?',
        timestamp: new Date()
      }
    ],
    loading: false,
    serverStatus: 'online',
    isOpen: false,
    navigationPath: null
  };

  const [state, dispatch] = useReducer(chatAssistantReducer, initialState);

  const checkHealth = useCallback(async () => {
    dispatch({
      type: SET_SERVER_STATUS,
      payload: 'online'
    });
  }, []);

  const sendMessage = useCallback(async (message) => {
    if (!message || message.trim() === '') {
      return { success: false, error: 'El mensaje no puede estar vacío' };
    }

    const userMessage = { 
      role: 'user', 
      content: message,
      timestamp: new Date()
    };
    
    dispatch({
      type: ADD_MESSAGE,
      payload: userMessage
    });

    dispatch({
      type: SET_LOADING,
      payload: true
    });

    try {
      const conversationHistory = state.messages.map(msg => ({
        role: msg.role,
        content: msg.content
      }));

      const response = await axiosClient.post('/api/assistant/chat', {
        message,
        conversationHistory
      });

      if (response.data.success) {
        dispatch({
          type: ADD_MESSAGE,
          payload: {
            role: 'assistant',
            content: response.data.response,
            timestamp: new Date()
          }
        });
        
        // Guardar el path de navegación en el estado
        if (response.data.navigation) {
          console.log('[CHAT] Path de navegación recibido:', response.data.navigation.path);
          dispatch({
            type: SET_NAVIGATION,
            payload: response.data.navigation.path
          });
        }
        
        return { success: true };
      } else {
        throw new Error(response.data.message || 'Error en la respuesta');
      }
    } catch (error) {
      console.error('Error al enviar mensaje:', error);
      
      const errorMessage = error.response?.data?.message 
        || error.message 
        || 'No se pudo conectar con el servidor';
      
      dispatch({
        type: ADD_MESSAGE,
        payload: {
          role: 'assistant',
          content: `Lo siento, ocurrió un error: ${errorMessage}. Por favor intenta nuevamente.`,
          timestamp: new Date(),
          isError: true
        }
      });
      
      if (error.response?.status === 429) {
        dispatch({
          type: SET_SERVER_STATUS,
          payload: 'rate_limited'
        });
      }
      
      return { success: false, error: errorMessage };
    } finally {
      dispatch({
        type: SET_LOADING,
        payload: false
      });
    }
  }, [state.messages]);

  const clearMessages = useCallback(() => {
    dispatch({
      type: CLEAR_MESSAGES
    });
    
    setTimeout(() => {
      dispatch({
        type: ADD_MESSAGE,
        payload: {
          role: 'assistant',
          content: '¡Hola! Soy tu asistente virtual. ¿En qué puedo ayudarte hoy?',
          timestamp: new Date()
        }
      });
    }, 100);
  }, []);

  const toggleChat = useCallback((value) => {
    dispatch({
      type: TOGGLE_CHAT,
      payload: value
    });
  }, []);

  const clearNavigationPath = useCallback(() => {
    dispatch({
      type: SET_NAVIGATION,
      payload: null
    });
  }, []);

  return (
    <ChatAssistantContext.Provider
      value={{
        messages: state.messages,
        loading: state.loading,
        serverStatus: state.serverStatus,
        isOpen: state.isOpen,
        navigationPath: state.navigationPath,
        checkHealth,
        sendMessage,
        clearMessages,
        toggleChat,
        clearNavigationPath
      }}
    >
      {children}
    </ChatAssistantContext.Provider>
  );
};

export default ChatAssistantState;