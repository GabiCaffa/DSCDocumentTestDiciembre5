import {
  SET_MESSAGES,
  ADD_MESSAGE,
  CLEAR_MESSAGES,
  SET_LOADING,
  SET_SERVER_STATUS,
  TOGGLE_CHAT,
  SET_NAVIGATION
} from '../../types/index';

const chatAssistantReducer = (state, action) => {
  switch (action.type) {
    case SET_MESSAGES:
      return {
        ...state,
        messages: action.payload
      };
    
    case ADD_MESSAGE:
      return {
        ...state,
        messages: [...state.messages, action.payload]
      };
    
    case CLEAR_MESSAGES:
      return {
        ...state,
        messages: []
      };
    
    case SET_LOADING:
      return {
        ...state,
        loading: action.payload
      };
    
    case SET_SERVER_STATUS:
      return {
        ...state,
        serverStatus: action.payload
      };
    
    case TOGGLE_CHAT:
      return {
        ...state,
        isOpen: action.payload !== undefined ? action.payload : !state.isOpen
      };
    
    case SET_NAVIGATION:
      return {
        ...state,
        navigationPath: action.payload
      };
    
    default:
      return state;
  }
};

export default chatAssistantReducer;