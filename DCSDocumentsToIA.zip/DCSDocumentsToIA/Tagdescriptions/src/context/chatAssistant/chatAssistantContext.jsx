// chatAssistantContext.js
import { createContext } from 'react';

const ChatAssistantContext = createContext();

export default ChatAssistantContext;