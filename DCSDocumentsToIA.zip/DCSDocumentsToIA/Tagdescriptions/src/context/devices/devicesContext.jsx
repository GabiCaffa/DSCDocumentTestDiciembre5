import {createContext} from 'react'

const devicesContext = createContext();

export default devicesContext;