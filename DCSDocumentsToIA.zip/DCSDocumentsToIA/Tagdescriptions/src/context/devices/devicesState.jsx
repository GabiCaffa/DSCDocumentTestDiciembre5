// tagdescriptions/src/context/devices/devicesState.jsx
import React, { useReducer, useMemo, useRef, useCallback } from 'react';
import devicesContext from './devicesContext';
import devicesReducer from './devicesReducer';
import {
    CREATE_DEVICE,
    SHOW_FORM_DEVICE, 
    GET_DEVICES,
    SHOW_ERROR,
    UPDATE_DEVICE,
    DELETE_DEVICE,
    SELECT_DEVICE,
    GET_DEVICE,
    GET_DEVICE_TYPES,
    GET_DEVICE_TYPE,
    RESET_MESSAGE,
    GET_DEVICE_STATUS,
    SEARCH_DEVICE,
    GET_DEVICE_NODE_ID,
    DESELECT_DEVICE_NODE_ID
} from '../../types/index';

import axiosClient from '../../config/axios';

const DevicesState = props => {
    
    const initialState = {
        form: false,
        devices: [],
        devicesSearch: [],
        deviceSelected: null,
        message: null,
        devicetypes: [],
        devicetype: null,
        error: false,
        status: {}
    };

    const [state, dispatch] = useReducer(devicesReducer, initialState);

    const cache = useRef({
        devices: null,
        devicetypes: null,
        lastFetchDevices: null,
        lastFetchTypes: null,
        asset: null
    });

    const fetchingDevices = useRef(null);
    const fetchingTypes = useRef(false);

    const showForm = useCallback(() => {
        dispatch({ type: SHOW_FORM_DEVICE });
    }, []);

    const createDevice = useCallback(async (device) => {
        try {
            const res = await axiosClient.post('/api/devices', device);
            
            // Invalidar caché
            cache.current.devices = null;
            cache.current.lastFetchDevices = null;

            dispatch({
                type: CREATE_DEVICE,
                payload: res.data
            });
            getDevices(device.asset);
        } catch (error) {
            const alert = {
                msg: error.response.data.msg,
                category: 'alerta-error'
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        }
    }, []);

    const getDevice = useCallback(async (idDevice) => {
        try {
            const res = await axiosClient.get(`/api/devices/${idDevice}`);
            dispatch({
                type: GET_DEVICE,
                payload: res.data.device_get
            });
        } catch (error) {
            const alert = {
                msg: "hubo un error con el nodo de red",
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        }
    }, []);

    const resetMessage = useCallback(() => {
        dispatch({ type: RESET_MESSAGE });
    }, []);

    const getDevices = useCallback(async (asset, forceRefresh = false) => {
        if (!asset) return;

        const now = Date.now();
        const cacheValid = cache.current.lastFetchDevices && 
                          cache.current.asset === asset &&
                          (now - cache.current.lastFetchDevices < 5 * 60 * 1000);

        if (!forceRefresh && cacheValid && cache.current.devices) {
            dispatch({
                type: GET_DEVICES,
                payload: cache.current.devices
            });
            return;
        }

        if (fetchingDevices.current === asset) {
            return;
        }

        fetchingDevices.current = asset;

        try {
            const res = await axiosClient.get('/api/devices', { params: { asset } });
            
            cache.current.devices = res.data.devices;
            cache.current.lastFetchDevices = now;
            cache.current.asset = asset;

            dispatch({
                type: GET_DEVICES,
                payload: res.data.devices
            });
        } catch (error) {
            const alert = {
                msg: error.response.data.msg,
                category: 'alerta-error'
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        } finally {
            fetchingDevices.current = null;
        }
    }, []);

    const getDevicesAll = useCallback(async () => {
        try {
            const res = await axiosClient.get('/api/devices/all');
            dispatch({
                type: GET_DEVICES,
                payload: res.data.devices
            });
        } catch (error) {
            const alert = {
                msg: error.response.data.msg,
                category: 'alerta-error'
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        }
    }, []);

    const showError = useCallback(() => {
        dispatch({ type: SHOW_ERROR });
    }, []);

    const getDeviceTypes = useCallback(async (forceRefresh = false) => {
        const now = Date.now();
        const cacheValid = cache.current.lastFetchTypes && 
                          (now - cache.current.lastFetchTypes < 5 * 60 * 1000);

        if (!forceRefresh && cacheValid && cache.current.devicetypes) {
            dispatch({
                type: GET_DEVICE_TYPES,
                payload: cache.current.devicetypes
            });
            return;
        }

        if (fetchingTypes.current) {
            return;
        }

        fetchingTypes.current = true;

        try {
            const res = await axiosClient.get('/api/devicestypes');
            
            cache.current.devicetypes = res.data.deviceTypes;
            cache.current.lastFetchTypes = now;

            dispatch({
                type: GET_DEVICE_TYPES,
                payload: res.data.deviceTypes
            });
        } catch (error) {
            const alert = {
                msg: error.response.data.msg,
                category: 'alerta-error'
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        } finally {
            fetchingTypes.current = false;
        }
    }, []);

    const getDeviceType = useCallback(async (idDevice) => {
        try {
            const res = await axiosClient.get(`/api/devicestypes/${idDevice}`);
            dispatch({
                type: GET_DEVICE_TYPE,
                payload: res.data.device_type
            });
        } catch (error) {
            // Silencioso
        }
    }, []);

    const selectDevice = useCallback((idDevice) => {
        dispatch({
            type: SELECT_DEVICE,
            payload: idDevice
        });
    }, []);

    const deleteDevice = useCallback(async (idDevice) => {
        try {
            await axiosClient.delete(`/api/devices/${idDevice}`);
            
            // Invalidar caché
            cache.current.devices = null;
            cache.current.lastFetchDevices = null;

            dispatch({
                type: DELETE_DEVICE,
                payload: idDevice
            });
        } catch (error) {
            const alert = {
                msg: "hubo un error eliminando el nodo de red",
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        }
    }, []);

    const getDeviceStatus = useCallback(async (idDevice) => {
        try {
            const res = await axiosClient.get(`/api/devices/status/${idDevice}`);
            dispatch({
                type: GET_DEVICE_STATUS,
                payload: res.data
            });
        } catch (error) {
            console.log(error);
        }
    }, []);

    const updateDevice = useCallback(async (device) => {
        try {
            const id = device._id;
            const res = await axiosClient.put(`/api/devices/${id}`, device);
            
            // Invalidar caché
            cache.current.devices = null;
            cache.current.lastFetchDevices = null;

            dispatch({
                type: UPDATE_DEVICE,
                payload: res.data.deviceUpdate
            });
        } catch (error) {
            console.log(error);
        }
    }, []);

    const searchDevices = useCallback((text) => {
        dispatch({
            type: SEARCH_DEVICE,
            payload: text
        });
    }, []);

    const getDeviceID = useCallback(async (deviceName) => {
        try {
            const res = await axiosClient.get('/api/architecture/getDeviceID', { params: { deviceName } });
            dispatch({
                type: GET_DEVICE_NODE_ID,
                payload: res.data.idDevice
            });
        } catch (error) {
            const alert = {
                msg: "hubo un error con el device",
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        }
    }, []);

    const deselectDeviceId = useCallback(() => {
        dispatch({ type: DESELECT_DEVICE_NODE_ID });
    }, []);

    const value = useMemo(
        () => ({
            form: state.form,
            devices: state.devices,
            deviceSelected: state.deviceSelected,
            error: state.error,
            devicetypes: state.devicetypes,
            devicetype: state.devicetype,
            status: state.status,
            devicesSearch: state.devicesSearch,
            deviceID: state.deviceID,
            showForm, 
            createDevice,
            getDevices,
            getDevicesAll,
            getDevice,
            updateDevice,
            showError,
            selectDevice,
            deleteDevice,
            getDeviceTypes,
            getDeviceType,
            resetMessage,
            getDeviceStatus,
            searchDevices,
            getDeviceID,
            deselectDeviceId
        }),
        [
            state,
            showForm,
            createDevice,
            getDevices,
            getDevicesAll,
            getDevice,
            updateDevice,
            showError,
            selectDevice,
            deleteDevice,
            getDeviceTypes,
            getDeviceType,
            resetMessage,
            getDeviceStatus,
            searchDevices,
            getDeviceID,
            deselectDeviceId
        ]
    );

    return (
        <devicesContext.Provider value={value}>
            {props.children}
        </devicesContext.Provider>
    );
};

export default DevicesState;