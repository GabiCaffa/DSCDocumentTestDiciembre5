// tagdescriptions/src/context/alerts/alertState.jsx
import React, { useReducer, useMemo, useCallback } from 'react';
import alertReducer from './alertReducer';
import alertContext from './alertContext';
import { SHOW_ALERT, HIDE_ALERT } from '../../types';

const AlertState = (props) => {
    const initialState = {
        alert: null
    };
    
    const [state, dispatch] = useReducer(alertReducer, initialState);

    const showAlert = useCallback((msg, category) => {
        dispatch({
            type: SHOW_ALERT,
            payload: {
                msg: msg,
                category: category
            }
        });

        setTimeout(() => {
            dispatch({
                type: HIDE_ALERT
            });
        }, 5000);
    }, []);

    const value = useMemo(
        () => ({
            alert: state.alert,
            showAlert
        }),
        [state.alert, showAlert]
    );

    return (
        <alertContext.Provider value={value}>
            {props.children}
        </alertContext.Provider>
    );
};

export default AlertState;