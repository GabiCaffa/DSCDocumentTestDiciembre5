//tagdescriptions/src/context/auth/authContext.jsx
import {createContext} from 'react'

const authContext = createContext();

export default authContext;