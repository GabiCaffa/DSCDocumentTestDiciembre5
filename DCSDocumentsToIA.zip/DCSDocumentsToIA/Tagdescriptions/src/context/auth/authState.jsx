// tagdescriptions/src/context/auth/authState.jsx
import React, { useReducer, useEffect, useRef, useMemo, useCallback } from 'react';import authContext from './authContext';
import authReducer from './authReducer';
import axiosClient from '../../config/axios';
import tokenAuth from '../../config/token';

import {
    CREATE_USER_SUCCESS,
    CREATE_USER_ERROR,
    GET_USER, 
    LOGIN_SUCCESS,
    LOGIN_ERROR,
    LOG_OFF,
    RESET_MESSAGE
} from '../../types/index';

const AuthState = (props) => {
    const initialState = {
        token: localStorage.getItem('token'),
        authenticated: null,
        user_is_created: null,
        user: null,
        message: null,
        loading: true
    };

    const [state, dispatch] = useReducer(authReducer, initialState);
    
    //  Control estricto de ejecución
    const hasVerified = useRef(false);
    const isFetching = useRef(false);
    const verificationPromise = useRef(null);

    //  Memoizar getUser con useCallback
    const getUser = useCallback(async () => {
        // Si ya hay una verificación en progreso, retornar esa promesa
        if (verificationPromise.current) {
            return verificationPromise.current;
        }

        // Si ya se verificó, no volver a verificar
        if (hasVerified.current && state.authenticated !== null) {
            return;
        }

        const token = localStorage.getItem('token');
        
        if (!token) {
            hasVerified.current = true;
            dispatch({ type: LOGIN_ERROR });
            return;
        }
        
        // Crear promesa de verificación
        verificationPromise.current = (async () => {
            isFetching.current = true;
            tokenAuth(token);
            
            try {
                const res = await axiosClient.get('/api/auth');
                hasVerified.current = true;
                dispatch({
                    type: GET_USER,
                    payload: res.data.user
                });
            } catch (error) {
                console.log('Error al verificar usuario:', error.response?.data || error.message);
                localStorage.removeItem('token');
                hasVerified.current = true;
                dispatch({ type: LOGIN_ERROR });
            } finally {
                isFetching.current = false;
                verificationPromise.current = null;
            }
        })();

        return verificationPromise.current;
    }, [state.authenticated]);

    useEffect(() => {
        // Solo ejecutar UNA VEZ al montar
        if (!hasVerified.current && !verificationPromise.current) {
            getUser();
        }
    }, []); //  Dependencias vacías - SOLO al montar

    const createUser = useCallback(async (user) => {
        try {
            const res = await axiosClient.post('api/users', user);
            dispatch({
                type: CREATE_USER_SUCCESS,
                payload: res.data
            });
        } catch (error) {
            console.log(error);
            const alert = {
                msg: error.response.data.msg,
                category: 'alerta-error'
            };
            dispatch({
                type: CREATE_USER_ERROR,
                payload: alert
            });
        }
    }, []);

    const logOff = useCallback(() => {
        hasVerified.current = false;
        verificationPromise.current = null;
        dispatch({ type: LOG_OFF });
    }, []);

    const loginUser = useCallback(async (user) => {
        try {
            const res = await axiosClient.post('/api/auth', user);
            
            dispatch({
                type: LOGIN_SUCCESS,
                payload: res.data
            });

            tokenAuth(res.data.token);
            
            // Resetear flags para nueva verificación
            hasVerified.current = false;
            verificationPromise.current = null;
            
            const userRes = await axiosClient.get('/api/auth');
            hasVerified.current = true;
            dispatch({
                type: GET_USER,
                payload: userRes.data.user
            });
            
        } catch (error) {
            console.log('Error en login:', error.response?.data || error.message);
            const alert = {
                msg: error.response?.data?.msg || 'Error al iniciar sesión',
                category: 'alerta-error'
            };
            dispatch({
                type: LOGIN_ERROR,
                payload: alert
            });
        }
    }, []);
    
    const resetMessage = useCallback(() => {
        dispatch({ type: RESET_MESSAGE });
    }, []);

    //  Memoizar el valor del contexto
    const value = useMemo(
        () => ({
            token: state.token,
            authenticated: state.authenticated,
            user: state.user,
            message: state.message,
            loading: state.loading,
            user_is_created: state.user_is_created,
            createUser,
            loginUser,
            getUser,
            logOff,
            resetMessage
        }),
        [state, createUser, loginUser, getUser, logOff, resetMessage]
    );

    return (
        <authContext.Provider value={value}>
            {props.children}
        </authContext.Provider>
    );
};

export default AuthState;