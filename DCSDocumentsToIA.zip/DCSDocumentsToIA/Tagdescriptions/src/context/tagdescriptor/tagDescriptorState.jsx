//tagdescriptions/src/context/tagdescriptor/tagDescriptorState.jsx
import React, { useReducer, useMemo, useRef, useCallback } from 'react';import tagDescriptorContext from './tagDescriptorContext';
import tagDescriptorReducer from './tagDescriptorReducer';
import {
    FORM_TAGDESCRIPTOR, 
    GET_TAGDESCRIPTOR,
    CREATE_TAGDESCRIPTOR,
    SHOW_ERROR_TAGDESCRIPTOR,
    UPDATE_TAGDESCRIPTOR,
    SELECT_TAGDESCRIPTOR,
    DESELECT_TAGDESCRIPTOR,
    GET_TAGSDESCRIPTORS,
    GET_ALL_TAGDESCRIPTORS,
    DELETE_TAGDESCRIPTOR,
    SEARCH_TAGSDESCRIPTORS,
    RESET_MESSAGE,
    VALIDATE_TAGDESCRIPTOR,
    INVALIDATE_TAGDESCRIPTOR,
    CREATE_DOCUMENT,
    GET_TAGSDESCRIPTORS_RELATED,
    SELECT_ONLY_DESCRIPTOR,
    GET_INTERLOCKS,
    GET_AYE,
    GET_FOTOS
} from '../../types/index';

import axiosClient from '../../config/axios';

const TagDescriptorState = props => {
    
    const initialState = {
        tagdescriptors: [],
        searchtagdescriptors: [],
        interlocks: [],
        alarmasyeventos: [],
        fotos: null,
        form: false,
        tagname_ok: true, 
        tagdescriptor: null,
        related: [],
        message: null,
        urlDoc: null
    };

    const [state, dispatch] = useReducer(tagDescriptorReducer, initialState);

    const cache = useRef({
        tagdescriptors: null,
        lastFetch: null,
        system: null
    });

    const fetchingTags = useRef(null);

    const showForm = useCallback(() => {
        dispatch({ type: FORM_TAGDESCRIPTOR });
    }, []);

    const getTagsDescriptors = useCallback(async (system, forceRefresh = false) => {
        if (!system) {
            return;
        }

        // Verificar caché (válido por 5 minutos)
        const now = Date.now();
        const cacheValid = cache.current.lastFetch && 
                          cache.current.system === system &&
                          (now - cache.current.lastFetch < 5 * 60 * 1000);

        if (!forceRefresh && cacheValid && cache.current.tagdescriptors) {
            dispatch({
                type: GET_TAGSDESCRIPTORS,
                payload: cache.current.tagdescriptors
            });
            return;
        }

        // Si ya hay una petición en progreso para este system, no hacer otra
        if (fetchingTags.current === system) {
            return;
        }

        fetchingTags.current = system;

        try {
            const res = await axiosClient.get('/api/tagsdescriptors', { params: { system } });
            
            // Guardar en caché
            cache.current.tagdescriptors = res.data.tagsdescriptors;
            cache.current.lastFetch = now;
            cache.current.system = system;
            
            dispatch({
                type: GET_TAGSDESCRIPTORS,
                payload: res.data.tagsdescriptors
            });
        } catch (error) {
            const alert = {
                msg: "hubo un error buscando los tagdescriptors",
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR_TAGDESCRIPTOR,
                payload: alert
            });
        } finally {
            fetchingTags.current = null;
        }
    }, []);

    const searchTagsDescriptors = useCallback(async (search) => {
        try {
            dispatch({
                type: SEARCH_TAGSDESCRIPTORS,
                payload: search.toUpperCase()
            });
        } catch (error) {
            const alert = {
                msg: "hubo un error buscando los tagdescriptors",
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR_TAGDESCRIPTOR,
                payload: alert
            });
        }
    }, []);

    const getTagDescriptor = useCallback(async (id) => {
        try {
            const res = await axiosClient.get(`/api/showtag/${id}`);
            dispatch({
                type: GET_TAGDESCRIPTOR,
                payload: res.data.tagdescriptor
            });
        } catch (error) {
            const alert = {
                msg: "No existe el tag descriptor",
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR_TAGDESCRIPTOR,
                payload: alert
            });
        }
    }, []);

    const getAllTagDescriptor = useCallback(async () => {
        try {
            const res = await axiosClient.get('/api/tagsdescriptors/all');
            dispatch({
                type: GET_ALL_TAGDESCRIPTORS,
                payload: res.data.tagsdescriptors
            });
        } catch (error) {
            const alert = {
                msg: "hubo un error buscando los tagdescriptors",
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR_TAGDESCRIPTOR,
                payload: alert
            });
        }
    }, []);

    const resetMessage = useCallback(() => {
        dispatch({ type: RESET_MESSAGE });
    }, []);

    const createTagDescriptor = useCallback(async (ptagdescriptor) => {
        try {
            const res = await axiosClient.post('/api/tagsdescriptors', ptagdescriptor);
            
            cache.current.tagdescriptors = null;
            cache.current.lastFetch = null;
            
            dispatch({
                type: CREATE_TAGDESCRIPTOR,
                payload: res.data
            });
        } catch (error) {
            const alert = {
                msg: error.response.data.msg,
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR_TAGDESCRIPTOR,
                payload: alert
            });
        }
    }, []);

    const createDocument = useCallback(async (system) => {
        try {
            const res = await axiosClient.get('/api/documents', { params: { system } });
            dispatch({
                type: CREATE_DOCUMENT,
                payload: res.data
            });
        } catch (error) {
            const alert = {
                msg: error.response.data.msg,
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR_TAGDESCRIPTOR,
                payload: alert
            });
        }
    }, []);

    const showError = useCallback(() => {
        dispatch({ type: SHOW_ERROR_TAGDESCRIPTOR });
    }, []);

    const selectTagDescriptor = useCallback((id_tagdescriptor) => {
        console.log("Select", id_tagdescriptor);
        dispatch({
            type: SELECT_TAGDESCRIPTOR,
            payload: id_tagdescriptor
        });
    }, []);

    const deselectTagDescriptor = useCallback(() => {
        dispatch({ type: DESELECT_TAGDESCRIPTOR });
    }, []);

    const deleteTagDescriptor = useCallback(async (idTagDescriptor) => {
        try {
            await axiosClient.delete(`/api/tagsdescriptors/${idTagDescriptor}`);
            
            cache.current.tagdescriptors = null;
            cache.current.lastFetch = null;
            
            dispatch({
                type: DELETE_TAGDESCRIPTOR,
                payload: idTagDescriptor
            });
        } catch (error) {
            const alert = {
                msg: "hubo un error eliminando el tag descriptor",
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR_TAGDESCRIPTOR,
                payload: alert
            });
        }
    }, []);

    const validateTagname = useCallback(async (id) => {
        try {
            await axiosClient.get(`/api/showtag/${id}`);
            const alert = {
                msg: "El tag descriptor para ese tagname ya existe",
                category: "alerta-error"
            };
            dispatch({
                type: INVALIDATE_TAGDESCRIPTOR,
                payload: alert
            });
        } catch (error) {
            dispatch({ type: VALIDATE_TAGDESCRIPTOR });
        }
    }, []);

    const updateTagDescriptor = useCallback(async (tagdescriptor) => {
        try {
            const id = tagdescriptor._id;
            const res = await axiosClient.put(`/api/tagsdescriptors/${id}`, tagdescriptor);
            
            cache.current.tagdescriptors = null;
            cache.current.lastFetch = null;
            
            dispatch({
                type: UPDATE_TAGDESCRIPTOR,
                payload: res.data.tag_descriptor_modified
            });
        } catch (error) {
            console.log(error);
        }
    }, []);

    const selectOnlyDescriptor = useCallback(async (tagdescriptor) => {
        dispatch({
            type: SELECT_ONLY_DESCRIPTOR,
            payload: tagdescriptor
        });
    }, []);

    const getTagDescriptorsRelated = useCallback(async (id) => {
        try {
            const res = await axiosClient.get(`/api/tagsdescriptors/related/${id}`);
            console.log(res.data);
            dispatch({
                type: GET_TAGSDESCRIPTORS_RELATED,
                payload: res.data.tagsDescriptors_related
            });
        } catch (error) {
            const alert = {
                msg: "No existen descriptores relacionados",
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR_TAGDESCRIPTOR,
                payload: alert
            });
        }
    }, []);

    const getInterlocks = useCallback(async (tagdescriptor) => {
        try {
            const id = tagdescriptor._id;
            const res = await axiosClient.get(`/api/interlocks/${id}`);
            dispatch({
                type: GET_INTERLOCKS,
                payload: res.data.resp
            });
        } catch (error) {
            console.log(error);
        }
    }, []);
    
    const getAlarmayEventos = useCallback(async (id) => {
        try {
            const res = await axiosClient.get(`/api/alarmasyeventos/${id}`);
            dispatch({
                type: GET_AYE,
                payload: res.data.resp
            });
        } catch (error) {
            console.log(error);
        }
    }, []);

    const getFotos = useCallback(async (tagdescriptor) => {
        try {
            const id = tagdescriptor._id;
            const res = await axiosClient.get(`/api/fotos/${id}`);
            dispatch({
                type: GET_FOTOS,
                payload: res.data.resp
            });
        } catch (error) {
            console.log(error);
        }
    }, []);

    const value = useMemo(
        () => ({
            tagdescriptors: state.tagdescriptors,
            form: state.form,
            error: state.error,
            tagdescriptor: state.tagdescriptor,
            message: state.message,
            searchtagdescriptors: state.searchtagdescriptors,
            tagname_ok: state.tagname_ok,
            urlDoc: state.urlDoc,
            related: state.related,
            interlocks: state.interlocks,
            alarmasyeventos: state.alarmasyeventos,
            showForm, 
            getTagsDescriptors,
            createTagDescriptor,
            showError, 
            selectTagDescriptor,
            deleteTagDescriptor,
            getTagDescriptor,
            deselectTagDescriptor,
            updateTagDescriptor,
            searchTagsDescriptors,
            getTagDescriptorsRelated,
            resetMessage,
            validateTagname,
            createDocument,
            selectOnlyDescriptor,
            getInterlocks,
            getAlarmayEventos,
            getAllTagDescriptor,
            getFotos
        }),
        [
            state,
            showForm,
            getTagsDescriptors,
            createTagDescriptor,
            showError,
            selectTagDescriptor,
            deleteTagDescriptor,
            getTagDescriptor,
            deselectTagDescriptor,
            updateTagDescriptor,
            searchTagsDescriptors,
            getTagDescriptorsRelated,
            resetMessage,
            validateTagname,
            createDocument,
            selectOnlyDescriptor,
            getInterlocks,
            getAlarmayEventos,
            getAllTagDescriptor,
            getFotos
        ]
    );

    return (
        <tagDescriptorContext.Provider value={value}>
            {props.children}
        </tagDescriptorContext.Provider>
    );
};

export default TagDescriptorState;