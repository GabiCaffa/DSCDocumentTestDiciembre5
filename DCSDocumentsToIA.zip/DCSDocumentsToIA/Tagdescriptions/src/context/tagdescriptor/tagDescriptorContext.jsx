import {createContext} from 'react'

const tagDescriptorContext = createContext();

export default tagDescriptorContext;