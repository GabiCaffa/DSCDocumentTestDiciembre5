import {createContext} from 'react'

const iocardsContext = createContext();

export default iocardsContext;