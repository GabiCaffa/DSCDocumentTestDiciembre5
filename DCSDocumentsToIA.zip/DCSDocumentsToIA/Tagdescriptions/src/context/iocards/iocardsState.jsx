//tagdescriptions/src/context/iocards/iocardsState.jsx
import React, { useReducer, useMemo, useRef, useCallback } from 'react';
import iocardsContext from './iocardsContext';
import iocardsReducer from './iocardsReducer';
import {
    CREATE_IOCARD, 
    SHOW_FORM_IOCARD, 
    GET_IOCARDS,
    SHOW_ERROR,
    UPDATE_IOCARD,
    DELETE_IOCARD,
    SELECT_IOCARD,
    GET_IOCARD,
    GET_IOCARD_TYPES,
    GET_IOCARD_TYPE,
    RESET_MESSAGE,
    GET_IOCARD_STATUS,
    SEARCH_IOCARD,
    GET_IOCARD_NODE_ID,
    GET_IOCARD_CONTROLLERS,
    GET_IOCARD_CABINETS,
    DESELECT_IOCARD_NODE_ID,
    GET_IOCARD_CONTROLLERS_SINB,
    GET_IOCARDS_CONTROLLER_A,
} from '../../types/index';

import axiosClient from '../../config/axios';

const IOCardsState = props => {
    
    const initialState = {
        form: false,
        devices: [],
        devicesSearch: [],
        deviceSelected: null,
        message: null,
        devicetypes: [],
        devicetype: null,
        error: false,
        status: {},
        iocards: [],
        iocardsSearch: [],
        iocardsSelected: null,
        iocardtypes: [],
        iocardcontrollers: [],
        iocardcabinets: []
    };

    const [state, dispatch] = useReducer(iocardsReducer, initialState);

    const cache = useRef({
        iocards: null,
        iocardtypes: null,
        controllers: null,
        cabinets: null,
        lastFetchIOCards: null,
        lastFetchTypes: null,
        lastFetchControllers: null,
        lastFetchCabinets: null,
        asset: null
    });

    const fetchingIOCards = useRef(null);
    const fetchingTypes = useRef(false);
    const fetchingControllers = useRef(false);
    const fetchingCabinets = useRef(false);

    const showForm = useCallback(() => {
        dispatch({ type: SHOW_FORM_IOCARD });
    }, []);

    const createIOCard = useCallback(async (iocard) => {
        try {
            const res = await axiosClient.post('/api/iocards', iocard);
            
            // Invalidar caché
            cache.current.iocards = null;
            cache.current.lastFetchIOCards = null;

            dispatch({
                type: CREATE_IOCARD,
                payload: res.data
            });
        } catch (error) {
            console.log(error.response);
            let aux = "";
            if (error.response.status === 400)
                aux = error.response.data.errors[0].msg;
            else
                aux = error.response.data.msg;
            
            const alert = {
                msg: aux,
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        }
    }, []);

    const getDevice = useCallback(async (idDevice) => {
        try {
            const res = await axiosClient.get(`/api/devices/${idDevice}`);
            dispatch({
                type: GET_IOCARD,
                payload: res.data.device_get
            });
        } catch (error) {
            const alert = {
                msg: "hubo un error con el nodo de red",
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        }
    }, []);

    const resetMessage = useCallback(() => {
        dispatch({ type: RESET_MESSAGE });
    }, []);
    
    const getIOCards = useCallback(async (asset, forceRefresh = false) => {
        if (!asset) return;

        const now = Date.now();
        const cacheValid = cache.current.lastFetchIOCards && 
                          cache.current.asset === asset &&
                          (now - cache.current.lastFetchIOCards < 5 * 60 * 1000);

        if (!forceRefresh && cacheValid && cache.current.iocards) {
            dispatch({
                type: GET_IOCARDS,
                payload: cache.current.iocards
            });
            return;
        }

        if (fetchingIOCards.current === asset) {
            return;
        }

        fetchingIOCards.current = asset;

        try {
            const res = await axiosClient.get('/api/iocards', { params: { asset } });
            
            cache.current.iocards = res.data.iocards;
            cache.current.lastFetchIOCards = now;
            cache.current.asset = asset;

            dispatch({
                type: GET_IOCARDS,
                payload: res.data.iocards
            });
        } catch (error) {
            const alert = {
                msg: error.response.data.msg,
                category: 'alerta-error'
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        } finally {
            fetchingIOCards.current = null;
        }
    }, []);

    const getIOCardsAll = useCallback(async () => {
        try {
            const res = await axiosClient.get('/api/iocards/all');
            dispatch({
                type: GET_IOCARDS,
                payload: res.data.iocards
            });
        } catch (error) {
            const alert = {
                msg: error.response.data.msg,
                category: 'alerta-error'
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        }
    }, []);

    const showError = useCallback(() => {
        dispatch({ type: SHOW_ERROR });
    }, []);

    const getCabinets = useCallback(async () => {
        try {
            const res = await axiosClient.get('/api/devicestypes');
            dispatch({
                type: GET_IOCARD_TYPES,
                payload: res.data.deviceTypes
            });
        } catch (error) {
            const alert = {
                msg: error.response.data.msg,
                category: 'alerta-error'
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        }
    }, []);

    const getIOCardControllers = useCallback(async (forceRefresh = false) => {
        const now = Date.now();
        const cacheValid = cache.current.lastFetchControllers && 
                          (now - cache.current.lastFetchControllers < 5 * 60 * 1000);

        if (!forceRefresh && cacheValid && cache.current.controllers) {
            dispatch({
                type: GET_IOCARD_CONTROLLERS,
                payload: cache.current.controllers
            });
            return;
        }

        if (fetchingControllers.current) {
            return;
        }

        fetchingControllers.current = true;

        try {
            const res = await axiosClient.get('/api/iocards/iocardcontrollers');
            
            cache.current.controllers = res.data.allControllers;
            cache.current.lastFetchControllers = now;

            dispatch({
                type: GET_IOCARD_CONTROLLERS,
                payload: res.data.allControllers
            });
        } catch (error) {
            const alert = {
                msg: error.response.data.msg,
                category: 'alerta-error'
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        } finally {
            fetchingControllers.current = false;
        }
    }, []);

    const getIOCardControllers_sinB = useCallback(async () => {
        try {
            const res = await axiosClient.get('/api/iocards/iocardcontrollerssinB');
            dispatch({
                type: GET_IOCARD_CONTROLLERS_SINB,
                payload: res.data.allControllers
            });
        } catch (error) {
            const alert = {
                msg: error.response.data.msg,
                category: 'alerta-error'
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        }
    }, []);

    const getIOCardCabinets = useCallback(async (forceRefresh = false) => {
        const now = Date.now();
        const cacheValid = cache.current.lastFetchCabinets && 
                          (now - cache.current.lastFetchCabinets < 5 * 60 * 1000);

        if (!forceRefresh && cacheValid && cache.current.cabinets) {
            dispatch({
                type: GET_IOCARD_CABINETS,
                payload: cache.current.cabinets
            });
            return;
        }

        if (fetchingCabinets.current) {
            return;
        }

        fetchingCabinets.current = true;

        try {
            const res = await axiosClient.get('/api/iocards/iocardcabinets');
            
            cache.current.cabinets = res.data.cabinets;
            cache.current.lastFetchCabinets = now;

            dispatch({
                type: GET_IOCARD_CABINETS,
                payload: res.data.cabinets
            });
        } catch (error) {
            const alert = {
                msg: error.response.data.msg,
                category: 'alerta-error'
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        } finally {
            fetchingCabinets.current = false;
        }
    }, []);

    const getIOCardTypes = useCallback(async (forceRefresh = false) => {
        const now = Date.now();
        const cacheValid = cache.current.lastFetchTypes && 
                          (now - cache.current.lastFetchTypes < 5 * 60 * 1000);

        if (!forceRefresh && cacheValid && cache.current.iocardtypes) {
            dispatch({
                type: GET_IOCARD_TYPES,
                payload: cache.current.iocardtypes
            });
            return;
        }

        if (fetchingTypes.current) {
            return;
        }

        fetchingTypes.current = true;

        try {
            const res = await axiosClient.get('/api/iocards/iocardstypes');
            
            cache.current.iocardtypes = res.data.iocardTypes_all;
            cache.current.lastFetchTypes = now;

            dispatch({
                type: GET_IOCARD_TYPES,
                payload: res.data.iocardTypes_all
            });
        } catch (error) {
            const alert = {
                msg: error.response.data.msg,
                category: 'alerta-error'
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        } finally {
            fetchingTypes.current = false;
        }
    }, []);

    const getDeviceType = useCallback(async (idDevice) => {
        try {
            const res = await axiosClient.get(`/api/devicestypes/${idDevice}`);
            dispatch({
                type: GET_IOCARD_TYPE,
                payload: res.data.device_type
            });
        } catch (error) {
            // Silencioso
        }
    }, []);

    const selectIOCard = useCallback((idIOCard) => {
        dispatch({
            type: SELECT_IOCARD,
            payload: idIOCard
        });
    }, []);

    const deleteIOCard = useCallback(async (id) => {
        try {
            await axiosClient.delete(`/api/iocards/${id}`);
            
            // Invalidar caché
            cache.current.iocards = null;
            cache.current.lastFetchIOCards = null;

            dispatch({
                type: DELETE_IOCARD,
                payload: id
            });
        } catch (error) {
            const alert = {
                msg: "hubo un error eliminando el nodo de red",
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        }
    }, []);

    const getDeviceStatus = useCallback(async (idDevice) => {
        try {
            const res = await axiosClient.get(`/api/devices/status/${idDevice}`);
            dispatch({
                type: GET_IOCARD_STATUS,
                payload: res.data
            });
        } catch (error) {
            console.log(error);
        }
    }, []);

    const updateIOCard = useCallback(async (iocard) => {
        try {
            const id = iocard._id;
            const res = await axiosClient.put(`/api/iocards/${id}`, iocard);
            
            // Invalidar caché
            cache.current.iocards = null;
            cache.current.lastFetchIOCards = null;

            dispatch({
                type: UPDATE_IOCARD,
                payload: res.data.iocardUpdate
            });
        } catch (error) {
            let aux = "";
            if (error.response.status === 400)
                aux = error.response.data.errors[0].msg;
            else
                aux = error.response.data.msg;
            const alert = {
                msg: aux,
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        }
    }, []);

    const searchIOCards = useCallback((text) => {
        dispatch({
            type: SEARCH_IOCARD,
            payload: text
        });
    }, []);

    const getDeviceID = useCallback(async (deviceName) => {
        try {
            const res = await axiosClient.get('/api/architecture/getDeviceID', { params: { deviceName } });
            dispatch({
                type: GET_IOCARD_NODE_ID,
                payload: res.data.idDevice
            });
        } catch (error) {
            const alert = {
                msg: "hubo un error con el device",
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        }
    }, []);

    const deselectDeviceId = useCallback(() => {
        dispatch({ type: DESELECT_IOCARD_NODE_ID });
    }, []);

    const getIoCardsContrllerA = useCallback(async (idController) => {
        try {
            const res = await axiosClient.get(`/api/iocards/iocardsA/${idController}`);
            dispatch({
                type: GET_IOCARDS_CONTROLLER_A,
                payload: res.data.iocards
            });
        } catch (error) {
            const alert = {
                msg: "hubo un error con el device",
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        }
    }, []);

    const getIoCardsContrllerB = useCallback(() => {
        // Implementar si es necesario
    }, []);

    const value = useMemo(
        () => ({
            form: state.form,
            devices: state.devices,
            deviceSelected: state.deviceSelected,
            error: state.error,
            devicetypes: state.devicetypes,
            devicetype: state.devicetype,
            status: state.status,
            devicesSearch: state.devicesSearch,
            deviceID: state.deviceID,
            message: state.message,
            iocards: state.iocards,
            iocardsSearch: state.iocardsSearch,
            iocardsSelected: state.iocardsSelected,
            iocardtypes: state.iocardtypes,
            iocardcontrollers: state.iocardcontrollers,
            iocardcabinets: state.iocardcabinets,
            showForm, 
            createIOCard,
            getIOCards,
            getIOCardsAll,
            getIOCardTypes,
            getDevice,
            updateIOCard,
            showError,
            selectIOCard,
            deleteIOCard,
            getDeviceType,
            resetMessage,
            getDeviceStatus,
            searchIOCards,
            getDeviceID,
            deselectDeviceId,
            getIOCardControllers,
            getIOCardControllers_sinB,
            getIOCardCabinets,
            getCabinets,
            getIoCardsContrllerA,
            getIoCardsContrllerB
        }),
        [
            state,
            showForm,
            createIOCard,
            getIOCards,
            getIOCardsAll,
            getIOCardTypes,
            getDevice,
            updateIOCard,
            showError,
            selectIOCard,
            deleteIOCard,
            getDeviceType,
            resetMessage,
            getDeviceStatus,
            searchIOCards,
            getDeviceID,
            deselectDeviceId,
            getIOCardControllers,
            getIOCardControllers_sinB,
            getIOCardCabinets,
            getCabinets,
            getIoCardsContrllerA,
            getIoCardsContrllerB
        ]
    );

    return (
        <iocardsContext.Provider value={value}>
            {props.children}
        </iocardsContext.Provider>
    );
};

export default IOCardsState;