// tagdescriptions/src/context/user/userState.jsx
import React, { useReducer, useMemo, useRef, useCallback } from 'react';
import userContext from './userContext';
import userReducer from './userReducer';
import axiosClient from '../../config/axios';

import {
    GET_USERS_SUCCESS,
    GET_USERS_ERROR,
    UPDATE_USER_SUCCESS,
    UPDATE_USER_ERROR,
    DELETE_USER_SUCCESS,
    DELETE_USER_ERROR,
    RESET_MESSAGE,
    CHANGE_PASSWORD_SUCCESS,
    CHANGE_PASSWORD_ERROR
} from '../../types/index';

const UserState = (props) => {
    const initialState = {
        users: [],
        message: null,
    };

    const [state, dispatch] = useReducer(userReducer, initialState);

    const cache = useRef({
        users: null,
        lastFetch: null
    });

    const fetchingUsers = useRef(false);

    const getUsers = useCallback(async (forceRefresh = false) => {
        const now = Date.now();
        const cacheValid = cache.current.lastFetch && 
                          (now - cache.current.lastFetch < 5 * 60 * 1000);

        if (!forceRefresh && cacheValid && cache.current.users) {
            dispatch({
                type: GET_USERS_SUCCESS,
                payload: cache.current.users
            });
            return;
        }

        if (fetchingUsers.current) {
            return;
        }

        fetchingUsers.current = true;

        try {
            const res = await axiosClient.get('api/users');
            
            cache.current.users = res.data.users;
            cache.current.lastFetch = now;

            dispatch({
                type: GET_USERS_SUCCESS,
                payload: res.data.users
            });
        } catch (error) {
            console.log(error);
            const alert = {
                msg: error.response.data.msg,
                category: 'alerta-error'
            };
            dispatch({
                type: GET_USERS_ERROR,
                payload: alert
            });
        } finally {
            fetchingUsers.current = false;
        }
    }, []);

    const updateUser = useCallback(async (user) => {
        try {
            await axiosClient.put(`/api/users/changeState/${user._id}`, user);
            
            // Invalidar caché
            cache.current.users = null;
            cache.current.lastFetch = null;

            dispatch({ type: UPDATE_USER_SUCCESS });

            getUsers(true);
        } catch (error) {
            console.log(error);
            const alert = {
                msg: error.response.data.msg,
                category: 'alerta-error'
            };
            dispatch({
                type: UPDATE_USER_ERROR,
                payload: alert
            });
        }
    }, [getUsers]);
    
    const deleteUser = useCallback(async (user) => {
    try {
        const idUser = user._id;
        
        // Llamada al backend - ruta correcta
        await axiosClient.delete(`/api/users/${idUser}`); 
        
        // Invalidar caché
        cache.current.users = null;
        cache.current.lastFetch = null;

        const alert = {
            msg: 'Usuario eliminado correctamente',
            category: 'alerta-ok'
        };

        dispatch({ 
            type: DELETE_USER_SUCCESS,
            payload: alert
        });

        // Recargar usuarios
        getUsers(true);
        
    } catch (error) {
        console.error('Error eliminando usuario:', error);
        
        const alert = {
            msg: error.response?.data?.msg || 'No se pudo eliminar el usuario',
            category: 'alerta-error'
        };
        
        dispatch({
            type: DELETE_USER_ERROR,
            payload: alert
        });
    }
}, [getUsers]);

    const changePassword = useCallback(async (password) => {
        try {
            console.log("fumo?");
            await axiosClient.put(`/api/users/changePassword`, password);
            
            dispatch({ type: CHANGE_PASSWORD_SUCCESS });

            getUsers(true);
        } catch (error) {
            console.log(error);
            const alert = {
                msg: error.response.data.msg,
                category: 'alerta-error'
            };
            dispatch({
                type: CHANGE_PASSWORD_ERROR,
                payload: alert
            });
        }
    }, [getUsers]);
    
    const resetMessage = useCallback(() => {
        dispatch({ type: RESET_MESSAGE });
    }, []);

    const value = useMemo(
        () => ({
            users: state.users,
            message: state.message,
            getUsers,
            updateUser,
            deleteUser,
            resetMessage,
            changePassword
        }),
        [
            state,
            getUsers,
            updateUser,
            deleteUser,
            resetMessage,
            changePassword
        ]
    );

    return (
        <userContext.Provider value={value}>
            {props.children}
        </userContext.Provider>
    );
};

export default UserState;