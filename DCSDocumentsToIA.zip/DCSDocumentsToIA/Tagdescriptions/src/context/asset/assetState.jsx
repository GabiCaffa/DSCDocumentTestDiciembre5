//tagdescriptions/src/context/asset/assetState.jsx
import React, { useReducer, useMemo, useRef, useCallback } from 'react';import assetContext from './assetContext';
import assetReducer from './assetReducer';
import {
    FORM_ASSETS,      
    GET_ASSETS,       
    ADD_ASSET,       
    SHOW_ERROR_ASSET,
    VALIDATE_ASSET,  
    SELECT_ASSET,    
    DELETE_ASSET,
    GET_ASSETS_TREE,
    DESELECT_ASSET,
    RESET_MESSAGE   
} from '../../types/index';
import axiosClient from '../../config/axios';

const AssetState = props => {
    
    const initialState = {
        assets: [],
        form: false,
        error: false, 
        asset: null,
        message: null, 
        assetsTree: [{}]
    };

    const [state, dispatch] = useReducer(assetReducer, initialState);

    const cache = useRef({
        assets: null,
        assetsTree: null,
        lastFetchAssets: null,
        lastFetchTree: null
    });

    const fetchingAssets = useRef(false);
    const fetchingTree = useRef(false);

    const showForm = useCallback(() => {
        dispatch({ type: FORM_ASSETS });
    }, []);

    const getAssets = useCallback(async (forceRefresh = false) => {
        // Verificar caché (válido por 5 minutos)
        const now = Date.now();
        const cacheValid = cache.current.lastFetchAssets && 
                          (now - cache.current.lastFetchAssets < 5 * 60 * 1000);

        if (!forceRefresh && cacheValid && cache.current.assets) {
            dispatch({
                type: GET_ASSETS,
                payload: cache.current.assets
            });
            return;
        }

        // Si ya hay una petición en progreso, no hacer otra
        if (fetchingAssets.current) {
            return;
        }

        fetchingAssets.current = true;

        try {
            const res = await axiosClient.get('/api/assets');
            
            // Guardar en caché
            cache.current.assets = res.data.assets;
            cache.current.lastFetchAssets = now;
            
            dispatch({
                type: GET_ASSETS,
                payload: res.data.assets
            });
        } catch (error) {
            const alert = {
                msg: error.response?.data?.msg || 'Error al obtener assets',
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR_ASSET,
                payload: alert
            });
        } finally {
            fetchingAssets.current = false;
        }
    }, []);

    const addAsset = useCallback(async asset => {
        try {
            const res = await axiosClient.post('/api/assets', asset);
            
            //  Invalidar caché al agregar
            cache.current.assets = null;
            cache.current.assetsTree = null;
            cache.current.lastFetchAssets = null;
            cache.current.lastFetchTree = null;
            
            dispatch({
                type: ADD_ASSET,
                payload: res.data
            });
        } catch (error) {
            const alert = {
                msg: error.response?.data?.msg || 'Error al agregar asset',
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR_ASSET,
                payload: alert
            });
        }
    }, []);

    const showError = useCallback(() => {
        dispatch({ type: VALIDATE_ASSET });
    }, []);

    const selectAsset = useCallback((asset) => {
        dispatch({
            type: SELECT_ASSET,
            payload: asset
        });
    }, []);

    const deSelectAsset = useCallback(() => {
        dispatch({
            type: DESELECT_ASSET,
            payload: null
        });
    }, []);

    const resetMessage = useCallback(() => {
        dispatch({ type: RESET_MESSAGE });
    }, []);

    const deleteAsset = useCallback(async (asset) => {
        try {
            const idAsset = asset._id;
            
            await axiosClient.delete(`/api/assets/${idAsset}`);
            
            cache.current.assets = null;
            cache.current.assetsTree = null;
            cache.current.lastFetchAssets = null;
            cache.current.lastFetchTree = null;
            
            dispatch({
                type: DELETE_ASSET,
                payload: idAsset
            });
        } catch (error) {
            const alert = {
                msg: error.response?.data?.msg || 'Error al eliminar asset',
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR_ASSET,
                payload: alert
            });
        }
    }, []);

    const getAssetTree = useCallback(async (forceRefresh = false) => {
        // Verificar caché (válido por 5 minutos)
        const now = Date.now();
        const cacheValid = cache.current.lastFetchTree && 
                          (now - cache.current.lastFetchTree < 5 * 60 * 1000);

        if (!forceRefresh && cacheValid && cache.current.assetsTree) {
            dispatch({
                type: GET_ASSETS_TREE,
                payload: cache.current.assetsTree
            });
            return;
        }

        //  Si ya hay una petición en progreso, no hacer otra
        if (fetchingTree.current) {
            return;
        }

        fetchingTree.current = true;

        try {
            //  CORREGIDO: Agregada la / inicial
            const res = await axiosClient.get('/api/tree');
            
            let assetsTree_temp = res.data.assets;
            let j = 0;
            let i = 0;
            
            assetsTree_temp.forEach(i_asset => {
                assetsTree_temp[j].key = i_asset._id;
                assetsTree_temp[j].label = i_asset.name;
                assetsTree_temp[j].nodes = i_asset.nodes;
                i = 0;
                assetsTree_temp[j].nodes.forEach(i_system => {
                    assetsTree_temp[j].nodes[i].key = i_system._id;
                    assetsTree_temp[j].nodes[i].label = i_system.name;
                    i = i + 1;
                });
                j = j + 1;
            });

            // Guardar en caché
            cache.current.assetsTree = assetsTree_temp;
            cache.current.lastFetchTree = now;

            dispatch({
                type: GET_ASSETS_TREE,
                payload: assetsTree_temp
            });

        } catch (error) {
            const alert = {
                msg: error.response?.data?.msg || 'Error al obtener árbol de assets',
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR_ASSET,
                payload: alert
            });
        } finally {
            fetchingTree.current = false;
        }
    }, []);

    //  CRÍTICO: Memoizar el valor del contexto
    const value = useMemo(
        () => ({
            assets: state.assets,
            form: state.form,
            error: state.error,
            asset: state.asset,
            message: state.message,
            assetsTree: state.assetsTree,
            showForm, 
            getAssets,
            addAsset,
            showError, 
            selectAsset,
            deleteAsset,
            getAssetTree,
            resetMessage,
            deSelectAsset
        }),
        [
            state,
            showForm,
            getAssets,
            addAsset,
            showError,
            selectAsset,
            deleteAsset,
            getAssetTree,
            resetMessage,
            deSelectAsset
        ]
    );

    return (
        <assetContext.Provider value={value}>
            {props.children}
        </assetContext.Provider>
    );
};

export default AssetState;