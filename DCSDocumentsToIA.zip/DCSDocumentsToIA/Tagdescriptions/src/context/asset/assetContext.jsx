import {createContext} from 'react'

const assetContext = createContext();

export default assetContext;