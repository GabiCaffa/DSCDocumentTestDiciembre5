// tagdescriptions/src/context/report/reportState.jsx
import reportContext from './reportContext';
import reportReducer from './reportReducer';
import React, { useReducer, useMemo, useRef, useCallback } from 'react';import {
    FORM_REPORT,
    GET_REPORT,
    CREATE_REPORT,
    SHOW_ERROR_REPORT,
    UPDATE_REPORT,
    SELECT_REPORT,
    DESELECT_REPORT,
    GET_REPORTS,
    DELETE_REPORT,
    SEARCH_REPORTS,
    RESET_REPORT_MESSAGE,
    VALIDATE_REPORT,
    INVALIDATE_REPORT,
    SELECT_ONLY_REPORT,
    EXECUTE_REPORT
} from '../../types/index';

import axiosClient from '../../config/axios';

const ReportState = props => {

    const initialState = {
        reports: [],
        searchreports: [],   
        reportResult: [],   
        form: false,
        reportname_ok: true,
        report: null,
        related: [],
        message: null,
        urlDoc: null,
        error: false
    };

    const [state, dispatch] = useReducer(reportReducer, initialState);
    
    
const cache = useRef({
    reports: null,
    lastFetch: null,
    system: null 
});

const fetchingReports = useRef(null);

    const showForm = () => {
        dispatch({ type: FORM_REPORT });
    };

const getReports = useCallback(async (system, forceRefresh = false) => {
    if (!system) {
        return;
    }

    // Verificar caché (válido por 5 minutos)
    const now = Date.now();
    const cacheKey = `${system}`;
    const cacheValid = cache.current.lastFetch && 
                      cache.current.system === system &&
                      (now - cache.current.lastFetch < 5 * 60 * 1000);

    if (!forceRefresh && cacheValid && cache.current.reports) {
        dispatch({
            type: GET_REPORTS,
            payload: cache.current.reports
        });
        return;
    }

    // Si ya hay una petición en progreso para este system, no hacer otra
    if (fetchingReports.current === system) {
        return;
    }

    fetchingReports.current = system;

    try {
        const res = await axiosClient.get('/api/reports', { params: { system } });
        
        // Guardar en caché
        cache.current.reports = res.data.reports;
        cache.current.lastFetch = now;
        cache.current.system = system;
        
        dispatch({
            type: GET_REPORTS,
            payload: res.data.reports
        });
    } catch (error) {
        dispatch({
            type: SHOW_ERROR_REPORT,
            payload: { msg: "Hubo un error buscando los reportes", category: "alerta-error" }
        });
    } finally {
        fetchingReports.current = null;
    }
}, []);

    const searchReports = (search) => {
        dispatch({
            type: SEARCH_REPORTS,
            payload: search.toUpperCase()
        });
    };

    const getReport = async (id) => {
        try {
            const res = await axiosClient.get(`/api/reports/${id}`);
            const report = res.data.report;
            dispatch({
                type: GET_REPORT,
                payload: report
            });
            return report;
        } catch (error) {
            dispatch({
                type: SHOW_ERROR_REPORT,
                payload: { msg: "No existe el reporte", category: "alerta-error" }
            });
            return null;
        }
    };

    const resetMessage = () => dispatch({ type: RESET_REPORT_MESSAGE });

    const createReport = async report => {
        try {
            const res = await axiosClient.post('/api/reports', report);
            
            cache.current.reports = null;
            cache.current.lastFetch = null;
            
            dispatch({
                type: CREATE_REPORT,
                payload: res.data
            });
        } catch (error) {
            dispatch({
                type: SHOW_ERROR_REPORT,
                payload: { msg: error.response.data.msg, category: "alerta-error" }
            });
        }
    };

    const showError = () => {
        dispatch({ type: SHOW_ERROR_REPORT });
    };

    const selectReport = (id) => {
        dispatch({
            type: SELECT_REPORT,
            payload: id
        });
    };

    const deselectReport = () => {
        dispatch({
            type: DESELECT_REPORT
        });
    };

    const deleteReport = async (id) => {
        try {
            await axiosClient.delete(`/api/reports/${id}`);
            
            cache.current.reports = null;
            cache.current.lastFetch = null;
            
            dispatch({
                type: DELETE_REPORT,
                payload: id
            });
        } catch (error) {
            dispatch({
                type: SHOW_ERROR_REPORT,
                payload: { msg: "Hubo un error eliminando el reporte", category: "alerta-error" }
            });
        }
    };

    const validateReportName = async (reportName) => {
        try {
            const res = await axiosClient.get(`/api/reports`);
            const existingReport = res.data.reports.find(
                r => r.name.toUpperCase() === reportName.toUpperCase()
            );
            
            if (existingReport) {
                const alert = {
                    msg: "El reporte para ese nombre ya existe",
                    category: "alerta-error"
                };
                dispatch({
                    type: INVALIDATE_REPORT,
                    payload: alert
                });
            } else {
                dispatch({ type: VALIDATE_REPORT });
            }
        } catch (error) {
            dispatch({ type: VALIDATE_REPORT });
        }
    };

    const updateReport = async (report) => {
        try {
            const id = report._id;
            const res = await axiosClient.put(`/api/reports/${id}`, report);
            
            cache.current.reports = null;
            cache.current.lastFetch = null;
            
            dispatch({
                type: UPDATE_REPORT,
                payload: res.data.report_modified
            });
        } catch (error) {
            console.log(error);
        }
    };

    const selectOnlyReport = (report) => {
        dispatch({
            type: SELECT_ONLY_REPORT,
            payload: report
        });
    };

    const executeReport = async (nameReport) => {
        try {
            const res = await axiosClient.get(`/api/reports/execute/${nameReport}`);
            dispatch({
                type: EXECUTE_REPORT,
                payload: res.data.result
            });
        } catch (error) {
            console.error("Error ejecutando reporte:", error);
            throw error;
        }
    };

    const executeReportWithParams = async (nameReport, parameters) => {
        try {
            const res = await axiosClient.post(`/api/reports/execute/${nameReport}`, {
                parameters
            });
            dispatch({
                type: EXECUTE_REPORT,
                payload: res.data.result
            });
            return res.data.result;
        } catch (error) {
            console.error("Error ejecutando reporte con parámetros:", error);
            dispatch({
                type: SHOW_ERROR_REPORT,
                payload: { msg: "Error al ejecutar el reporte", category: "alerta-error" }
            });
            throw error;
        }
    };

    const value = useMemo(
        () => ({
            reports: state.reports,
            form: state.form,
            error: state.error,
            report: state.report,
            message: state.message,
            searchreports: state.searchreports,
            reportname_ok: state.reportname_ok,
            urlDoc: state.urlDoc,
            reportResult: state.reportResult,
            showForm,
            getReports,
            getReport,
            createReport,
            updateReport,
            deleteReport,
            selectReport,
            deselectReport,
            searchReports,
            validateReportName,
            resetMessage,
            selectOnlyReport,
            executeReport,
            executeReportWithParams,
            showError
        }),
        [state] // Solo se recalcula cuando state cambia
    );

    return (
        <reportContext.Provider value={value}>
            {props.children}
        </reportContext.Provider>
    );
};

export default ReportState;