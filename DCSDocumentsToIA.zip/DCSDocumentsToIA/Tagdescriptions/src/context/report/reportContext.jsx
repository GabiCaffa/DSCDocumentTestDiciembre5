// tagdescriptions/src/context/report/reportContext.jsx
import {createContext} from 'react'

const reportContext = createContext();

export default reportContext;