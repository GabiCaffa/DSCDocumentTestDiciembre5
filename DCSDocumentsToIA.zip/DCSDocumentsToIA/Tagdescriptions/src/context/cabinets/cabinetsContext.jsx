import { createContext } from "react";

const CabinetsContext = createContext();

export default CabinetsContext;