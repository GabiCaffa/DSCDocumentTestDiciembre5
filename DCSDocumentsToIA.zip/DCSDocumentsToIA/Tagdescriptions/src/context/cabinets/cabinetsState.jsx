// tagdescriptions/src/context/cabinets/cabinetsState.jsx
import React, { useReducer, useMemo, useRef, useCallback } from 'react';
import imageCompression from 'browser-image-compression';
import cabinetsReducer from './cabinetsReducer';
import CabinetsContext from './cabinetsContext';

import {
    SHOW_FORM_CABINET,
    CREATE_CABINET,
    GET_CABINETS,
    GET_CABINET,
    GET_CABINETBYNAME,
    DELETE_CABINET,
    UPDATE_CABINETS,
    GET_AREAS,
    SHOW_ERROR_CABINET,
    UPLOAD_FILE_CABINETS_SUCCESS,
    DELETE_FILE_CABINETS,
    RESET_MESSAGE_CABINET,
    DESELECT_CABINET
} from '../../types/index';

import axiosClient from '../../config/axios';

const CabinetState = ({ children }) => {

    const initialState = {
        cabinets: [],
        cabinetSelected: null,
        form: false,
        message: null,
        areas: [],
        error: false
    };

    const [state, dispatch] = useReducer(cabinetsReducer, initialState);

    const cache = useRef({
        cabinets: null,
        areas: null,
        lastFetchCabinets: null,
        lastFetchAreas: null,
        assetId: null
    });

    const fetchingCabinets = useRef(null);
    const fetchingAreas = useRef(false);

    const showForm = useCallback(() => {
        dispatch({ type: SHOW_FORM_CABINET });
    }, []);

    const createCabinet = useCallback(async cabinet => {
        try {
            const result = await axiosClient.post('/api/cabinets', cabinet);
            
            // Invalidar caché
            cache.current.cabinets = null;
            cache.current.lastFetchCabinets = null;
            
            dispatch({
                type: CREATE_CABINET,
                payload: result.data
            });
        } catch (error) {
            const alert = {
                msg: error.response.data.msg,
                category: 'alerta-error'
            };
            dispatch({
                type: SHOW_ERROR_CABINET,
                payload: alert
            });
        }
    }, []);

    const getAreas = useCallback(async (forceRefresh = false) => {
        const now = Date.now();
        const cacheValid = cache.current.lastFetchAreas && 
                          (now - cache.current.lastFetchAreas < 5 * 60 * 1000);

        if (!forceRefresh && cacheValid && cache.current.areas) {
            dispatch({
                type: GET_AREAS,
                payload: cache.current.areas
            });
            return;
        }

        if (fetchingAreas.current) {
            return;
        }

        fetchingAreas.current = true;

        try {
            const result = await axiosClient.get('/api/areas');
            
            cache.current.areas = result.data.areas;
            cache.current.lastFetchAreas = now;

            dispatch({
                type: GET_AREAS,
                payload: result.data.areas
            });
        } catch (error) {
            console.log(error);
        } finally {
            fetchingAreas.current = false;
        }
    }, []);

    const getCabinets = useCallback(async (assetId, forceRefresh = false) => {
        if (!assetId) return;

        const now = Date.now();
        const cacheValid = cache.current.lastFetchCabinets && 
                          cache.current.assetId === assetId &&
                          (now - cache.current.lastFetchCabinets < 5 * 60 * 1000);

        if (!forceRefresh && cacheValid && cache.current.cabinets) {
            dispatch({
                type: GET_CABINETS,
                payload: cache.current.cabinets
            });
            return;
        }

        if (fetchingCabinets.current === assetId) {
            return;
        }

        fetchingCabinets.current = assetId;

        try {
            const result = await axiosClient.get('/api/cabinets', { params: { assetId } });
            
            cache.current.cabinets = result.data.cabinets;
            cache.current.lastFetchCabinets = now;
            cache.current.assetId = assetId;

            dispatch({
                type: GET_CABINETS,
                payload: result.data.cabinets
            });
        } catch (error) {
            console.log(error);
        } finally {
            fetchingCabinets.current = null;
        }
    }, []);

    const getCabinet = useCallback(async id => {
        try {
            const result = await axiosClient.get(`api/cabinets/${id}`);
            dispatch({
                type: GET_CABINET,
                payload: result.data.cabinet
            });
        } catch (error) {
            console.log(error);
        }
    }, []);

    const getCabinetbyName = useCallback(async cabinetname => {
        try {
            const result = await axiosClient.get(`api/cabinets/cabinetname/${cabinetname}`);
            dispatch({
                type: GET_CABINETBYNAME,
                payload: result.data.cabinet
            });
        } catch (error) {
            console.log(error);
        }
    }, []);

    const deleteCabinet = useCallback(async (id) => {
        try {
            await axiosClient.delete(`/api/cabinets/${id}`);
            
            // Invalidar caché
            cache.current.cabinets = null;
            cache.current.lastFetchCabinets = null;

            dispatch({
                type: DELETE_CABINET,
                payload: id
            });
        } catch (error) {
            const alert = {
                msg: error.response.data.msg,
                category: 'alerta-error'
            };
            dispatch({
                type: SHOW_ERROR_CABINET,
                payload: alert
            });
        }
    }, []);

    const selectCabinet = useCallback((cabinetID) => {
        getCabinet(cabinetID);
    }, [getCabinet]);

    const selectCabinetbyName = useCallback((cabinetName) => {
        getCabinetbyName(cabinetName);
    }, [getCabinetbyName]);

    const uploadFileCabinet = useCallback(async (cabinet, files) => {
        try {
            const options = {
                maxSizeMB: 1,
                maxWidthOrHeight: 1000,
                useWebWorker: true
            };

            for (let i = 0; i < files.length; i++) {
                const compressedFile = await imageCompression(files[i], options);
                const formData = new FormData();
                formData.append('cabinetsFiles', compressedFile);
                const result = await axiosClient.post(`api/cabinetfiles/${cabinet._id}`, formData);
                uploadFileCabinetSuccess(result.data.cabinet);
            }
        } catch (error) {
            const alert = {
                msg: error.response.data.msg,
                category: 'alerta-error'
            };
            dispatch({
                type: SHOW_ERROR_CABINET,
                payload: alert
            });
        }
    }, []);

    const uploadFileCabinetSuccess = useCallback((cabinet) => {
        dispatch({
            type: UPLOAD_FILE_CABINETS_SUCCESS,
            payload: cabinet
        });
    }, []);

    const updateCabinet = useCallback(async (cabinet) => {
        try {
            const id = cabinet._id;
            const res = await axiosClient.put(`/api/cabinets/${id}`, cabinet);
            
            // Invalidar caché
            cache.current.cabinets = null;
            cache.current.lastFetchCabinets = null;

            dispatch({
                type: UPDATE_CABINETS,
                payload: res.data.cabinetUpdate
            });
        } catch (error) {
            const alert = {
                msg: error.response.data.msg,
                category: 'alerta-error'
            };
            dispatch({
                type: SHOW_ERROR_CABINET,
                payload: alert
            });
        }
    }, []);

    const resetMessage = useCallback(() => {
        dispatch({ type: RESET_MESSAGE_CABINET });
    }, []);

    const deSelectCabinet = useCallback(() => {
        dispatch({
            type: DESELECT_CABINET,
            payload: null
        });
    }, []);

    const deleteFileCabinet = useCallback(async (idCabinet, fileNameDeleted) => {
        try {
            const res = await axiosClient.delete(`api/cabinetfiles/${idCabinet}`, { params: { fileNameDeleted } });
            dispatch({
                type: DELETE_FILE_CABINETS,
                payload: res.data.cabinetUpdate
            });
        } catch (error) {
            const alert = {
                msg: error.response.data.msg,
                category: 'alerta-error'
            };
            dispatch({
                type: SHOW_ERROR_CABINET,
                payload: alert
            });
        }
    }, []);

    const value = useMemo(
        () => ({
            cabinets: state.cabinets,
            cabinetSelected: state.cabinetSelected,
            form: state.form,
            message: state.message,
            areas: state.areas,
            error: state.error,
            createCabinet,
            getCabinet,
            getCabinetbyName,
            getCabinets,
            deleteCabinet,
            showForm,
            getAreas,
            resetMessage,
            uploadFileCabinet,
            updateCabinet,
            selectCabinet,
            selectCabinetbyName,
            deSelectCabinet,
            deleteFileCabinet
        }),
        [
            state,
            createCabinet,
            getCabinet,
            getCabinetbyName,
            getCabinets,
            deleteCabinet,
            showForm,
            getAreas,
            resetMessage,
            uploadFileCabinet,
            updateCabinet,
            selectCabinet,
            selectCabinetbyName,
            deSelectCabinet,
            deleteFileCabinet
        ]
    );

    return (
        <CabinetsContext.Provider value={value}>
            {children}
        </CabinetsContext.Provider>
    );
};

export default CabinetState;