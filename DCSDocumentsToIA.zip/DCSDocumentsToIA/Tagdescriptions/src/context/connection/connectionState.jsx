// tagdescriptions/src/context/connection/connectionState.jsx
import React, { useReducer, useMemo, useRef, useCallback } from 'react';
import connectionContext from './connectionContext';
import connectionReducer from './connectionReducer';
import {
    CREATE_CONNECTION,
    GET_CONNECTIONS,
    DELETE_CONNECTION,
    SEARCH_CONNECTIONS,
    SHOW_ERROR,
    RESET_MESSAGE
} from '../../types/index';

import axiosClient from '../../config/axios';

const ConnectionState = props => {
    
    const initialState = {
        connections: [],
        connectionsSearch: [],
        message: null,
        error: false,
    };

    const [state, dispatch] = useReducer(connectionReducer, initialState);

    const cache = useRef({
        connections: null,
        lastFetch: null
    });

    const fetchingConnections = useRef(false);

    const createConnection = useCallback(async (connection) => {
        try {
            const res = await axiosClient.post('/api/connections/', connection);
            console.log(res);
            
            // Invalidar caché
            cache.current.connections = null;
            cache.current.lastFetch = null;

            dispatch({
                type: CREATE_CONNECTION,
                payload: res.data.connection
            });
        } catch (error) {
            console.log(error.response.data);
            const alert = {
                msg: error.response.data,
                category: 'alerta-error'
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        }
    }, []);

    const getConnections = useCallback(async (forceRefresh = false) => {
        const now = Date.now();
        const cacheValid = cache.current.lastFetch && 
                          (now - cache.current.lastFetch < 5 * 60 * 1000);

        if (!forceRefresh && cacheValid && cache.current.connections) {
            dispatch({
                type: GET_CONNECTIONS,
                payload: cache.current.connections
            });
            return;
        }

        if (fetchingConnections.current) {
            return;
        }

        fetchingConnections.current = true;

        try {
            const res = await axiosClient.get(`/api/connections/`);
            
            cache.current.connections = res.data.connections;
            cache.current.lastFetch = now;

            dispatch({
                type: GET_CONNECTIONS,
                payload: res.data.connections
            });
        } catch (error) {
            const alert = {
                msg: "hubo un error en el listado de las conexiones",
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        } finally {
            fetchingConnections.current = false;
        }
    }, []);

    const resetMessage = useCallback(() => {
        dispatch({ type: RESET_MESSAGE });
    }, []);

    const showError = useCallback(() => {
        dispatch({ type: SHOW_ERROR });
    }, []);

    const deleteConnection = useCallback(async (idConnection) => {
        try {
            await axiosClient.delete(`/api/connections/${idConnection}`);
            
            // Invalidar caché
            cache.current.connections = null;
            cache.current.lastFetch = null;

            dispatch({
                type: DELETE_CONNECTION,
                payload: idConnection
            });
        } catch (error) {
            const alert = {
                msg: "hubo un error eliminando el nodo de red",
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        }
    }, []);

    const searchConnections = useCallback((text) => {
        dispatch({
            type: SEARCH_CONNECTIONS,
            payload: text
        });
    }, []);

    const value = useMemo(
        () => ({
            connections: state.connections,
            error: state.error,
            connectionsSearch: state.connectionsSearch,
            message: state.message,
            createConnection,
            getConnections,
            resetMessage,
            showError,
            deleteConnection,
            searchConnections
        }),
        [
            state,
            createConnection,
            getConnections,
            resetMessage,
            showError,
            deleteConnection,
            searchConnections
        ]
    );

    return (
        <connectionContext.Provider value={value}>
            {props.children}
        </connectionContext.Provider>
    );
};

export default ConnectionState;