import {createContext} from 'react'

const connectionContext = createContext();

export default connectionContext;