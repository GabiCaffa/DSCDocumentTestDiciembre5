// tagdescriptions/src/context/import/importState.jsx
import React, { useReducer, useMemo, useCallback } from 'react';
import importContext from './importContext';
import importReducer from './importReducer';
import {
    SHOW_ERROR,
    PROCESS_IMPORT_FILE,
    RESET_MESSAGE
} from '../../types/index';

import axiosClient from '../../config/axios';

const ImportState = props => {
    
    const initialState = {
        form: false,
        message: null,
        error: false
    };

    const [state, dispatch] = useReducer(importReducer, initialState);

    const resetMessage = useCallback(() => {
        dispatch({ type: RESET_MESSAGE });
    }, []);

    const processImportFile = useCallback(async (file) => {
        try {
            const formData = new FormData();
            formData.append("fileToProcess", file);
            const res = await axiosClient.post('/api/files', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });
            console.log(res);
            dispatch({
                type: PROCESS_IMPORT_FILE,
                payload: res.data
            });
            const alert = {
                msg: "Se procesó el archivo correctamente",
                category: "alerta-ok"
            };
            console.log(alert);
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        } catch (error) {
            console.log(error.response.data.msg);
            const alert = {
                msg: error.response.data.msg,
                category: "alerta-error"
            };
            dispatch({
                type: SHOW_ERROR,
                payload: alert
            });
        }
    }, []);

    const value = useMemo(
        () => ({
            form: state.form,
            error: state.error,
            message: state.message,
            processImportFile,
            resetMessage
        }),
        [state, processImportFile, resetMessage]
    );

    return (
        <importContext.Provider value={value}>
            {props.children}
        </importContext.Provider>
    );
};

export default ImportState;