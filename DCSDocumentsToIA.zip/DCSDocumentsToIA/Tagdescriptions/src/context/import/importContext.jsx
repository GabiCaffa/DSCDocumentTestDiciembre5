import {createContext} from 'react'

const importContext = createContext();

export default importContext;