// tagdescriptions/src/components/cabinets/Cabinets.jsx
import React, { useContext, useEffect, useRef } from 'react';
import authContext from '../../context/auth/authContext'
import alertContext from '../../context/alerts/alertContext';
import SidebarCabibinets from '../../layout/sidebarCabinets';
import CabinetsContext from '../../context/cabinets/cabinetsContext';
import assetContext from '../../context/asset/assetContext';
import HeaderCabinets from './HeaderCabinets';
import Header from '../../layout/header'
import NewCabinets from './NewCabinets';
import CabinetsList from './CabinetsList';

const Cabinets = () => {

    const cabContext = useContext(CabinetsContext)
    const { form, showForm } = cabContext
    const aContext = useContext(alertContext)
    const { alert } = aContext
    const asContext = useContext(assetContext)
    const { deSelectAsset, asset } = asContext
    const auContext = useContext(authContext)
    const { getUser } = auContext;

    // Usar ref para evitar llamadas múltiples
    const hasInitialized = useRef(false);

    // Efecto inicial - solo se ejecuta una vez al montar
    useEffect(() => {
        if (!hasInitialized.current) {
            deSelectAsset();
            getUser();
            hasInitialized.current = true;
        }
        // eslint-disable-next-line
    }, [])

    // Efecto para manejar cambios en asset - con condición para evitar bucles

/*useEffect(() => {
    // Solo ejecutar si form es false y hay un asset
    if (!form && asset) {
        showForm();
    }
    // eslint-disable-next-line
}, [asset]) // Removido form y showForm de las dependencias
*/
    return (
        <div className="contenedor-app">
            {alert ? (<div className={`alerta ${alert.category}`}>{alert.msg} </div>)
                : null}
            <SidebarCabibinets />

            <div className="seccion-principal">
                <Header />

                <main>
                    <HeaderCabinets />

                    <div className="contenedor-tareas">
                        {form
                            ? (<NewCabinets />)
                            : (<CabinetsList />)
                        }
                    </div>
                </main>
            </div>
        </div>
    )
}

export default Cabinets