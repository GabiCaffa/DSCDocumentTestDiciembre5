// tagdescriptions/src/components/reports/report.jsx
import React, { useContext } from 'react';
import reportContext from "../../context/report/reportContext";
import { confirmAlert } from 'react-confirm-alert';

const Report = ({ report }) => {
    const rContext = useContext(reportContext);
    const { deleteReport, selectReport, showForm } = rContext;

    const editReport = () => {
        selectReport(report._id);
        showForm();
    };

    const deleteReportOnClick = () => {
        deleteReport(report._id);
    };

    const openReportInNewTab = () => {
        // Guardar el ID del reporte en localStorage
        localStorage.setItem('reportId', report._id);
        localStorage.setItem('reportName', report.name);
        
        // Abrir en nueva pestaña directamente a executeReports
        window.open('/executeReports/' + report.name, '_blank');
    };

    const showDialogConfirm = () => {
        confirmAlert({
            title: 'Confirmar',
            message: '¿Estás seguro de eliminar el reporte?',
            buttons: [
                {
                    label: 'Sí',
                    onClick: deleteReportOnClick
                },
                {
                    label: 'No',
                    onClick: () => console.log("Cancelado")
                }
            ]
        });
    };

    // Contar parámetros válidos
    const paramCount = report.parameters && Array.isArray(report.parameters) 
        ? report.parameters.length 
        : 0;

    return (
        <li className="tarea sombra">
            <p><strong>{report.name}</strong></p>
            <p><small>{report.datasource}</small></p>
            
            {paramCount > 0 && (
                <p style={{ fontSize: '0.85em', color: '#666', marginTop: '0.5em' }}>
                     {paramCount} parámetro(s) configurado(s)
                </p>
            )}
            
            <div className="acciones">
                <button 
                    type="button"
                    className="btn btn-terciario"
                    onClick={openReportInNewTab}
                > 
                    Ver Reporte 
                </button>

                <button
                    type="button"
                    className="btn btn-primario"
                    onClick={editReport}
                >
                    Editar
                </button>

                <button
                    type="button"
                    className="btn btn-secundario"
                    onClick={showDialogConfirm}
                >
                    Eliminar
                </button>
            </div>
        </li>
    );
};

export default Report;