// tagdescriptions/src/components/reports/ExecuteReports.jsx
import React, { useEffect, useState, useMemo } from 'react';
import { useParams } from 'react-router-dom';
import {
  Container,
  Paper,
  Typography,
  Button,
  Box,
  Chip,
  Alert,
  CircularProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  Stack,
  TextField,
  InputAdornment,
  IconButton,
  Tooltip,
  Menu,
  MenuItem
} from '@mui/material';
import {
  Download as DownloadIcon,
  Print as PrintIcon,
  FilterList as FilterListIcon,
  Error as ErrorIcon,
  Description as DescriptionIcon,
  Search as SearchIcon,
  Clear as ClearIcon,
  ArrowUpward as ArrowUpwardIcon,
  ArrowDownward as ArrowDownwardIcon
} from '@mui/icons-material';
import axiosClient from '../../config/axios';
import ReportParametersModal from './parametersModalReport';

const ExecuteReports = () => {
    const { nameReport } = useParams();
    const [results, setResults] = useState([]);
    const [loading, setLoading] = useState(true);
    const [columns, setColumns] = useState([]);
    const [error, setError] = useState('');
    const [appliedFilters, setAppliedFilters] = useState(null);
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(25);
    
    const [searchTerm, setSearchTerm] = useState('');
    const [sortColumn, setSortColumn] = useState('');
    const [sortDirection, setSortDirection] = useState('asc');
    const [columnFilters, setColumnFilters] = useState({});
    const [anchorEl, setAnchorEl] = useState(null);
    const [filterColumn, setFilterColumn] = useState('');

    // Estados para el modal
    const [modalOpen, setModalOpen] = useState(false);
    const [reportData, setReportData] = useState(null);
    const [showResults, setShowResults] = useState(false);

    useEffect(() => {
        const loadReportData = async () => {
            try {
                setLoading(true);
                
                // Primero intentar con localStorage (cuando viene desde /reports)
                let reportId = localStorage.getItem('reportId');
                
                if (reportId) {
                    // Caso 1: Viene desde la navegación normal
                    const res = await axiosClient.get(`/api/reports/${reportId}`);
                    const reportArray = res.data.report;
                    const fullReport = Array.isArray(reportArray) && reportArray.length > 0 
                        ? reportArray[0] 
                        : reportArray;
                    
                    setReportData(fullReport);
                    setModalOpen(true);
                    setLoading(false);
                    
                    // Limpiar localStorage después de cargar
                    localStorage.removeItem('reportId');
                    localStorage.removeItem('reportName');
                } else {
                    // Caso 2: Recarga de página - buscar por nombre
                    console.log('Buscando reporte por nombre:', nameReport);
                    const res = await axiosClient.get(`/api/reports/name/${nameReport}`);
                    
                    console.log('Respuesta del backend:', res.data);
                    
                    // Verificar estructura de la respuesta
                    const fullReport = res.data.report || res.data;
                    
                    if (!fullReport) {
                        throw new Error('No se encontró el reporte');
                    }
                    
                    console.log('Reporte encontrado:', fullReport);
                    setReportData(fullReport);
                    setModalOpen(true);
                    setLoading(false);
                }
            } catch (err) {
                console.error('Error cargando datos del reporte:', err);
                console.error('Detalles del error:', err.response?.data);
                setError('Error al cargar el reporte: ' + (err.response?.data?.msg || err.message));
                setLoading(false);
            }
        };

        loadReportData();
    }, [nameReport]);

    const executeReportDirectly = async () => {
        try {
            setLoading(true);
            setShowResults(false);
            
            const res = await axiosClient.get(`/api/reports/execute/${nameReport}`);
            const reportResult = res.data.result;

            if (reportResult && reportResult.length > 0) {
                const dynamicColumns = Object.keys(reportResult[0]);
                setColumns(dynamicColumns);
                setResults(reportResult);
            } else {
                setResults([]);
                setColumns([]);
            }

            setShowResults(true);
            setLoading(false);
        } catch (err) {
            handleExecutionError(err);
        }
    };

    const handleExecuteReport = async (paramValues, withFilters) => {
        console.log('Ejecutando reporte con:', { paramValues, withFilters });
        setModalOpen(false);
        setLoading(true);
        setShowResults(false);
        
        try {
            let reportResult;
            
            if (withFilters && Object.keys(paramValues).length > 0) {
                const paramsWithLabels = {};
                if (reportData && reportData.parameters) {
                    reportData.parameters.forEach(param => {
                        if (paramValues[param.name]) {
                            paramsWithLabels[param.name] = {
                                value: paramValues[param.name],
                                label: param.label || param.name
                            };
                        }
                    });
                }
                setAppliedFilters(paramsWithLabels);
                
                const res = await axiosClient.post(`/api/reports/execute/${nameReport}`, {
                    parameters: paramValues
                });
                reportResult = res.data.result;
            } else {
                setAppliedFilters(null);
                const res = await axiosClient.get(`/api/reports/execute/${nameReport}`);
                reportResult = res.data.result;
            }

            if (reportResult && reportResult.length > 0) {
                const dynamicColumns = Object.keys(reportResult[0]);
                setColumns(dynamicColumns);
                setResults(reportResult);
            } else {
                setResults([]);
                setColumns([]);
            }

            setShowResults(true);
            setLoading(false);
        } catch (err) {
            handleExecutionError(err);
        }
    };

    const handleExecutionError = (err) => {
        console.error('Error ejecutando reporte:', err);
        
        let errorMessage = 'Error al ejecutar el reporte';
        
        if (err.response?.data?.error) {
            const sqlError = err.response.data.error;
            
            if (sqlError.includes('Invalid column name')) {
                const columnMatch = sqlError.match(/Invalid column name '(.+?)'/);
                const columnName = columnMatch ? columnMatch[1] : 'desconocida';
                errorMessage = `Error: La columna "${columnName}" no existe en la base de datos.\n\nVerifica que el "Campo SQL" del parámetro sea correcto.`;
            } else if (sqlError.includes('Incorrect syntax')) {
                errorMessage = `Error de sintaxis SQL.\n\nRevisa la configuración de los parámetros.`;
            } else {
                errorMessage = `Error SQL: ${sqlError}`;
            }
        } else if (err.response?.data?.msg) {
            errorMessage = err.response.data.msg;
        } else if (err.message) {
            errorMessage = err.message;
        }
        
        setError(errorMessage);
        setLoading(false);
    };

    const filteredAndSortedResults = useMemo(() => {
        let filtered = [...results];

        if (searchTerm) {
            filtered = filtered.filter(row =>
                columns.some(col => {
                    const value = row[col];
                    return value && value.toString().toLowerCase().includes(searchTerm.toLowerCase());
                })
            );
        }

        Object.entries(columnFilters).forEach(([col, filterValue]) => {
            if (filterValue) {
                filtered = filtered.filter(row => {
                    const value = row[col];
                    return value && value.toString().toLowerCase().includes(filterValue.toLowerCase());
                });
            }
        });

        if (sortColumn) {
            filtered.sort((a, b) => {
                const aVal = a[sortColumn] || '';
                const bVal = b[sortColumn] || '';
                
                if (aVal < bVal) return sortDirection === 'asc' ? -1 : 1;
                if (aVal > bVal) return sortDirection === 'asc' ? 1 : -1;
                return 0;
            });
        }

        return filtered;
    }, [results, searchTerm, columnFilters, sortColumn, sortDirection, columns]);

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(parseInt(event.target.value, 10));
        setPage(0);
    };

    const handleSort = (column) => {
        if (sortColumn === column) {
            setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
        } else {
            setSortColumn(column);
            setSortDirection('asc');
        }
    };

    const handleOpenColumnFilter = (event, column) => {
        setAnchorEl(event.currentTarget);
        setFilterColumn(column);
    };

    const handleCloseColumnFilter = () => {
        setAnchorEl(null);
        setFilterColumn('');
    };

    const handleColumnFilterChange = (value) => {
        setColumnFilters(prev => ({
            ...prev,
            [filterColumn]: value
        }));
        setPage(0);
    };

    const clearAllFilters = () => {
        setSearchTerm('');
        setColumnFilters({});
        setSortColumn('');
        setSortDirection('asc');
        setPage(0);
    };

    const exportToCSV = () => {
        const headers = columns.join(';');
        const rows = filteredAndSortedResults.map(row => 
            columns.map(col => row[col] || '').join(';')
        );
        const csv = [headers, ...rows].join('\n');
        
        const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `reporte_${nameReport}_${new Date().toISOString().split('T')[0]}.csv`;
        link.click();
    };

    if (modalOpen && reportData) {
        return (
            <Box sx={{ 
                height: '100vh', 
                display: 'flex', 
                alignItems: 'center', 
                justifyContent: 'center',
                bgcolor: 'grey.50'
            }}>
                <ReportParametersModal
                    open={modalOpen}
                    onClose={() => {
                        setModalOpen(false);
                        window.close();
                    }}
                    report={reportData}
                    onExecute={handleExecuteReport}
                />
            </Box>
        );
    }

    if (loading) {
        return (
            <Box sx={{ 
                display: 'flex', 
                flexDirection: 'column',
                alignItems: 'center', 
                justifyContent: 'center', 
                minHeight: '100vh',
                gap: 3
            }}>
                <CircularProgress size={60} thickness={4} />
                <Typography variant="h6" color="text.secondary">
                    Cargando reporte...
                </Typography>
            </Box>
        );
    }

    if (error) {
        return (
            <Container maxWidth="md" sx={{ py: 6 }}>
                <Alert 
                    severity="error" 
                    icon={<ErrorIcon sx={{ fontSize: '2rem' }} />}
                    sx={{ 
                        fontSize: '1.1rem',
                        py: 3,
                        '& .MuiAlert-message': { width: '100%' }
                    }}
                >
                    <Typography variant="h6" fontWeight={600} gutterBottom>
                        Error al ejecutar el reporte
                    </Typography>
                    <Box 
                        component="pre" 
                        sx={{ 
                            whiteSpace: 'pre-wrap', 
                            fontFamily: 'monospace',
                            fontSize: '0.95rem',
                            mt: 2,
                            mb: 2
                        }}
                    >
                        {error}
                    </Box>
                    <Button 
                        variant="contained" 
                        color="error"
                        onClick={() => window.close()}
                        sx={{ mt: 2 }}
                    >
                        Cerrar ventana
                    </Button>
                </Alert>
            </Container>
        );
    }

    if (!showResults) {
        return null;
    }

    const paginatedResults = filteredAndSortedResults.slice(
        page * rowsPerPage, 
        page * rowsPerPage + rowsPerPage
    );

    const activeFiltersCount = Object.values(columnFilters).filter(v => v).length + (searchTerm ? 1 : 0);

    return (
        <Box sx={{ 
            height: '100vh', 
            display: 'flex', 
            flexDirection: 'column',
            overflow: 'hidden',
            bgcolor: 'grey.50'
        }}>
            {/* Header Centrado */}
            <Paper 
                elevation={1} 
                sx={{ 
                    borderRadius: 0,
                    borderBottom: '1px solid',
                    borderColor: 'grey.300',
                    py: 2.5,
                    px: 3
                }}
            >
                <Box sx={{ textAlign: 'center' }}>
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 1.5, mb: 1 }}>
                        <DescriptionIcon sx={{ fontSize: '1.8rem', color: 'text.secondary' }} />
                        <Typography variant="h5" fontWeight={600}>
                            {nameReport}
                        </Typography>
                    </Box>
                    <Typography variant="body2" color="text.secondary" mb={2}>
                        Total de registros: <Typography component="span" fontWeight={600} color="text.primary">{results.length}</Typography>
                        {filteredAndSortedResults.length !== results.length && (
                            <Typography component="span" color="primary.main" ml={1}>
                                · Mostrando {filteredAndSortedResults.length} filtrados
                            </Typography>
                        )}
                    </Typography>
                    
                    {appliedFilters && Object.keys(appliedFilters).length > 0 && (
                        <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap justifyContent="center">
                            {Object.entries(appliedFilters).map(([key, filterData]) => {
                                if (filterData && typeof filterData === 'object' && filterData.label && filterData.value) {
                                    const displayValue = Array.isArray(filterData.value) 
                                        ? filterData.value.join(', ') 
                                        : filterData.value;
                                    return (
                                        <Chip 
                                            key={key} 
                                            label={`${filterData.label}: ${displayValue}`}
                                            variant="outlined"
                                            sx={{ 
                                                fontSize: '0.95rem',
                                                height: '36px',
                                                px: 1,
                                                borderColor: 'grey.400',
                                                bgcolor: 'white',
                                                '& .MuiChip-label': {
                                                    px: 1.5
                                                }
                                            }}
                                        />
                                    );
                                }
                                return null;
                            })}
                        </Stack>
                    )}
                </Box>
            </Paper>

            {/* Resto del código igual... */}
            <Paper 
                elevation={0} 
                sx={{ 
                    px: 2, 
                    py: 1.5,
                    borderBottom: '1px solid',
                    borderColor: 'grey.300',
                    bgcolor: 'white'
                }}
            >
                <Stack direction="row" spacing={1.5} alignItems="center" justifyContent="center" flexWrap="wrap">
                    <TextField
                        placeholder="Buscar en todos los campos..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        size="small"
                        sx={{ 
                            width: '400px',
                            '& .MuiInputBase-root': { 
                                bgcolor: 'white',
                                fontSize: '0.9rem',
                                height: '36px'
                            }
                        }}
                        InputProps={{
                            startAdornment: (
                                <InputAdornment position="start">
                                    <SearchIcon sx={{ color: 'text.secondary', fontSize: '1.2rem' }} />
                                </InputAdornment>
                            ),
                            endAdornment: searchTerm && (
                                <InputAdornment position="end">
                                    <IconButton size="small" onClick={() => setSearchTerm('')}>
                                        <ClearIcon fontSize="small" />
                                    </IconButton>
                                </InputAdornment>
                            )
                        }}
                    />

                    {activeFiltersCount > 0 && (
                        <Button
                            variant="outlined"
                            size="small"
                            startIcon={<ClearIcon />}
                            onClick={clearAllFilters}
                            sx={{ 
                                borderColor: 'grey.400',
                                color: 'text.primary',
                                fontSize: '0.8rem',
                                height: '36px',
                                minWidth: 'auto',
                                px: 2
                            }}
                        >
                            Limpiar ({activeFiltersCount})
                        </Button>
                    )}
                    
                    <Button
                        variant="outlined"
                        size="small"
                        startIcon={<DownloadIcon />}
                        onClick={exportToCSV}
                        sx={{ 
                            borderColor: 'grey.400',
                            color: 'text.primary',
                            fontSize: '0.8rem',
                            height: '36px',
                            minWidth: 'auto',
                            px: 2
                        }}
                    >
                        CSV
                    </Button>
                    
                    <Button
                        variant="outlined"
                        size="small"
                        startIcon={<PrintIcon />}
                        onClick={() => window.print()}
                        sx={{ 
                            borderColor: 'grey.400',
                            color: 'text.primary',
                            fontSize: '0.8rem',
                            height: '36px',
                            minWidth: 'auto',
                            px: 2
                        }}
                    >
                        Imprimir
                    </Button>
                </Stack>
            </Paper>

            <Box sx={{ flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
                <TableContainer sx={{ flex: 1, overflow: 'auto' }}>
                    <Table stickyHeader size="small">
                        <TableHead>
                            <TableRow>
                                {columns.map((col) => (
                                    <TableCell 
                                        key={col}
                                        sx={{ 
                                            fontWeight: 600,
                                            fontSize: '0.85rem',
                                            bgcolor: 'grey.100',
                                            py: 1.2,
                                            borderBottom: '2px solid',
                                            borderColor: 'grey.300',
                                            color: 'text.primary',
                                            cursor: 'pointer',
                                            userSelect: 'none',
                                            whiteSpace: 'nowrap',
                                            '&:hover': {
                                                bgcolor: 'grey.200'
                                            }
                                        }}
                                    >
                                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
                                            <Box 
                                                onClick={() => handleSort(col)}
                                                sx={{ display: 'flex', alignItems: 'center', gap: 0.5, flex: 1 }}
                                            >
                                                <span>{col}</span>
                                                {sortColumn === col && (
                                                    sortDirection === 'asc' 
                                                        ? <ArrowUpwardIcon sx={{ fontSize: '0.9rem' }} /> 
                                                        : <ArrowDownwardIcon sx={{ fontSize: '0.9rem' }} />
                                                )}
                                            </Box>
                                            <Tooltip title="Filtrar columna">
                                                <IconButton 
                                                    size="small"
                                                    onClick={(e) => handleOpenColumnFilter(e, col)}
                                                    sx={{ 
                                                        p: 0.3,
                                                        color: columnFilters[col] ? 'primary.main' : 'text.secondary'
                                                    }}
                                                >
                                                    <FilterListIcon sx={{ fontSize: '0.9rem' }} />
                                                </IconButton>
                                            </Tooltip>
                                        </Box>
                                    </TableCell>
                                ))}
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {paginatedResults.map((row, index) => (
                                <TableRow 
                                    key={row.id || index}
                                    hover
                                    sx={{ 
                                        '&:nth-of-type(odd)': { bgcolor: 'grey.50' },
                                        '&:hover': { bgcolor: 'grey.100' }
                                    }}
                                >
                                    {columns.map((col) => (
                                        <TableCell 
                                            key={col}
                                            sx={{ 
                                                fontSize: '0.8rem', 
                                                py: 1,
                                                color: 'text.primary',
                                                whiteSpace: 'nowrap'
                                            }}
                                        >
                                            {row[col]}
                                        </TableCell>
                                    ))}
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>

                <Box sx={{ 
                    borderTop: '1px solid',
                    borderColor: 'grey.300',
                    bgcolor: 'white',
                    py: 1
                }}>
                    <Box sx={{ 
                        display: 'flex', 
                        justifyContent: 'center',
                        pr: 12
                    }}>
                        <TablePagination
                            component="div"
                            count={filteredAndSortedResults.length}
                            page={page}
                            onPageChange={handleChangePage}
                            rowsPerPage={rowsPerPage}
                            onRowsPerPageChange={handleChangeRowsPerPage}
                            rowsPerPageOptions={[10, 25, 50, 100, 200]}
                            labelRowsPerPage="Filas:"
                            labelDisplayedRows={({ from, to, count }) => `${from}-${to} de ${count}`}
                            sx={{
                                '& .MuiTablePagination-selectLabel, & .MuiTablePagination-displayedRows': {
                                    fontSize: '0.85rem',
                                    color: 'text.secondary',
                                    mb: 0
                                },
                                '& .MuiTablePagination-select': {
                                    fontSize: '0.85rem'
                                },
                                '& .MuiTablePagination-toolbar': {
                                    minHeight: '48px',
                                    py: 0
                                }
                            }}
                        />
                    </Box>
                </Box>
            </Box>

            <Menu
                anchorEl={anchorEl}
                open={Boolean(anchorEl)}
                onClose={handleCloseColumnFilter}
                PaperProps={{
                    sx: { p: 2, minWidth: '250px' }
                }}
            >
                <Typography variant="subtitle2" fontWeight={600} mb={1} fontSize="0.85rem">
                    Filtrar: {filterColumn}
                </Typography>
                <TextField
                    fullWidth
                    size="small"
                    placeholder="Escribe para filtrar..."
                    value={columnFilters[filterColumn] || ''}
                    onChange={(e) => handleColumnFilterChange(e.target.value)}
                    autoFocus
                    sx={{ '& .MuiInputBase-root': { fontSize: '0.85rem' } }}
                    InputProps={{
                        endAdornment: columnFilters[filterColumn] && (
                            <InputAdornment position="end">
                                <IconButton 
                                    size="small" 
                                    onClick={() => handleColumnFilterChange('')}
                                >
                                    <ClearIcon fontSize="small" />
                                </IconButton>
                            </InputAdornment>
                        )
                    }}
                />
            </Menu>
        </Box>
    );
};

export default ExecuteReports;