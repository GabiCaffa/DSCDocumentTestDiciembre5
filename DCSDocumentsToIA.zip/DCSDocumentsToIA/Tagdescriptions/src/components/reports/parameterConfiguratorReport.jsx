// tagdescriptions/src/components/reports/ParameterConfigurator.jsx
import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Box,
  Button,
  TextField,
  MenuItem,
  FormControlLabel,
  Checkbox,
  Card,
  CardContent,
  Grid,
  Typography,
  IconButton,
  Tooltip,
  Alert,
  Divider,
  Chip,
  Paper,
  Stack
} from '@mui/material';
import {
  Delete as DeleteIcon,
  Add as AddIcon,
  Help as HelpIcon,
  Info as InfoIcon
} from '@mui/icons-material';

const ParameterConfigurator = ({ parameters = [], onChange }) => {
  const [params, setParams] = useState([]);
  const onChangeRef = useRef(onChange);
  
  useEffect(() => {
    onChangeRef.current = onChange;
  }, [onChange]);

  useEffect(() => {
    if (Array.isArray(parameters)) {
      setParams(parameters);
    }
  }, [parameters]);

  const addParameter = () => {
    const newParam = {
      name: '',
      label: '',
      type: 'text',
      sqlField: '',
      operator: '=',
      required: false,
      options: [],
      defaultValue: ''
    };
    const updated = [...params, newParam];
    setParams(updated);
    setTimeout(() => onChangeRef.current(updated), 0);
  };

  const removeParameter = (index) => {
    const updated = params.filter((_, i) => i !== index);
    setParams(updated);
    setTimeout(() => onChangeRef.current(updated), 0);
  };

  const updateParameter = useCallback((index, field, value) => {
    setParams(prevParams => {
      const updated = [...prevParams];
      updated[index] = { ...updated[index], [field]: value };
      
      if (field === 'type' || field === 'required') {
        setTimeout(() => onChangeRef.current(updated), 0);
      } else {
        setTimeout(() => onChangeRef.current(updated), 500);
      }
      
      return updated;
    });
  }, []);

  const addOption = (paramIndex) => {
    setParams(prevParams => {
      const updated = [...prevParams];
      if (!Array.isArray(updated[paramIndex].options)) {
        updated[paramIndex].options = [];
      }
      updated[paramIndex].options.push({ label: '', value: '' });
      setTimeout(() => onChangeRef.current(updated), 0);
      return updated;
    });
  };

  const removeOption = (paramIndex, optionIndex) => {
    setParams(prevParams => {
      const updated = [...prevParams];
      updated[paramIndex].options = updated[paramIndex].options.filter((_, i) => i !== optionIndex);
      setTimeout(() => onChangeRef.current(updated), 0);
      return updated;
    });
  };

  const updateOption = useCallback((paramIndex, optionIndex, field, value) => {
    setParams(prevParams => {
      const updated = [...prevParams];
      if (!Array.isArray(updated[paramIndex].options)) {
        updated[paramIndex].options = [];
      }
      updated[paramIndex].options[optionIndex] = {
        ...updated[paramIndex].options[optionIndex],
        [field]: value
      };
      setTimeout(() => onChangeRef.current(updated), 500);
      return updated;
    });
  }, []);

  return (
    <Box sx={{ my: 4 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <Typography variant="h5" fontWeight={600}>
            Configuración de Parámetros
          </Typography>
          <Tooltip title="Los parámetros permiten filtrar los datos antes de ejecutar la query en el servidor">
            <HelpIcon sx={{ color: 'text.secondary', fontSize: '1.2rem', cursor: 'help' }} />
          </Tooltip>
        </Box>
        <Button 
          variant="outlined" 
          startIcon={<AddIcon />} 
          onClick={addParameter}
          size="large"
          sx={{ 
            fontSize: '0.95rem', 
            px: 3, 
            py: 1.2,
            borderColor: 'grey.400',
            color: 'text.primary',
            '&:hover': {
              borderColor: 'grey.600',
              bgcolor: 'grey.50'
            }
          }}
        >
          Agregar Parámetro
        </Button>
      </Box>

      {params.length === 0 && (
        <Alert 
          severity="info" 
          variant="outlined"
          icon={<InfoIcon sx={{ fontSize: '1.3rem' }} />}
          sx={{ mb: 3, fontSize: '1rem', py: 2 }}
        >
          Agrega parámetros para permitir que los usuarios filtren los datos antes de ejecutar el reporte. 
        </Alert>
      )}

      <Stack spacing={3}>
        {params.map((param, paramIndex) => (
          <Card key={paramIndex} elevation={2} sx={{ borderRadius: 2, border: '1px solid', borderColor: 'grey.200' }}>
            <CardContent sx={{ p: 3 }}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Typography variant="h6" fontWeight={600}>
                    Parámetro {paramIndex + 1}
                  </Typography>
                  {param.name && (
                    <Chip 
                      label={param.name} 
                      size="medium"
                      variant="outlined"
                      sx={{ 
                        borderColor: 'grey.400',
                        bgcolor: 'white',
                        color: 'text.primary'
                      }}
                    />
                  )}
                </Box>
                <IconButton 
                  color="error" 
                  onClick={() => removeParameter(paramIndex)}
                  size="large"
                >
                  <DeleteIcon />
                </IconButton>
              </Box>

              <Grid container spacing={3}>
                <Grid item xs={12} md={6}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mb: 1 }}>
                    <Typography variant="subtitle1" fontWeight={600} fontSize="1rem">
                      Nombre (ID interno)
                    </Typography>
                    <Tooltip title="Identificador único sin espacios, ej: fecha_desde">
                      <HelpIcon sx={{ fontSize: '1rem', color: 'text.secondary', cursor: 'help' }} />
                    </Tooltip>
                  </Box>
                  <TextField
                    fullWidth
                    placeholder="fecha_desde"
                    value={param.name || ''}
                    onChange={(e) => updateParameter(paramIndex, 'name', e.target.value)}
                    error={param.name && !/^[a-z0-9_]+$/i.test(param.name)}
                    helperText="Sin espacios, usar guiones bajos (_)"
                    sx={{ '& .MuiInputBase-root': { fontSize: '1rem', minHeight: '52px' } }}
                  />
                </Grid>

                <Grid item xs={12} md={6}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mb: 1 }}>
                    <Typography variant="subtitle1" fontWeight={600} fontSize="1rem">
                      Etiqueta (visible al usuario)
                    </Typography>
                    <Tooltip title="Texto que verá el usuario en el formulario">
                      <HelpIcon sx={{ fontSize: '1rem', color: 'text.secondary', cursor: 'help' }} />
                    </Tooltip>
                  </Box>
                  <TextField
                    fullWidth
                    placeholder="Fecha desde"
                    value={param.label || ''}
                    onChange={(e) => updateParameter(paramIndex, 'label', e.target.value)}
                    sx={{ '& .MuiInputBase-root': { fontSize: '1rem', minHeight: '52px' } }}
                  />
                </Grid>

                <Grid item xs={12} md={4}>
                  <Typography variant="subtitle1" fontWeight={600} mb={1} fontSize="1rem">
                    Tipo de campo
                  </Typography>
                  <TextField
                    fullWidth
                    select
                    value={param.type || 'text'}
                    onChange={(e) => updateParameter(paramIndex, 'type', e.target.value)}
                    sx={{ '& .MuiInputBase-root': { fontSize: '1rem', minHeight: '52px' } }}
                  >
                    <MenuItem value="text" sx={{ fontSize: '1rem', py: 1.5 }}>Texto</MenuItem>
                    <MenuItem value="number" sx={{ fontSize: '1rem', py: 1.5 }}>Número</MenuItem>
                    <MenuItem value="date" sx={{ fontSize: '1rem', py: 1.5 }}>Fecha</MenuItem>
                    <MenuItem value="select" sx={{ fontSize: '1rem', py: 1.5 }}>Selección única</MenuItem>
                    <MenuItem value="multiselect" sx={{ fontSize: '1rem', py: 1.5 }}>Selección múltiple</MenuItem>
                  </TextField>
                </Grid>

                <Grid item xs={12} md={4}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mb: 1 }}>
                    <Typography variant="subtitle1" fontWeight={600} fontSize="1rem">
                      Campo SQL
                    </Typography>
                    <Tooltip title="Nombre exacto de la columna en tu base de datos, incluyendo alias">
                      <HelpIcon sx={{ fontSize: '1rem', color: 'text.secondary', cursor: 'help' }} />
                    </Tooltip>
                  </Box>
                  <TextField
                    fullWidth
                    placeholder="m.equipo"
                    value={param.sqlField || ''}
                    onChange={(e) => updateParameter(paramIndex, 'sqlField', e.target.value)}
                    helperText="Ej: m.equipo, t.timestamp_alarm"
                    sx={{ '& .MuiInputBase-root': { fontSize: '1rem', minHeight: '52px' } }}
                  />
                </Grid>

                <Grid item xs={12} md={4}>
                  <Typography variant="subtitle1" fontWeight={600} mb={1} fontSize="1rem">
                    Operador
                  </Typography>
                  <TextField
                    fullWidth
                    select
                    value={param.operator || '='}
                    onChange={(e) => updateParameter(paramIndex, 'operator', e.target.value)}
                    sx={{ '& .MuiInputBase-root': { fontSize: '1rem', minHeight: '52px' } }}
                  >
                    <MenuItem value="=" sx={{ fontSize: '1rem', py: 1.5 }}>=</MenuItem>
                    <MenuItem value="!=" sx={{ fontSize: '1rem', py: 1.5 }}>!=</MenuItem>
                    <MenuItem value=">" sx={{ fontSize: '1rem', py: 1.5 }}>{'>'}</MenuItem>
                    <MenuItem value="<" sx={{ fontSize: '1rem', py: 1.5 }}>{'<'}</MenuItem>
                    <MenuItem value=">=" sx={{ fontSize: '1rem', py: 1.5 }}>{'>='}</MenuItem>
                    <MenuItem value="<=" sx={{ fontSize: '1rem', py: 1.5 }}>{'<='}</MenuItem>
                    <MenuItem value="LIKE" sx={{ fontSize: '1rem', py: 1.5 }}>LIKE</MenuItem>
                    <MenuItem value="IN" sx={{ fontSize: '1rem', py: 1.5 }}>IN</MenuItem>
                    <MenuItem value="BETWEEN" sx={{ fontSize: '1rem', py: 1.5 }}>BETWEEN</MenuItem>
                  </TextField>
                </Grid>

                <Grid item xs={12} md={6}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mb: 1 }}>
                    <Typography variant="subtitle1" fontWeight={600} fontSize="1rem">
                      Valor por defecto (opcional)
                    </Typography>
                    <Tooltip title="Para fechas usa formato YYYY-MM-DD, ej: 2024-01-15">
                      <HelpIcon sx={{ fontSize: '1rem', color: 'text.secondary', cursor: 'help' }} />
                    </Tooltip>
                  </Box>
                  <TextField
                    fullWidth
                    type={param.type === 'date' ? 'date' : param.type === 'number' ? 'number' : 'text'}
                    placeholder={param.type === 'date' ? 'YYYY-MM-DD' : 'Déjalo vacío si no aplica'}
                    value={param.defaultValue || ''}
                    onChange={(e) => updateParameter(paramIndex, 'defaultValue', e.target.value)}
                    InputLabelProps={param.type === 'date' ? { shrink: true } : undefined}
                    sx={{ '& .MuiInputBase-root': { fontSize: '1rem', minHeight: '52px' } }}
                  />
                </Grid>

                <Grid item xs={12} md={6} sx={{ display: 'flex', alignItems: 'flex-end' }}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={param.required || false}
                        onChange={(e) => updateParameter(paramIndex, 'required', e.target.checked)}
                        size="large"
                      />
                    }
                    label={<Typography fontSize="1rem">Campo requerido</Typography>}
                  />
                </Grid>

                {(param.type === 'select' || param.type === 'multiselect') && (
                  <Grid item xs={12}>
                    <Divider sx={{ my: 2 }} />
                    <Paper elevation={0} sx={{ p: 2.5, bgcolor: 'grey.50', border: '1px solid', borderColor: 'grey.200' }}>
                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                        <Typography variant="h6" fontWeight={600}>
                          Opciones
                        </Typography>
                        <Button
                          variant="outlined"
                          size="medium"
                          startIcon={<AddIcon />}
                          onClick={() => addOption(paramIndex)}
                          sx={{ 
                            fontSize: '0.9rem',
                            borderColor: 'grey.400',
                            color: 'text.primary',
                            '&:hover': {
                              borderColor: 'grey.600',
                              bgcolor: 'white'
                            }
                          }}
                        >
                          Agregar opción
                        </Button>
                      </Box>

                      <Stack spacing={1.5}>
                        {param.options && Array.isArray(param.options) && param.options.map((option, optionIndex) => (
                          <Box key={optionIndex} sx={{ display: 'flex', gap: 1.5, alignItems: 'center' }}>
                            <TextField
                              placeholder="Etiqueta (ej: Equipo 1)"
                              value={option.label || ''}
                              onChange={(e) => updateOption(paramIndex, optionIndex, 'label', e.target.value)}
                              sx={{ flex: 1, '& .MuiInputBase-root': { fontSize: '0.95rem', bgcolor: 'white' } }}
                            />
                            <TextField
                              placeholder="Valor (ej: EQ001)"
                              value={option.value || ''}
                              onChange={(e) => updateOption(paramIndex, optionIndex, 'value', e.target.value)}
                              sx={{ flex: 1, '& .MuiInputBase-root': { fontSize: '0.95rem', bgcolor: 'white' } }}
                            />
                            <IconButton
                              color="error"
                              onClick={() => removeOption(paramIndex, optionIndex)}
                            >
                              <DeleteIcon />
                            </IconButton>
                          </Box>
                        ))}

                        {(!param.options || param.options.length === 0) && (
                          <Typography color="text.secondary" textAlign="center" py={2} fontSize="0.95rem">
                            No hay opciones. Haz clic en "Agregar opción"
                          </Typography>
                        )}
                      </Stack>
                    </Paper>
                  </Grid>
                )}
              </Grid>

              <Paper 
                elevation={0} 
                sx={{ 
                  mt: 3, 
                  p: 2, 
                  bgcolor: 'grey.50', 
                  borderLeft: 3, 
                  borderColor: 'grey.400',
                  fontFamily: 'monospace'
                }}
              >
                <Typography variant="caption" fontWeight={600} color="text.secondary" display="block" mb={0.5}>
                  Vista previa SQL:
                </Typography>
                <Typography variant="body1" fontFamily="monospace" fontSize="0.95rem" color="text.primary">
                  {param.sqlField || '[campo]'} {param.operator || '='} {'{valor}'}
                </Typography>
              </Paper>
            </CardContent>
          </Card>
        ))}
      </Stack>

      {params.length === 0 && (
        <Card sx={{ textAlign: 'center', bgcolor: 'grey.50', py: 6, border: '1px solid', borderColor: 'grey.200' }}>
          <Typography color="text.secondary" fontSize="1rem">
            No hay parámetros configurados. Haz clic en "Agregar Parámetro" para empezar.
          </Typography>
        </Card>
      )}
    </Box>
  );
};

export default ParameterConfigurator;