// tagdescriptions/src/components/reports/ReportParametersModal.jsx
import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  TextField,
  MenuItem,
  Grid,
  Typography,
  Box,
  Chip,
  Alert,
  Stack,
  IconButton
} from '@mui/material';
import {
  PlayArrow as PlayArrowIcon,
  FilterList as FilterListIcon,
  Close as CloseIcon,
  InfoOutlined as InfoOutlinedIcon
} from '@mui/icons-material';

const ReportParametersModal = ({ open, onClose, report, onExecute }) => {
  const [paramValues, setParamValues] = useState({});

  useEffect(() => {
    if (report && report.parameters) {
      const initialValues = {};
      report.parameters.forEach(param => {
        initialValues[param.name] = param.defaultValue || '';
      });
      setParamValues(initialValues);
    }
  }, [report]);

  const handleChange = (paramName, value) => {
    setParamValues(prev => ({
      ...prev,
      [paramName]: value
    }));
  };

  const handleExecuteWithFilters = () => {
    // Crear un objeto con metadata de los parámetros para mostrar las etiquetas
    const paramsWithLabels = {};
    if (report && report.parameters) {
      report.parameters.forEach(param => {
        if (paramValues[param.name]) {
          paramsWithLabels[param.name] = {
            value: paramValues[param.name],
            label: param.label || param.name
          };
        }
      });
    }
    
    // Guardar tanto los valores como las etiquetas
    localStorage.setItem('reportParametersWithLabels', JSON.stringify(paramsWithLabels));
    
    onExecute(paramValues, true);
  };

  const handleExecuteWithoutFilters = () => {
    onExecute({}, false);
  };

  const validateRequired = () => {
    if (!report || !report.parameters) return true;
    
    for (const param of report.parameters) {
      if (param.required && (!paramValues[param.name] || paramValues[param.name] === '')) {
        return false;
      }
    }
    return true;
  };

  const renderField = (param) => {
    const value = paramValues[param.name] || '';

    switch (param.type) {
      case 'text':
        return (
          <TextField
            fullWidth
            label={param.label}
            value={value}
            onChange={(e) => handleChange(param.name, e.target.value)}
            variant="outlined"
            size="large"
            sx={{ 
              '& .MuiInputBase-root': { fontSize: '1rem', minHeight: '52px' },
              '& .MuiOutlinedInput-root': {
                '&:hover fieldset': { borderColor: 'grey.500' }
              }
            }}
          />
        );

      case 'number':
        return (
          <TextField
            fullWidth
            type="number"
            label={param.label}
            value={value}
            onChange={(e) => handleChange(param.name, e.target.value)}
            variant="outlined"
            size="large"
            sx={{ 
              '& .MuiInputBase-root': { fontSize: '1rem', minHeight: '52px' },
              '& .MuiOutlinedInput-root': {
                '&:hover fieldset': { borderColor: 'grey.500' }
              }
            }}
          />
        );

      case 'date':
        return (
          <TextField
            fullWidth
            type="date"
            label={param.label}
            value={value}
            onChange={(e) => handleChange(param.name, e.target.value)}
            variant="outlined"
            size="large"
            InputLabelProps={{ shrink: true }}
            sx={{ 
              '& .MuiInputBase-root': { fontSize: '1rem', minHeight: '52px' },
              '& .MuiOutlinedInput-root': {
                '&:hover fieldset': { borderColor: 'grey.500' }
              }
            }}
          />
        );

      case 'select':
        return (
          <TextField
            fullWidth
            select
            label={param.label}
            value={value || ''}
            onChange={(e) => handleChange(param.name, e.target.value)}
            variant="outlined"
            size="large"
            sx={{ 
              '& .MuiInputBase-root': { fontSize: '1rem', minHeight: '52px' },
              '& .MuiOutlinedInput-root': {
                '&:hover fieldset': { borderColor: 'grey.500' }
              }
            }}
          >
            {param.options && param.options.map((option, idx) => (
              <MenuItem key={idx} value={option.value} sx={{ fontSize: '1rem', py: 1.5 }}>
                {option.label}
              </MenuItem>
            ))}
          </TextField>
        );

      case 'multiselect':
        return (
          <TextField
            fullWidth
            select
            label={param.label}
            value={Array.isArray(value) ? value : []}
            onChange={(e) => handleChange(param.name, e.target.value)}
            variant="outlined"
            SelectProps={{
              multiple: true,
              renderValue: (selected) => (
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                  {selected.map((val) => (
                    <Chip 
                      key={val} 
                      label={val} 
                      size="small"
                      variant="outlined"
                      sx={{ borderColor: 'grey.400' }}
                    />
                  ))}
                </Box>
              ),
            }}
            sx={{ 
              '& .MuiInputBase-root': { fontSize: '1rem', minHeight: '52px' },
              '& .MuiOutlinedInput-root': {
                '&:hover fieldset': { borderColor: 'grey.500' }
              }
            }}
          >
            {param.options && param.options.map((option, idx) => (
              <MenuItem key={idx} value={option.value} sx={{ fontSize: '1rem', py: 1.5 }}>
                {option.label}
              </MenuItem>
            ))}
          </TextField>
        );

      default:
        return null;
    }
  };

  if (!report) return null;

  const hasValidParameters = report.parameters && report.parameters.length > 0 && 
    report.parameters.some(p => p.name && p.sqlField && p.type);

  return (
    <Dialog 
      open={open} 
      onClose={onClose} 
      maxWidth="md" 
      fullWidth
      PaperProps={{
        sx: {
          minHeight: '400px',
          borderRadius: 2,
          border: '1px solid',
          borderColor: 'grey.200'
        }
      }}
    >
      <DialogTitle sx={{ 
        display: 'flex', 
        alignItems: 'center', 
        justifyContent: 'space-between',
        fontSize: '1.3rem',
        pb: 2,
        borderBottom: '1px solid',
        borderColor: 'divider'
      }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5 }}>
          <FilterListIcon sx={{ fontSize: '1.5rem', color: 'text.secondary' }} />
          <Box>
            <Typography variant="h6" component="span" fontWeight={600}>
              Configurar Reporte
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
              {report.name}
            </Typography>
          </Box>
        </Box>
        <IconButton onClick={onClose} size="small">
          <CloseIcon />
        </IconButton>
      </DialogTitle>

      <DialogContent sx={{ pt: 3, pb: 2 }}>
        {hasValidParameters ? (
          <Grid container spacing={3} sx={{ mt: 0.5 }}>
            {report.parameters.map((param, index) => (
              <Grid item xs={12} sm={6} key={index}>
                <Box>
                  <Typography variant="subtitle2" fontWeight={600} mb={1} fontSize="0.9rem" color="text.secondary">
                    {param.label}
                    {param.required && (
                      <Typography component="span" color="error" ml={0.5}>*</Typography>
                    )}
                  </Typography>
                  {renderField(param)}
                </Box>
              </Grid>
            ))}
          </Grid>
        ) : (
          <Alert 
            severity="info" 
            variant="outlined"
            icon={<InfoOutlinedIcon sx={{ fontSize: '1.3rem' }} />}
            sx={{ fontSize: '1rem', py: 2 }}
          >
            Este reporte no tiene parámetros válidos configurados.
            Solo puedes ejecutarlo sin filtros o editar el reporte para agregar parámetros.
          </Alert>
        )}
      </DialogContent>

      <DialogActions sx={{ 
        px: 3, 
        py: 2.5, 
        gap: 1.5,
        borderTop: '1px solid',
        borderColor: 'divider',
        bgcolor: 'grey.50'
      }}>
        <Button
          onClick={onClose}
          variant="outlined"
          size="large"
          sx={{ 
            fontSize: '0.95rem', 
            px: 3, 
            py: 1,
            borderColor: 'grey.400',
            color: 'text.primary',
            '&:hover': {
              borderColor: 'grey.600',
              bgcolor: 'grey.100'
            }
          }}
        >
          Cancelar
        </Button>
        <Button
          onClick={handleExecuteWithoutFilters}
          variant="outlined"
          size="large"
          sx={{ 
            fontSize: '0.95rem', 
            px: 3, 
            py: 1,
            borderColor: 'grey.400',
            color: 'text.primary',
            '&:hover': {
              borderColor: 'grey.600',
              bgcolor: 'grey.100'
            }
          }}
        >
          Ejecutar sin filtros
        </Button>
        {hasValidParameters && (
          <Button
            onClick={handleExecuteWithFilters}
            startIcon={<PlayArrowIcon />}
            variant="contained"
            size="large"
            disabled={!validateRequired()}
            sx={{ 
              fontSize: '0.95rem', 
              px: 3, 
              py: 1,
              bgcolor: 'text.primary',
              '&:hover': {
                bgcolor: 'text.secondary'
              }
            }}
          >
            Ejecutar con filtros
          </Button>
        )}
      </DialogActions>
    </Dialog>
  );
};

export default ReportParametersModal;