// tagdescriptions/src/components/reports/newReport.jsx
import React, { Fragment, useState, useContext, useEffect } from 'react';
import reportContext from '../../context/report/reportContext';
import systemContext from '../../context/system/systemContext';
import alertContext from '../../context/alerts/alertContext';
import ParameterConfigurator from './parameterConfiguratorReport';
import 'suneditor/dist/css/suneditor.min.css';

const NewReport = () => {
    const rContext = useContext(reportContext);
    const {
        reportname_ok, message, createReport, report, resetMessage, updateReport, validateReportName,
    } = rContext;

    const sContext = useContext(systemContext);
    const { systemSelected } = sContext;

    const aContext = useContext(alertContext);
    const { showAlert } = aContext;

    const [user, setUser] = useState('');
    const [password, setPassword] = useState('');
    const [name, setName] = useState('');
    const [datasource, setDatasource] = useState('');
    const [query, setQuery] = useState('');
    const [parameters, setParameters] = useState([]);
    const [icon, setIcon] = useState('');
 
    useEffect(() => {
        if (Array.isArray(report) && report.length > 0) {
            const [currentReport] = report;
            setUser(currentReport.user || '');
            setPassword(currentReport.password || '');
            setName(currentReport.name || '');
            setDatasource(currentReport.datasource || '');
            setQuery(currentReport.query || '');
            // Asegurar que parameters es siempre un array válido
            setParameters(Array.isArray(currentReport.parameters) ? currentReport.parameters : []);
        } else {
            setUser('');
            setPassword('');
            setName('');
            setDatasource('');
            setQuery('');
            setParameters([]);
        }
        // eslint-disable-next-line
    }, [report]);

    useEffect(() => {
        if (message) {
            showAlert(message.msg, message.category);
            setIcon(message.category === "alerta-error" ? '-red' : '');
            resetMessage();
        }
        // eslint-disable-next-line
    }, [message]);

    if (!systemSelected) return null;

    const onChangeUser = (e) => setUser(e.target.value);
    const onChangePassword = (e) => setPassword(e.target.value);
    const onChangeName = (e) => setName(e.target.value);
    const onChangeDatasource = (e) => setDatasource(e.target.value);
    const onChangeQuery = (e) => setQuery(e.target.value);

    const onBlurName = () => {
        if (!(report !== null && report.length > 0)) {
            validateReportName(name);
        }
        setIcon('');
    };

    // Función para limpiar parámetros vacíos o inválidos
    const cleanParameters = (params) => {
        if (!Array.isArray(params)) return [];
        
        return params.filter(param => {
            // Filtrar parámetros que tienen los campos obligatorios
            return param.name && 
                   param.name.trim() !== '' && 
                   param.label && 
                   param.label.trim() !== '' && 
                   param.type && 
                   param.sqlField && 
                   param.sqlField.trim() !== '';
        }).map(param => ({
            name: param.name.trim(),
            label: param.label.trim(),
            type: param.type,
            sqlField: param.sqlField.trim(),
            operator: param.operator || '=',
            required: param.required || false,
            options: Array.isArray(param.options) ? param.options : [],
            defaultValue: param.defaultValue || ''
        }));
    };

    const onSubmitReport = (e) => {
        e.preventDefault();

        if (user.trim() === '' || password.trim() === '' || name.trim() === '' || 
            datasource.trim() === '' || query.trim() === '') {
            showAlert('Debe completar todos los campos básicos', 'alerta-error');
            return;
        }

        // Limpiar parámetros antes de enviar
        const cleanedParameters = cleanParameters(parameters);

        console.log('Parámetros limpiados a enviar:', cleanedParameters);

        const newReport = {
            user,
            password,
            name: name.toUpperCase(),
            datasource,
            query,
            parameters: cleanedParameters, // Enviar parámetros limpios
            system: systemSelected._id
        };

        if (report !== null && report.length > 0) {
            newReport._id = report[0]._id;
            updateReport(newReport);
        } else {
            if (reportname_ok === false) {
                showAlert(message?.msg || "El reporte con ese nombre ya existe", "alerta-error");
                resetMessage();
                return;
            }
            createReport(newReport);
        }
    };

    const handleParametersChange = (newParams) => {
        console.log('Parámetros actualizados:', newParams);
        setParameters(newParams);
    };

    return (
        <Fragment>
            <h2>Reporte en el sistema: {systemSelected.name}</h2>
            <div className="formDescriptor">
                <div className="descriptor">
                    <form className="formulario-nuevo-proyecto" onSubmit={onSubmitReport}>
                        
                        <input
                            type="text"
                            className={`input-text${icon}`}
                            placeholder="Nombre del reporte"
                            name="name"
                            value={name}
                            onChange={onChangeName}
                            readOnly={report !== null && report.length > 0}
                            onBlur={onBlurName}
                        />
                        <input
                            type="text"
                            className={`input-text${icon}`}
                            placeholder="Nombre del usuario"
                            name="user"
                            value={user}
                            onChange={onChangeUser}
                        />
                        <input
                            type="password"
                            className={`input-text${icon}`}
                            placeholder="Contraseña del usuario"
                            name="password"
                            value={password}
                            onChange={onChangePassword}
                        />
                        <input
                            type="text"
                            className="input-text"
                            placeholder="Origen de datos (datasource)"
                            name="datasource"
                            value={datasource}
                            onChange={onChangeDatasource}
                        />
                        <textarea
                            className="input-text"
                            placeholder="Consulta (query)"
                            name="query"
                            value={query}
                            onChange={onChangeQuery}
                            rows={4}
                            style={{ resize: 'vertical', fontFamily: 'monospace', fontSize: '14px' }}
                        />

                        {/* Configurador de parámetros */}
                        <ParameterConfigurator
                            parameters={parameters}
                            onChange={handleParametersChange}
                        />

                        <input
                            type="submit"
                            className="btn btn-primario btn-block"
                            value={(report !== null && report.length > 0) ? "Guardar Reporte" : "Agregar Reporte"}
                        />
                    </form>
                </div>             
            </div>
        </Fragment>
    );
};

export default NewReport;