// src/components/tagsdescriptors/tagsDescriptors.jsx
import React, { useContext, useEffect, useRef } from 'react';
import { Alert } from 'antd';
import MainLayout from '../../layout/MainLayout';
import NewTagDescriptor from './newTagDescriptor';
import TagDescriptorList from './tagDescriptorList';
import SearchTagDescriptor from './searchTagDescriptor';
import SidebarDescriptors from '../../layout/sidebarDescriptorsSearch';
import tagDescriptorContext from '../../context/tagdescriptor/tagDescriptorContext';
import systemContext from '../../context/system/systemContext';
import alertContext from '../../context/alerts/alertContext';

const Tagsdescriptors = () => {
    const tContext = useContext(tagDescriptorContext);
    const { form } = tContext;

    const sContext = useContext(systemContext);
    const { deselectSystem } = sContext;

    const aContext = useContext(alertContext);
    const { alert } = aContext;

    const hasLoaded = useRef(false);

    useEffect(() => {
        if (!hasLoaded.current) {
            hasLoaded.current = true;
            deselectSystem();
        }
    }, []);

    return (
        <MainLayout sidebar={<SidebarDescriptors />} sidebarWidth={280}>
            {/* Alert de Ant Design */}
            {alert && (
                <Alert
                    message={alert.msg}
                    type={alert.category === 'alerta-error' ? 'error' : 'success'}
                    closable
                    style={{ marginBottom: '20px' }}
                />
            )}

            {/* Contenido principal */}
            <div style={{ width: '100%' }}>
                <SearchTagDescriptor />
                
                <div style={{ marginTop: '20px' }}>
                    {form ? <NewTagDescriptor /> : <TagDescriptorList />}
                </div>
            </div>
        </MainLayout>
    );
};

export default Tagsdescriptors;