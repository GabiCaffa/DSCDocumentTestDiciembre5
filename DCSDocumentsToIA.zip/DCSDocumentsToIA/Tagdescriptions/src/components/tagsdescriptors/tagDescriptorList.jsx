//tagdescriptions/src/components/tagsdescriptors/tagDescriptorList.jsx
import React, { useEffect, useContext, Fragment, useState, useRef } from 'react';
import systemContext from '../../context/system/systemContext';
import TagDescriptor from './tagDescriptor';
import tagDescriptorContext from '../../context/tagdescriptor/tagDescriptorContext';
import ReactPaginate from 'react-paginate';

const TagDescriptorList = () => {

    const sContext = useContext(systemContext);
    const { systemSelected } = sContext;
    
    const tContext = useContext(tagDescriptorContext);
    const { searchtagdescriptors, getTagsDescriptors } = tContext;

    const lastSystemRef = useRef(null);

    const [pag, setPag] = useState({
        offset: 0,
        perPage: 10,
        currentPage: 0,
        pageCount: 0,
        data: []
    });

    useEffect(() => {
        if (systemSelected && systemSelected._id !== lastSystemRef.current) {
            lastSystemRef.current = systemSelected._id;
            getTagsDescriptors(systemSelected._id);
        }
        // eslint-disable-next-line
    }, [systemSelected]);

    useEffect(() => {
        if (systemSelected && searchtagdescriptors) {
            setPag(prev => ({
                ...prev,
                pageCount: Math.ceil(searchtagdescriptors.length / prev.perPage),
                data: searchtagdescriptors,
                offset: 0,
                currentPage: 0
            }));
        }
        // eslint-disable-next-line
    }, [searchtagdescriptors, systemSelected]);

    if (!systemSelected) {
        return <h2>Seleccione un sistema</h2>;
    }
    
    if (!searchtagdescriptors || searchtagdescriptors.length === 0) {
        return (
            <Fragment>
                <h2>Tags descriptors del sistema: {systemSelected.name}</h2>
                <p>No hay documentos para el sistema seleccionado</p>
            </Fragment>
        );
    }

    const handlePageClick = (e) => {
        const selectedPage = e.selected;
        const offset = selectedPage * pag.perPage;
        setPag(prev => ({
            ...prev,
            currentPage: selectedPage,
            offset: offset
        }));
    };

    return ( 
        <Fragment>
            <h2>Tags descriptors del sistema: {systemSelected.name}</h2>
            <ul>
                {pag.data.slice(pag.offset, pag.offset + pag.perPage).map(tgd => (
                    <TagDescriptor
                        key={tgd._id}
                        tagdescriptor={tgd}
                    />
                ))}
            </ul>
            <div>
                <ReactPaginate
                    previousLabel={"<"}
                    nextLabel={">"}
                    breakLabel={"..."}
                    breakClassName={"break-me"}
                    pageCount={pag.pageCount}
                    marginPagesDisplayed={2}
                    pageRangeDisplayed={5}
                    onPageChange={handlePageClick}
                    containerClassName={"pagination"}
                    subContainerClassName={"pages pagination"}
                    activeClassName={"active"}
                    forcePage={pag.currentPage}
                />
            </div>
        </Fragment>
    );
};
 
export default TagDescriptorList;