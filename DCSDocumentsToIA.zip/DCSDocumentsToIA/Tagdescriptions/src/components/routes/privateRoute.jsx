// tagdescriptions/src/components/routes/privateRoute.jsx
import React, { useContext } from 'react';
import { Navigate } from 'react-router-dom';
import authContext from '../../context/auth/authContext';

const PrivateRoute = ({ children }) => {
    const aContext = useContext(authContext);
    const { authenticated, loading } = aContext;

    // Mientras carga, muestra un spinner
    if (loading) {
        return (
            <div style={{ 
                display: 'flex', 
                justifyContent: 'center', 
                alignItems: 'center', 
                height: '100vh',
                fontSize: '18px',
                color: '#666'
            }}>
                <div>Cargando...</div>
            </div>
        );
    }

    // Si no está autenticado, redirige al login
    return authenticated ? children : <Navigate to="/" replace />;
};

export default PrivateRoute;