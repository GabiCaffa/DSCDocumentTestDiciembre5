//tagdescriptions/src/components/advanceSearch/tagAllDescriptorList.jsx
import React, {useEffect, useContext, Fragment, useState} from 'react';
import TagDescriptor from './tagDescriptorSearch'
import tagDescriptorContext from '../../context/tagdescriptor/tagDescriptorContext';
import systemContext from '../../context/system/systemContext';
import ReactPaginate from 'react-paginate';
import { Link } from 'react-router-dom'

const TagAllDescriptorList = () => {
    const tContext = useContext(tagDescriptorContext)
    const {searchtagdescriptors, getAllTagDescriptor} = tContext
    
    const sContext = useContext(systemContext)
    const {getSystemById} = sContext

    const [pag, setPag] = useState({
        offset: 0,
        perPage: 10,
        currentPage: 0,
        pageCount: 0,
        data: []
    })
    
    const [loadedSystems, setLoadedSystems] = useState(new Set())

    useEffect(() => {
        const listTagsDescriptors = () => {
            getAllTagDescriptor()
        }
        listTagsDescriptors()
        // eslint-disable-next-line
    }, [])

    useEffect(() => {
        setPag({
            ...pag,
            pageCount: Math.ceil(searchtagdescriptors.length / pag.perPage),
            data: searchtagdescriptors,
            offset: 0,
            currentPage: 0
        })
        // eslint-disable-next-line
    }, [searchtagdescriptors])
    
    useEffect(() => {
        const currentPageData = pag.data.slice(pag.offset, pag.offset + pag.perPage)
        
        currentPageData.forEach(tagdescriptor => {
            const systemId = tagdescriptor.system
            // Solo cargar si no está ya cargado
            if (systemId && !loadedSystems.has(systemId)) {
                getSystemById(systemId)
                setLoadedSystems(prev => new Set([...prev, systemId]))
            }
        })
        // eslint-disable-next-line
    }, [pag.offset, pag.data, pag.perPage])

    const handlePageClick = (e) => {
        const selectedPage = e.selected;
        const offset = selectedPage * pag.perPage;
        setPag({
            ...pag,
            currentPage: selectedPage,
            offset: offset
        })
    }

    return ( 
        <Fragment>
            <h2>Buscar Tags descriptors</h2>
            <ul>
                {(searchtagdescriptors.length === 0) ? (
                    <li className="tarea">
                        <p>No hay documentos para mostrar</p>
                    </li>
                ) : (
                    pag.data
                        .slice(pag.offset, pag.offset + pag.perPage)
                        .map((tgd) => (
                            <TagDescriptor
                                tagdescriptor={tgd}
                                key={tgd._id}
                            />
                        ))
                )}
            </ul>
            <div>
                <ReactPaginate
                    previousLabel={"<"}
                    nextLabel={">"}
                    breakLabel={"..."}
                    breakClassName={"break-me"}
                    pageCount={pag.pageCount}
                    marginPagesDisplayed={2}
                    pageRangeDisplayed={5}
                    onPageChange={handlePageClick}
                    containerClassName={"pagination"}
                    subContainerClassName={"pages pagination"}
                    activeClassName={"active"}
                    forcePage={pag.currentPage}
                />
            </div>
            <Link 
                to={'/menu'}
                className="link-menu">
                &#60; Menu
            </Link>
        </Fragment>
    )
}
 
export default TagAllDescriptorList;