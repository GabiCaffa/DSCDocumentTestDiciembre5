//tagdescriptions/src/components/advanceSearch/tagDescriptorSearch.jsx
import React, {Fragment, useContext, useEffect} from 'react';
import tagDescriptorContext from "../../context/tagdescriptor/tagDescriptorContext";
import systemContext from '../../context/system/systemContext';

const TagDescriptorSearch = ({tagdescriptor}) => {
    
    const sContext = useContext(systemContext)
    const {systemAndAssetSelected, getSystemById, selectSystem} = sContext;
    
    const tContext = useContext(tagDescriptorContext)
    const { selectTagDescriptor, showForm} = tContext
    
    const editTagDescriptor = (tagdescriptor, system) => {
        selectTagDescriptor(tagdescriptor._id);
        selectSystem(system)
        showForm();
    }
   
    useEffect(() => {
        if (tagdescriptor && tagdescriptor.system) {
            getSystemById(tagdescriptor.system)
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [tagdescriptor.system]) 
    
    return ( 
        <Fragment>
            <li className="tarea sombra">
                {systemAndAssetSelected ? (
                    <p>
                        <span>Nombre:</span> {tagdescriptor.tagname} | 
                        <span>Asset:</span> {systemAndAssetSelected.assetName} | 
                        <span>System:</span> {systemAndAssetSelected.systemName}
                    </p>
                ) : null}
                
                <div className="acciones">
                    <button 
                        type="button"
                        className="btn btn-primario"
                        onClick={() => {editTagDescriptor(tagdescriptor, systemAndAssetSelected)}}
                    >
                        Editar
                    </button>                
                </div>
            </li> 
        </Fragment>
    );
}
 
export default TagDescriptorSearch;