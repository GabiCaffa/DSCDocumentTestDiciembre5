//tagdescriptions/src/components/advanceSearch/newTagDescriptorSearch.jsx
import React, { Fragment, useState, useContext, useEffect } from 'react';
import tagDescriptorContext from '../../context/tagdescriptor/tagDescriptorContext';
import systemContext from '../../context/system/systemContext';
import SunEditor from 'suneditor-react';
import 'suneditor/dist/css/suneditor.min.css';
import plugins from 'suneditor/src/plugins';
import alertContext from '../../context/alerts/alertContext';

const NewTagDescriptorSearch = () => {
    
    const tdContext = useContext(tagDescriptorContext);
    const { 
        tagname_ok, 
        message, 
        createTagDescriptor, 
        tagdescriptor, 
        related, 
        interlocks, 
        resetMessage, 
        updateTagDescriptor, 
        validateTagname, 
        getTagDescriptorsRelated, 
        selectOnlyDescriptor, 
        getInterlocks 
    } = tdContext;

    const sContext = useContext(systemContext);
    const { systemSelected } = sContext;

    const aContext = useContext(alertContext);
    const { showAlert } = aContext;

    const [tagname, setTagname] = useState('');
    const [description, setDescription] = useState('');
    const [icon, setIcon] = useState('');

    // Cargar datos iniciales y cuando cambie tagdescriptor
    useEffect(() => {
        if (tagdescriptor !== null && tagdescriptor.length > 0) {
            const [currentTagDescriptor] = tagdescriptor;
            setTagname(currentTagDescriptor.tagname);
            setDescription(currentTagDescriptor.description);
            getTagDescriptorsRelated(currentTagDescriptor._id);
            getInterlocks(currentTagDescriptor);
        } else {
            setTagname('');
            setDescription('');
        }
        // eslint-disable-next-line
    }, [tagdescriptor]);

    // Manejar mensajes
    useEffect(() => {
        if (message) {
            showAlert(message.msg, message.category);
            console.log(message.category);
            if (message.category === "alerta-error") {
                setIcon('-red');
            } else {
                setIcon('');
            }
            resetMessage();
        }
        // eslint-disable-next-line
    }, [message]);

    if (!systemSelected) return null;

    const onChangeTagDescriptor = (e) => {
        setTagname(e.target.value);
    };

    const onBlurTagDescriptor = (e) => {
        if (!(tagdescriptor !== null && tagdescriptor.length > 0)) {
            validateTagname(e.target.value);
        }
        setIcon('');
    };

    const onChangeRichText = (content) => {
        setDescription(content);
    };

    const goToRelated = (tagdescriptor_related) => {
        selectOnlyDescriptor(tagdescriptor_related);
        setTagname(tagdescriptor_related.tagname);
        setDescription(tagdescriptor_related.description);
        getTagDescriptorsRelated(tagdescriptor_related._id);
    };

    const onSubmitTagDescriptor = (e) => {
        e.preventDefault();

        // Validaciones
        if (tagname.trim() === '' || description.trim() === '') {
            showAlert('Debe completar tagname y descripción', 'alerta-error');
            return;
        }

        // Crear objeto tag descriptor
        let newTagDescriptor = {
            tagname: tagname.toUpperCase(),
            description: description,
            system: systemSelected._id
        };

        if (tagdescriptor !== null && tagdescriptor.length > 0) {
            const [currentTagDescriptor] = tagdescriptor;
            newTagDescriptor._id = currentTagDescriptor._id;
            updateTagDescriptor(newTagDescriptor);
        } else {
            if (tagname_ok === false) {
                if (message) {
                    showAlert(message.msg, message.category);
                    resetMessage();
                } else {
                    showAlert("El tag descriptor para ese tagname ya existe", "alerta-error");
                }
                return;
            }
            createTagDescriptor(newTagDescriptor);
        }
    };

    const onClickCancelar = () => {
        window.location.reload();
    };

    // Configuración optimizada de SunEditor para React 18
    const editorOptions = {
        height: 300,
        plugins: plugins,
        buttonList: [
            ['undo', 'redo'],
            ['font', 'fontSize', 'formatBlock'],
            ['bold', 'underline', 'italic', 'strike', 'subscript', 'superscript'],
            ['fontColor', 'hiliteColor'],
            ['removeFormat'],
            ['outdent', 'indent'],
            ['align', 'horizontalRule', 'list', 'lineHeight'],
            ['table', 'link', 'image', 'video'],
            ['fullScreen', 'showBlocks', 'codeView'],
            ['preview', 'print']
        ],
        formats: ['p', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'],
        font: ['Arial', 'Comic Sans MS', 'Courier New', 'Impact', 'Georgia', 'Tahoma', 'Trebuchet MS', 'Verdana'],
        fontSize: [8, 10, 14, 18, 24, 36],
        colorList: [
            '#ff0000', '#ff5e00', '#ffe400', '#abf200', '#00d8ff', '#0055ff', '#6600ff', '#ff00dd', '#000000',
            '#ffd8d8', '#fae0d4', '#faf4c0', '#e4f7ba', '#d4f4fa', '#d9e5ff', '#e8d9ff', '#ffd9fa', '#f1f1f1',
            '#ffa7a7', '#ffc19e', '#faed7d', '#cef279', '#b2ebf4', '#b2ccff', '#d1b2ff', '#ffb2f5', '#bdbdbd',
            '#f15f5f', '#f29661', '#e5d85c', '#bce55c', '#5cd1e5', '#6699ff', '#a366ff', '#f261df', '#8c8c8c',
            '#980000', '#993800', '#998a00', '#6b9900', '#008299', '#003399', '#3d0099', '#990085', '#353535',
            '#670000', '#662500', '#665c00', '#476600', '#005766', '#002266', '#290066', '#660058', '#222222'
        ]
    };

    return (
        <Fragment>
            <h2>Tag descriptor en el sistema: {systemSelected.systemName}</h2>
            <div className="formDescriptor">
                <div className="descriptor">
                    <form
                        className="formulario-nuevo-proyecto"
                        onSubmit={onSubmitTagDescriptor}
                    >
                        <input
                            type="text"
                            className={`input-text${icon}`}
                            placeholder="Tag name"
                            name="tagname"
                            value={tagname}
                            onChange={onChangeTagDescriptor}
                            readOnly={tagdescriptor !== null && tagdescriptor.length > 0}
                            onBlur={onBlurTagDescriptor}
                        />

                        {/* SunEditor optimizado para React 18 */}
                        <SunEditor
                            placeholder="Descripción del tag"
                            name="description"
                            setOptions={editorOptions}
                            setContents={description}
                            onChange={onChangeRichText}
                            showToolbar={true}
                            setDefaultStyle="font-family: Arial; font-size: 14px;"
                        />

                        {tagdescriptor !== null && tagdescriptor.length > 0 ? (
                            <input
                                type="submit"
                                className="btn btn-primario btn-block"
                                value="Guardar Tag"
                            />
                        ) : (
                            <input
                                type="submit"
                                className="btn btn-primario btn-block"
                                value="Agregar Tag"
                            />
                        )}
                        
                        <input
                            type="button"
                            className="btn btn-primario btn-block"
                            value="Cancelar"
                            onClick={onClickCancelar}
                        />
                    </form>
                </div>

                {tagdescriptor !== null && tagdescriptor.length > 0 && (
                    <div className="descriptorsRelated">
                        {related != null && (
                            <p><b>Descriptores relacionados</b></p>
                        )}
                        <ul>
                            {related !== null && related.length !== 0 ? (
                                related.map((r, index) => (
                                    <li key={`related-${index}`} className="itemRelated">
                                        <button 
                                            className="tagRelatedButton" 
                                            onClick={() => goToRelated(r)}
                                            type="button"
                                        >
                                            {r.tagname}
                                        </button>
                                    </li>
                                ))
                            ) : (
                                <li className="itemRelated">
                                    <span>No hay descriptores relacionados</span>
                                </li>
                            )}
                        </ul>

                        {interlocks != null && (
                            <p><b>Interlocks</b></p>
                        )}
                        <ul>
                            {interlocks[0] != null &&
                                interlocks[0].map((r, index) =>
                                    r.Interlock !== "" ? (
                                        <li key={`interlock-${index}`} className="itemRelated">
                                            <span>{r.Interlock}</span>
                                        </li>
                                    ) : null
                                )
                            }
                        </ul>
                    </div>
                )}
            </div>
        </Fragment>
    );
};

export default NewTagDescriptorSearch;