//tagdescriptions/src/components/architecture/nodedevice.jsx
/*Para switches, firewealls y routers*/ 
import React, { memo } from 'react';

import { Handle } from 'reactflow';
import Diagrama from './Diagrama';

const aux="left"
const funcion=()=>{
  //console.log("Entre")
}
export default memo(({ data, isConnectable }) => {
  
  return (
    <>
      {(data.posin) ?
        <Handle
        type="target"
        position={data.posin}
        style={{ background: '#555' }}
        onConnect={(params) => console.log('handle onConnect', params)}
        isConnectable={isConnectable}
        />
        :
        (null)
      }
      <div>
        <strong><center>{data.equipo}</center></strong>
      </div>
      <input
        className="boton"
        type="button"
        value="Connections"
        defaultValue={data.color}
      />
      <input
      className="boton"
      type="button"
      value="       Status       "
      onClick={()=>
        {   console.log("Entro")
            localStorage.setItem('networkstatusID',"12")
            window.open('/networkstatus')
        }
    }
      defaultValue={data.color}
    />
      {(data.posout) ?
        <Handle
          type="source"
          position={data.posout}
          id="a"
          style={{ background: '#555' }}
          isConnectable={isConnectable}
        />
        :
        (null)
      }
    </>
  );
});