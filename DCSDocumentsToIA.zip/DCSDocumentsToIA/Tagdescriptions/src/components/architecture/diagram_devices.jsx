//tagdescriptions/src/components/architecture/diagram_devices.jsx
import React, { useState, useEffect, useContext, useCallback, useMemo } from 'react';
import NodeCore from './nodeCoreDevice';
import { Link } from 'react-router-dom'
import networkContext from "../../context/network/networkContext";
import deviceContext from '../../context/devices/devicesContext'
import architecture from './architecturedevices'

import ReactFlow, {
  Controls,
  Background,
  applyNodeChanges,
  applyEdgeChanges,
  addEdge,
} from 'reactflow';
import 'reactflow/dist/style.css'; 

import Header from '../../layout/header';

const Diagram_Devices = () => {

  const tContext = useContext(networkContext)
  const { getArchitectureDevices, architectureDevices } = tContext
  
  const [nodes, setNodes] = useState([]);
  const [edges, setEdges] = useState([]);

  const dContext = useContext(deviceContext)
  const {deselectDeviceId} = dContext

  const networkNodeName = localStorage.getItem('networkNodeName');

  // CRÍTICO: Define nodeTypes con useMemo
  const nodeTypes = useMemo(() => ({
    Botones: NodeCore,
  }), []);

  // CRÍTICO: Define edgeTypes con useMemo (aunque esté vacío)
  const edgeTypes = useMemo(() => ({}), []);

  useEffect(() => {
    if (architectureDevices.length !== 0) {
      const architectureData = architecture(architectureDevices);
      if (architectureData) {
        const newNodes = architectureData.filter(el => !el.source);
        const newEdges = architectureData.filter(el => el.source);
        setNodes(newNodes);
        setEdges(newEdges);
      }
    }
  }, [architectureDevices])

  useEffect(() => {
    if (networkNodeName !== "" && networkNodeName !== null) {
      getArchitectureDevices(networkNodeName)
      localStorage.setItem('networkNodeName', '')
    }
    // eslint-disable-next-line
  }, [networkNodeName])

  const onNodesChange = useCallback(
    (changes) => setNodes((nds) => applyNodeChanges(changes, nds)),
    []
  );

  const onEdgesChange = useCallback(
    (changes) => setEdges((eds) => applyEdgeChanges(changes, eds)),
    []
  );

  const onConnect = useCallback(
    (params) => setEdges((eds) => addEdge(params, eds)),
    []
  );

  const onNodeDragStop = (event, node) => console.log('drag stop', node);
  
  const onNodeClick = (event, node) => {
    if ((node.data.idMongo !== localStorage.getItem('devicestatusID')) && node.data.idMongo) {
      if (event.target.id === "btnConnections") {
        console.log("CLICKK")
        window.open("/conections300/" + node.data.idMongo, "_blank")
      } else {
        localStorage.setItem('devicestatusID', node.data.idMongo)
        window.open('/devicestatus', "_blank")
        deselectDeviceId()
      }
    }
  }

  const back = () => {
    window.open("/architecture", "_self")
  }

  return (
    <div>
      <Header />
      <h1>Conexiones del switch {networkNodeName}</h1>
      <div className='contenedor_networkDevices'>
        {(nodes.length > 0) ? (
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onConnect={onConnect}
            onNodeClick={onNodeClick}
            onNodeDragStop={onNodeDragStop}
            nodeTypes={nodeTypes}
            edgeTypes={edgeTypes}
            defaultZoom={1.0}
            snapToGrid={true}
            fitView
          >
            <Controls />
            <Background color="#aaa" gap={16} />
          </ReactFlow>
        ) : (
          <p>No hay nada para mostrar</p>
        )}

        <div className="link-arq-div">
          <Link
            to={'/menu'}
            className="link-menu">
            &#60; Menu
          </Link>
          <a href="./architecture" onClick={back} className="link-menu"> &#60; Architecture </a>
        </div>
      </div>
    </div>
  );
};

export default Diagram_Devices;