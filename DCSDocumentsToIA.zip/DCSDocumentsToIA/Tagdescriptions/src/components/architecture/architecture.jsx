// tagdescriptions/src/components/architecture/architecture.jsx
const createArchitecture = (arquitectura = []) => {
  let equipos = [];
  let conexiones = [];
  
  if (arquitectura.nodes) {
    equipos = arquitectura.nodes;
    conexiones = arquitectura.connections;
  } else {   
    console.log("NO Tiene nodos");
    return null;
  }
  
  let draweq = [];
  let posy = 0;
  let posx = 0;
  let color = '#FFFFF';
  let cName = '#FFFFF';
  let posin = 'left';
  let posout = '';

  let cant_area = [];
  let i = 1;
  while (i < 27) {
    cant_area[i] = 0;
    i = i + 1;
  }

  equipos.forEach((eq) => {
    switch (eq.area) {
      case 1: cant_area[1] = cant_area[1] + 1; break;
      case 2: cant_area[2] = cant_area[2] + 1; break;
      case 3: cant_area[3] = cant_area[3] + 1; break;
      case 4: cant_area[4] = cant_area[4] + 1; break;
      case 5: cant_area[5] = cant_area[5] + 1; break;
      case 6: cant_area[6] = cant_area[6] + 1; break;
      case 21: cant_area[21] = cant_area[21] + 1; break;
      case 22: cant_area[22] = cant_area[22] + 1; break;
      case 23: cant_area[23] = cant_area[23] + 1; break;
      case 24: cant_area[24] = cant_area[24] + 1; break;
      case 25: cant_area[25] = cant_area[25] + 1; break;
      case 26: cant_area[26] = cant_area[26] + 1; break;
      default: console.log('Area no definida');
    }
  });

  const pasoy = 120;
  let area2y = -0;
  let area3y = cant_area[2] * pasoy + area2y;
  let area4y = (cant_area[2] + cant_area[3]) * pasoy + area2y;
  let area5y = area4y - 40 + area2y;
  let area6y = (cant_area[2] + cant_area[3] + cant_area[4]) * pasoy + area2y;
  let area2yB = -0;
  let area3yB = cant_area[22] * pasoy + area2yB;
  let area4yB = (cant_area[22] + cant_area[23]) * pasoy + area2yB;
  let area5yB = area4yB - 40 + area2yB;
  let area6yB = (cant_area[22] + cant_area[23] + cant_area[24]) * pasoy + area2yB;

  let xlevel0 = 600;
  let pasolevelx = 200;
  let ylevel1 = 0;
  
  equipos.forEach((eq, i) => {
    posin = 'right';
    posout = '';
    
    switch (eq.area) {
      case 1: 
        posx = 700;
        posy = 250;
        posin = 'right';
        posout = 'left';
        cName = 'architecture_node_rackroom';
        break;
      case 2: 
        posx = 400;
        posy = area2y;  
        area2y = area2y + pasoy;
        cName = 'architecture_node_recovery';
        break;  
      case 3: 
        posx = 400;
        posy = area3y;
        area3y = area3y + pasoy;
        cName = 'architecture_node_rackroom';
        break;  
      case 4: 
        posx = 400;
        posy = area4y;
        area4y = area4y + pasoy;
        posout = 'left';
        cName = 'architecture_node_dryer';
        break;  
      case 5: 
        posx = 100;
        posy = area5y;
        area5y = area5y + pasoy;
        cName = 'architecture_node_dryer';
        break;  
      case 6: 
        posx = 400;
        posy = area6y;
        area6y = area6y + pasoy;
        cName = 'architecture_node_fiber';
        break;  
      case 21:  
        posx = 1000;
        posy = 250;
        posin = 'left';
        posout = 'right';
        cName = 'architecture_node_rackroom';
        break;
      case 22:  
        posx = 1300;
        posy = area2yB;  
        area2yB = area2yB + pasoy;
        posin = 'left';
        cName = 'architecture_node_recovery';
        break;  
      case 23:  
        posx = 1300;
        posy = area3yB;
        area3yB = area3yB + pasoy;
        posin = 'left';
        cName = 'architecture_node_rackroom';
        break;  
      case 24:  
        posx = 1300;
        posy = area4yB;
        area4yB = area4yB + pasoy;
        posin = 'left';
        posout = 'right';
        cName = 'architecture_node_dryer';
        break;  
      case 25:  
        posx = 1600;
        posy = area5yB;
        area5yB = area5yB + pasoy;
        posin = 'left';
        cName = 'architecture_node_dryer';
        break;  
      case 26:  
        posx = 1300;
        posy = area6yB;
        area6yB = area6yB + pasoy;
        posin = 'left';
        cName = 'architecture_node_fiber';
        break;
      default: 
        console.log('No esta definida el area para realizar el dibujo');  
    }
  
    if (eq.level !== null) {
      switch (eq.level) {
        case 0:     
          posx = xlevel0;
          xlevel0 = xlevel0 + 200;
          posy = ylevel1 - 100;
          posin = 'top';
          cName = '';
          break;
        case 1:     
          posx = 400;
          posy = ylevel1;
          ylevel1 = ylevel1 + 180;
          xlevel0 = 600;
          posin = 'left';
          posout = 'right';
          cName = '';
          break;
        case 2:     
          posx = 100;
          posy = 0;
          posout = 'right';
          cName = '';
          break;
      }
    }

    switch (eq.devicetype) {
      case 'CF9': color = '#4EA235'; break;
      case 'C300': color = '#1862CC'; break;  
      case 'PGM': color = '#7974CC'; break;
      case 'FDAP': color = '#D5B048'; break;
    }

    // CRÍTICO: Asegúrate de que el ID sea único y válido
    const nodeId = String(eq.id); // Convierte a string
    
    draweq.push({
      id: nodeId, // ID único como string
      type: 'Botones', 
      sourcePosition: 'right', 
      targetPosition: 'left',
      data: { 
        cName: cName, 
        equipo: eq.node, 
        posin: posin, 
        posout: posout, 
        devicetype: eq.devicetype, 
        area: eq.area, 
        img: eq.url
      },
      position: { x: posx, y: posy }, 
      style: { background: '' }
    });
  });

  // Conexiones
  conexiones.forEach((con, i) => {
    // CRÍTICO: Convierte source y target a strings y genera ID único
    const sourceId = String(con.ids);
    const targetId = String(con.idt);
    const edgeId = `${sourceId}-${targetId}`;
    
    draweq.push({ 
      id: edgeId, 
      source: sourceId, 
      target: targetId, 
      type: 'smoothstep' 
    });
  });

  return draweq;
};

export default createArchitecture;