//tagdescriptions/src/components/architecture/diagrama.jsx
import React, { useState, useEffect, useContext, useCallback, useMemo } from 'react';
import NodeCore from './nodecore';
import { Link } from 'react-router-dom'
import networkContext from "../../context/network/networkContext";
import architecture from './architecture'

import ReactFlow, {
  Controls,
  Background,
  applyNodeChanges,
  applyEdgeChanges,
  addEdge,
} from 'reactflow';
import 'reactflow/dist/style.css';

import Header from '../../layout/header';

const Diagrama = () => {

  const tContext = useContext(networkContext)
  const {getNetworkArchitectureDevices, getNetworkArchitectureNodes, networkArchitectureDevices, networkArchitectureNodes} = tContext
  
  const [nodes, setNodes] = useState([]);
  const [edges, setEdges] = useState([]);
  
  // CRÍTICO: Define nodeTypes con useMemo
  const nodeTypes = useMemo(() => ({
    Botones: NodeCore,
  }), []);

  // CRÍTICO: Define edgeTypes con useMemo (aunque esté vacío)
  const edgeTypes = useMemo(() => ({}), []);

  useEffect(() => {
    if (networkArchitectureDevices.length !== 0) {
      const architectureData = architecture(networkArchitectureDevices);
      if (architectureData) {
        const newNodes = architectureData.filter(el => !el.source);
        const newEdges = architectureData.filter(el => el.source);
        setNodes(newNodes);
        setEdges(newEdges);
      }
    }
  }, [networkArchitectureDevices])

  useEffect(() => {
    getNetworkArchitectureNodes()
    // eslint-disable-next-line
  }, [])

  useEffect(() => {
    if (networkArchitectureNodes.nodes) {
      const architectureData = architecture(networkArchitectureNodes);
      if (architectureData) {
        const newNodes = architectureData.filter(el => !el.source);
        const newEdges = architectureData.filter(el => el.source);
        setNodes(newNodes);
        setEdges(newEdges);
      }
    }
  }, [networkArchitectureNodes])

  const onNodesChange = useCallback(
    (changes) => setNodes((nds) => applyNodeChanges(changes, nds)),
    []
  );

  const onEdgesChange = useCallback(
    (changes) => setEdges((eds) => applyEdgeChanges(changes, eds)),
    []
  );

  const onConnect = useCallback(
    (params) => setEdges((eds) => addEdge(params, eds)),
    []
  );

  const onNodeDragStop = (event, node) => console.log('drag stop', node);
  const onNodeClick = (event, node) => console.log('click', node);
  
  const back = () => {
    window.open("/architecture", "_self")
  }
  
  return (
    <div>
      <Header />
      <h1>Arquitectura de red</h1>
      <div className='contenedor'>
        {(nodes.length > 0) ? (
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={onNodesChange}
            onEdgesChange={onEdgesChange}
            onConnect={onConnect}
            onNodeClick={onNodeClick}
            onNodeDragStop={onNodeDragStop}
            nodeTypes={nodeTypes}
            edgeTypes={edgeTypes}
            fitView
          >
            <Controls />
            <Background color="#aaa" gap={16} />
          </ReactFlow>
        ) : (
          <p>No hay nada para mostrar</p>
        )}

        <div className="link-arq-div">
          <Link 
            to={'/menu'}
            className="link-menu">
            &#60; Menu
          </Link>
          <a href="./architecture" onClick={back} className="link-menu"> &#60; Architecture </a>
        </div>
      </div>
    </div>
  );
};

export default Diagrama;