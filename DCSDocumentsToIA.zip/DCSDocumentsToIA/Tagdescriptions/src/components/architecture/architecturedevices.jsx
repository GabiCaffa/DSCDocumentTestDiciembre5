//tagdescriptions/src/components/architecture/architecturedevices.jsx
const createArchitectureDevices = (arquitectura = []) => {
  let equipos = [];
  let conexiones = [];
  
  if (arquitectura.nodes) {
    equipos = arquitectura.nodes;
    conexiones = arquitectura.connections;
  } else {   
    return null;
  }
  
  let draweq = [];
  let posy = 0;
  let posx = 0;
  let cName = '#FFFFF';
  let posin = 'left';
  let posout = '';

  let cant_area = [];
  let i = 0;
  let max_areas = -1;
  
  equipos.forEach((eq) => {
    if (max_areas < eq.area) {
      max_areas = eq.area;
    }
  });

  while (i <= max_areas) {
    cant_area[i] = 0;
    i = i + 1;
  }

  equipos.forEach((eq) => {
    switch (eq.area) {
      case 1: cant_area[1] = cant_area[1] + 1; break;
      case 2: cant_area[2] = cant_area[2] + 1; break;
      case 3: cant_area[3] = cant_area[3] + 1; break;
      case 4: cant_area[4] = cant_area[4] + 1; break;
      case 5: cant_area[5] = cant_area[5] + 1; break;
      case 6: cant_area[6] = cant_area[6] + 1; break;
      case 21: cant_area[21] = cant_area[21] + 1; break;
      case 22: cant_area[22] = cant_area[22] + 1; break;
      case 23: cant_area[23] = cant_area[23] + 1; break;
      case 24: cant_area[24] = cant_area[24] + 1; break;
      case 25: cant_area[25] = cant_area[25] + 1; break;
      case 26: cant_area[26] = cant_area[26] + 1; break;
      default: console.log('Area no definida');
    }
  });
  
  let color;
  let xlevel0 = 600;
  let ylevel1 = 0;

  equipos.forEach((eq, i) => {
    posin = 'right';
    posout = '';
    
    if (eq.level !== null) {
      switch (eq.level) {
        case 0:     
          posx = xlevel0;
          xlevel0 = xlevel0 + 250;
          posy = ylevel1 - 150;
          posin = 'top';
          cName = '';
          break;
        case 1:     
          posx = 400;
          posy = ylevel1;
          ylevel1 = ylevel1 + 230;
          xlevel0 = 600;
          posin = 'left';
          posout = 'right';
          cName = '';
          break;
        case 2:     
          posx = 100;
          posy = 0;
          posout = 'right';
          cName = '';
          break;
        default:
          break;
      }
    }

    switch (eq.devicetype) {
      case 'CF9': color = '#4EA235'; break;
      case 'C300': color = '#1862CC'; break;  
      case 'PGM': color = '#7974CC'; break;
      case 'FDAP': color = '#D5B048'; break;
      default: color = '#D5B048';
    }

    // CRÍTICO: Convertir ID a string
    const nodeId = String(eq.id);
    
    draweq.push({
      id: nodeId,
      type: 'Botones',
      sourcePosition: 'right',
      targetPosition: 'left',
      data: { 
        idMongo: eq.idMongo,
        cName: cName,
        equipo: eq.node,
        posin: posin,
        posout: posout,
        devicetype: eq.devicetype,
        area: eq.area,
        img: eq.url
      },
      position: { x: posx, y: posy },
      style: { background: '' }
    });
  });

  // Conexiones - CRÍTICO: convertir IDs a strings
  conexiones.forEach((con, i) => {
    const sourceId = String(con.ids);
    const targetId = String(con.idt);
    const edgeId = `${sourceId}-${targetId}`;
    
    draweq.push({ 
      id: edgeId,
      source: sourceId,
      target: targetId,
      type: 'smoothstep'
    });
  });

  return draweq;
};

export default createArchitectureDevices;