import React, { useState, useRef, useEffect, useContext, useCallback } from 'react';
import ReactMarkdown from 'react-markdown';
import { useNavigate } from 'react-router-dom';
//import 'suneditor/dist/css/suneditor.min.css';
import ChatAssistantContext from '../../context/chatAssistant/chatAssistantContext';

const ChatAssistants = () => {
  const navigate = useNavigate();  
  const { 
    messages, 
    loading, 
    isOpen, 
    navigationPath,
    sendMessage, 
    toggleChat,
    clearMessages,
    clearNavigationPath
  } = useContext(ChatAssistantContext);
  
  const [inputMessage, setInputMessage] = useState('');
  const [position, setPosition] = useState({ x: null, y: null });
  const [size, setSize] = useState({ width: 380, height: 600 });
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(null);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [resizeStart, setResizeStart] = useState({ x: 0, y: 0, width: 0, height: 0, posX: 0, posY: 0 });
  const [darkMode, setDarkMode] = useState(false);
  const [isClosing, setIsClosing] = useState(false);
  
  const [isListening, setIsListening] = useState(false);
  const [speechSupported, setSpeechSupported] = useState(false);
  const [voiceError, setVoiceError] = useState(null);
  
  const messagesEndRef = useRef(null);
  const chatContainerRef = useRef(null);
  const recognitionRef = useRef(null);
  const isVoiceInputRef = useRef(false);

  // Cargar preferencia de modo oscuro
  useEffect(() => {
    const savedDarkMode = localStorage.getItem('chatDarkMode');
    if (savedDarkMode === 'true') {
      setDarkMode(true);
    }
  }, []);

  // Effect para manejar la navegación
  useEffect(() => {
    if (navigationPath) {
      console.log('[ChatAssistant] Navegando a:', navigationPath);
      
      const timer = setTimeout(() => {
        navigate(navigationPath);
        clearNavigationPath();
      }, 1500);
      
      return () => clearTimeout(timer);
    }
  }, [navigationPath, navigate, clearNavigationPath]);

  const handleSendMessage = useCallback(async () => {
    if (!inputMessage.trim() || loading) return;

    const messageToSend = inputMessage;
    setInputMessage('');
    
    await sendMessage(messageToSend);
  }, [inputMessage, loading, sendMessage]);

  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (SpeechRecognition) {
      setSpeechSupported(true);
      recognitionRef.current = new SpeechRecognition();
      
      recognitionRef.current.continuous = false;
      recognitionRef.current.interimResults = true;
      recognitionRef.current.lang = 'es-ES';
      
      recognitionRef.current.onstart = () => {
        setIsListening(true);
        setVoiceError(null);
        isVoiceInputRef.current = true;
      };
      
      recognitionRef.current.onresult = (event) => {
        let finalTranscript = '';
        
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          
          if (event.results[i].isFinal) {
            finalTranscript += transcript + ' ';
          }
        }
        
        if (finalTranscript.trim()) {
          setInputMessage(prev => (prev + ' ' + finalTranscript).trim());
        }
      };
      
      recognitionRef.current.onend = () => {
        setIsListening(false);
      };
      
      recognitionRef.current.onerror = (event) => {
        setIsListening(false);
        
        let errorMsg = 'Error en el micrófono';
        
        switch(event.error) {
          case 'no-speech':
            errorMsg = 'No se detectó sonido. Intenta de nuevo.';
            break;
          case 'audio-capture':
            errorMsg = 'No se encontró micrófono. Verifica los permisos.';
            break;
          case 'network':
            errorMsg = 'Error de conexión. Verifica tu internet.';
            break;
          case 'permission-denied':
            errorMsg = 'Permiso denegado para acceder al micrófono.';
            break;
          default:
            errorMsg = `Error: ${event.error}`;
        }
        
        setVoiceError(errorMsg);
      };
    }
  }, []);

  useEffect(() => {
    if (!isListening && inputMessage.trim() && isVoiceInputRef.current) {
      const timer = setTimeout(() => {
        if (!isListening && inputMessage.trim()) {
          handleSendMessage();
          isVoiceInputRef.current = false;
        }
      }, 500);
      
      return () => clearTimeout(timer);
    }
  }, [isListening, inputMessage, handleSendMessage]);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  useEffect(() => {
    if (isOpen && position.x === null) {
      const savedPosition = localStorage.getItem('chatPosition');
      const savedSize = localStorage.getItem('chatSize');
      
      if (savedPosition) {
        setPosition(JSON.parse(savedPosition));
      }
      if (savedSize) {
        setSize(JSON.parse(savedSize));
      }
    }
  }, [isOpen, position.x]);

  const handleToggleChat = () => {
    if (isOpen) {
      setIsClosing(true);
      setTimeout(() => {
        toggleChat(false);
        setIsClosing(false);
      }, 300);
    } else {
      toggleChat(true);
    }
  };

  const handleToggleDarkMode = () => {
    const newMode = !darkMode;
    setDarkMode(newMode);
    localStorage.setItem('chatDarkMode', newMode.toString());
  };

  const handleStartListening = () => {
    if (recognitionRef.current && !isListening) {
      setInputMessage('');
      isVoiceInputRef.current = true;
      recognitionRef.current.start();
    }
  };

  const handleStopListening = () => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.stop();
    }
  };

  const quickQuestions = [
    "¿Cómo me registro?",
    "¿Dónde veo los reportes?",
    "¿Cómo agrego un nodo de red?",
    "¿Dónde están los usuarios?"
  ];

  const handleQuickQuestion = (question) => {
    setInputMessage(question);
  };

  const handleMouseDown = (e) => {
    if (e.target.closest('.chat-assistant-header') && 
        !e.target.closest('.chat-header-actions')) {
      setIsDragging(true);
      
      const rect = chatContainerRef.current.getBoundingClientRect();
      setDragOffset({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      });
    }
  };

  const handleResizeMouseDown = (e, direction) => {
    e.stopPropagation();
    e.preventDefault();
    
    const rect = chatContainerRef.current.getBoundingClientRect();
    
    setIsResizing(direction);
    setResizeStart({
      x: e.clientX,
      y: e.clientY,
      width: rect.width,
      height: rect.height,
      posX: position.x !== null ? position.x : rect.left,
      posY: position.y !== null ? position.y : rect.top
    });
  };

  const handleMouseMove = useCallback((e) => {
    if (isDragging) {
      const newX = e.clientX - dragOffset.x;
      const newY = e.clientY - dragOffset.y;

      const maxX = window.innerWidth - size.width;
      const maxY = window.innerHeight - size.height;

      const boundedX = Math.max(0, Math.min(newX, maxX));
      const boundedY = Math.max(0, Math.min(newY, maxY));

      setPosition({ x: boundedX, y: boundedY });
    }
    
    if (isResizing) {
      const deltaX = e.clientX - resizeStart.x;
      const deltaY = e.clientY - resizeStart.y;
      
      let newWidth = resizeStart.width;
      let newHeight = resizeStart.height;
      let newX = resizeStart.posX;
      let newY = resizeStart.posY;
      
      if (isResizing.includes('right')) {
        newWidth = Math.max(320, Math.min(800, resizeStart.width + deltaX));
      }
      if (isResizing.includes('left')) {
        const proposedWidth = Math.max(320, Math.min(800, resizeStart.width - deltaX));
        newX = resizeStart.posX + (resizeStart.width - proposedWidth);
        newWidth = proposedWidth;
      }
      if (isResizing.includes('bottom')) {
        newHeight = Math.max(400, Math.min(900, resizeStart.height + deltaY));
      }
      if (isResizing.includes('top')) {
        const proposedHeight = Math.max(400, Math.min(900, resizeStart.height - deltaY));
        newY = resizeStart.posY + (resizeStart.height - proposedHeight);
        newHeight = proposedHeight;
      }
      
      setSize({ width: newWidth, height: newHeight });
      setPosition({ x: newX, y: newY });
    }
  }, [isDragging, dragOffset, size.width, size.height, isResizing, resizeStart]);

  const handleMouseUp = useCallback(() => {
    if (isDragging) {
      setIsDragging(false);
      if (position.x !== null) {
        localStorage.setItem('chatPosition', JSON.stringify(position));
      }
    }
    
    if (isResizing) {
      setIsResizing(null);
      localStorage.setItem('chatSize', JSON.stringify(size));
    }
  }, [isDragging, position, isResizing, size]);

  useEffect(() => {
    if (isDragging || isResizing) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      
      return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging, isResizing, handleMouseMove, handleMouseUp]);

  const getContainerClasses = () => {
    let classes = 'chat-assistant-container';
    if (darkMode) classes += ' dark-mode';
    if (isDragging) classes += ' dragging';
    if (isResizing) classes += ' resizing';
    if (isClosing) classes += ' closing';
    return classes;
  };

  const getContainerStyle = () => {
    const style = {
      width: `${size.width}px`,
      height: `${size.height}px`
    };

    if (position.x !== null) {
      style.position = 'fixed';
      style.left = `${position.x}px`;
      style.top = `${position.y}px`;
      style.right = 'auto';
      style.bottom = 'auto';
    }

    return style;
  };

  return (
    <>
      <button 
        className={`chat-assistant-button ${isOpen ? 'open' : ''} ${loading ? 'processing' : ''}`}
        onClick={handleToggleChat}
        aria-label="Asistente Virtual"
      >
        {isOpen ? (
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        ) : (
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
          </svg>
        )}
      </button>

      {isOpen && (
        <div 
          ref={chatContainerRef}
          className={getContainerClasses()}
          style={getContainerStyle()}
        >
          <div className="resize-border resize-top" onMouseDown={(e) => handleResizeMouseDown(e, 'top')} />
          <div className="resize-border resize-right" onMouseDown={(e) => handleResizeMouseDown(e, 'right')} />
          <div className="resize-border resize-bottom" onMouseDown={(e) => handleResizeMouseDown(e, 'bottom')} />
          <div className="resize-border resize-left" onMouseDown={(e) => handleResizeMouseDown(e, 'left')} />
          
          <div className="resize-corner resize-top-left" onMouseDown={(e) => handleResizeMouseDown(e, 'top-left')} />
          <div className="resize-corner resize-top-right" onMouseDown={(e) => handleResizeMouseDown(e, 'top-right')} />
          <div className="resize-corner resize-bottom-left" onMouseDown={(e) => handleResizeMouseDown(e, 'bottom-left')} />
          <div className="resize-corner resize-bottom-right" onMouseDown={(e) => handleResizeMouseDown(e, 'bottom-right')} />

          <div 
            className={`chat-assistant-header ${loading ? 'processing' : ''}`}
            onMouseDown={handleMouseDown}
          >
            <div className="chat-header-info">
              <div className="chat-status-indicator"></div>
              <div>
                <h3>Asistente Virtual</h3>
                <span className="chat-status-text">
                  {isDragging ? 'Moviendo...' : position.x !== null ? 'Arrastra para mover' : 'En línea'}
                </span>
              </div>
            </div>
            <div className="chat-header-actions">
              <button 
                className={`dark-mode-toggle ${darkMode ? 'active' : ''}`}
                onClick={handleToggleDarkMode}
                title={darkMode ? "Modo claro" : "Modo oscuro"}
              >
                {darkMode ? (
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="5"></circle>
                    <line x1="12" y1="1" x2="12" y2="3"></line>
                    <line x1="12" y1="21" x2="12" y2="23"></line>
                    <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
                    <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
                    <line x1="1" y1="12" x2="3" y2="12"></line>
                    <line x1="21" y1="12" x2="23" y2="12"></line>
                    <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
                    <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
                  </svg>
                ) : (
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
                  </svg>
                )}
              </button>
              <button 
                className="clear-chat-btn"
                onClick={clearMessages}
                title="Limpiar conversación"
              >
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="3 6 5 6 21 6"></polyline>
                  <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                  <line x1="10" y1="11" x2="10" y2="17"></line>
                  <line x1="14" y1="11" x2="14" y2="17"></line>
                </svg>
              </button>
            </div>
          </div>

          <div className="chat-assistant-messages">
            {messages.map((msg, index) => (
              <div 
                key={index} 
                className={`chat-message ${msg.role} ${msg.isError ? 'error' : ''}`}
              >
                <div className="message-content">
                  <ReactMarkdown>{msg.content}</ReactMarkdown>
                </div>
                <div className="message-timestamp">
                  {msg.timestamp && new Date(msg.timestamp).toLocaleTimeString('es-ES', { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                  })}
                </div>
              </div>
            ))}
            
            {loading && (
              <div className="chat-message assistant">
                <div className="message-content">
                  <div className="typing-indicator">
                    <span></span>
                    <span></span>
                    <span></span>
                  </div>
                  <span className="typing-text">pensando...</span>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>

          {messages.length <= 1 && !loading && (
            <div className="quick-questions">
              <p className="quick-questions-title">Preguntas frecuentes:</p>
              <div className="quick-questions-grid">
                {quickQuestions.map((question, index) => (
                  <button
                    key={index}
                    className="quick-question-btn"
                    onClick={() => handleQuickQuestion(question)}
                  >
                    {question}
                  </button>
                ))}
              </div>
            </div>
          )}

          {voiceError && (
            <div className="voice-error">
              <span>{voiceError}</span>
              <button 
                className="close-error"
                onClick={() => setVoiceError(null)}
              >
                ✕
              </button>
            </div>
          )}

          <form className="chat-assistant-input" onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}>
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => {
                setInputMessage(e.target.value);
                isVoiceInputRef.current = false;
              }}
              placeholder={isListening ? "Escuchando..." : "Escribe o usa micrófono..."}
              disabled={loading}
            />
            
            {speechSupported && (
              <button
                type="button"
                className={`voice-btn ${isListening ? 'listening' : ''}`}
                onClick={isListening ? handleStopListening : handleStartListening}
                disabled={loading}
                title={isListening ? "Detener grabación" : "Usar micrófono"}
                aria-label="Micrófono"
              >
                {isListening ? (
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" stroke="none">
                    <rect x="6" y="4" width="4" height="16" rx="1"></rect>
                    <rect x="14" y="4" width="4" height="16" rx="1"></rect>
                  </svg>
                ) : (
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path>
                    <path d="M19 10v2a7 7 0 0 1-14 0v-2"></path>
                    <line x1="12" y1="19" x2="12" y2="23"></line>
                    <line x1="8" y1="23" x2="16" y2="23"></line>
                  </svg>
                )}
              </button>
            )}
            
            <button 
              type="submit" 
              disabled={loading || !inputMessage.trim()}
              aria-label="Enviar mensaje"
            >
              {loading ? (
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="spinner">
                  <circle cx="12" cy="12" r="1"></circle>
                  <circle cx="19" cy="12" r="1"></circle>
                  <circle cx="5" cy="12" r="1"></circle>
                </svg>
              ) : (
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="5" y1="12" x2="19" y2="12"></line>
                  <polyline points="12 5 19 12 12 19"></polyline>
                </svg>
              )}
            </button>
          </form>
        </div>
      )}
    </>
  );
};

export default ChatAssistants;