// components/chatAssistant/NavigationWrapper.js
import { useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import ChatAssistantContext from '../../context/chatAssistant/chatAssistantContext';

const NavigationWrapper = () => {
  const navigate = useNavigate();
  const { navigationPath, clearNavigationPath } = useContext(ChatAssistantContext);
  
  const token = localStorage.getItem('token');
  const isAuthenticated = token ? true : false;

  useEffect(() => {
    if (navigationPath) {
      console.log(' NavigationWrapper: Navegando a', navigationPath);
      
      if (!isAuthenticated) {
        console.warn(' Navegación bloqueada - no autenticado');
        if (clearNavigationPath) {
          clearNavigationPath();
        }
        return;
      }
      

      navigate.push(navigationPath);
      
      if (clearNavigationPath) {
        setTimeout(() => {
          clearNavigationPath();
        }, 100);
      }
    }
  }, [navigationPath, navigate, clearNavigationPath, isAuthenticated]);

  return null;
};

export default NavigationWrapper;