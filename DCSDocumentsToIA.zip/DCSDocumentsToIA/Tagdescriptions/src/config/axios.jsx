// tagdescriptions/src/config/axios.jsx
import axios from 'axios';

const axiosClient = axios.create({
    //baseURL: process.env.REACT_APP_BACKEND_URL || 'http://localhost:4000'
    baseURL : 'https://fjqq9pfm-4000.brs.devtunnels.ms/'
});

export default axiosClient;