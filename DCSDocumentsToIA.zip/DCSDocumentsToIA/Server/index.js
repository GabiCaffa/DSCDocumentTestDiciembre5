// ServidorActualizado/index.js
import express from 'express';
import conectarDB from './config/db.js';
import cors from 'cors';

// Crear el server
const app = express();

// Me conecto a la base
conectarDB();

// Registrar modelos (no exporta nada, solo los carga)
import './models/User.js';
import './models/Asset.js';
import './models/System.js';
import './models/TagDescriptor.js';
import './models/NetworkNode.js';
import './models/Device.js';
import './models/DeviceType.js';
import './models/Connection.js';
import './models/Cabinet.js';
import './models/IOCard.js';
import './models/IOCardType.js';
import './models/Report.js';
import './models/Area.js';
import './models/NetworkNodeModel.js';

// Middlewares
app.use(express.json({ extended: true }));
app.use(cors());

// Archivos estáticos
app.use(express.static('cabinetsFiles'));

const PORT = process.env.PORT || 4000;

// Importar rutas
import usersRoutes from './routes/users.js';
import authRoutes from './routes/auth.js';
import assetsRoutes from './routes/assets.js';
import tagsdescriptorsRoutes from './routes/tagsdescriptors.js';
import systemsRoutes from './routes/systems.js';
import treeRoutes from './routes/tree.js';
import showtagRoutes from './routes/showtag.js';
import showtagsRoutes from './routes/showtags.js';
import documentsRoutes from './routes/documents.js';
import interlocksRoutes from './routes/interlocks.js';
import alarmasEventosRoutes from './routes/alarmasyeventos.js';
import networkRoutes from './routes/network.js';
import networkmodelsRoutes from './routes/networkmodels.js';
import networkShowRoutes from './routes/networkShow.js';
import devicesRoutes from './routes/devices.js';
import devicestypesRoutes from './routes/devicestypes.js';
import filesRoutes from './routes/files.js';
import areasRoutes from './routes/areas.js';
import architectureRoutes from './routes/architecture.js';
import connectionsRoutes from './routes/connections.js';
import cabinetsRoutes from './routes/cabinets.js';
import cabinetfilesRoutes from './routes/cabinetfiles.js';
import iocardsRoutes from './routes/iocards.js';
import reportsRoutes from './routes/reports.js';
import assistantRoutes from './routes/assistant.js';

// Usar rutas
app.use('/api/users', usersRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/assets', assetsRoutes);
app.use('/api/tagsdescriptors', tagsdescriptorsRoutes);
app.use('/api/systems', systemsRoutes);
app.use('/api/tree', treeRoutes);
app.use('/api/showtag', showtagRoutes);
app.use('/api/showtags', showtagsRoutes);
app.use('/api/documents', documentsRoutes);
app.use('/api/interlocks', interlocksRoutes);
app.use('/api/alarmasyeventos', alarmasEventosRoutes);
app.use('/api/network', networkRoutes);
app.use('/api/networkmodels', networkmodelsRoutes);
app.use('/api/networkShow', networkShowRoutes);
app.use('/api/devices', devicesRoutes);
app.use('/api/devicestypes', devicestypesRoutes);
app.use('/api/files', filesRoutes);
app.use('/api/areas', areasRoutes);
app.use('/api/architecture', architectureRoutes);
app.use('/api/connections', connectionsRoutes);
app.use('/api/cabinets', cabinetsRoutes);
app.use('/api/cabinetfiles', cabinetfilesRoutes);
app.use('/api/iocards', iocardsRoutes);
app.use('/api/reports', reportsRoutes);
app.use('/api/assistant', assistantRoutes);

// Arrancar server
app.listen(PORT, () => {
    console.log(`El server está levantando en el puerto ${PORT}`);
});
