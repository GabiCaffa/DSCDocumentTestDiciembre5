import express from 'express';
import { check } from 'express-validator';
import cabinetController from '../controllers/cabinetController.js';
import auth from '../middlewares/auth.js';

const router = express.Router();

router.post('/',
    auth,
    [
        check('cabinetName', 'El nombre del gabinete no puede estar vacío').not().isEmpty(),
        check('cabinetDescription', 'La descripción del gabinete no puede estar vacía').not().isEmpty(),
        check('cabinetLatitude', 'La latitud del gabinete no puede estar vacía').not().isEmpty(),
        check('cabinetLongitude', 'La longitud del gabinete no puede estar vacía').not().isEmpty(),
        check('cabinetSize', 'El tamaño del gabinete no puede estar vacío').not().isEmpty(),
        check('area', 'El area del gabinete no puede estar vacía').not().isEmpty()
    ],
    cabinetController.addCabinet);

router.get('/cabinetname/:cabinetname',
    //auth,
    cabinetController.getCabinetbyName);

router.get('/',
    auth,
    cabinetController.getCabinets);
router.get('/:id',
    //auth,
    cabinetController.getCabinet);
router.put('/:id',
    auth,
    cabinetController.updateCabinet);

router.delete('/:id',
    auth,
    cabinetController.deleteCabinet);

export default router;