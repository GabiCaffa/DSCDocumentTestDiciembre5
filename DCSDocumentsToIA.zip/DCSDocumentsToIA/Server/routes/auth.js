// ServidorActualizado/routes/auth.js
import express from 'express';
import authController from '../controllers/authController.js';
import auth from '../middlewares/auth.js';

const router = express.Router();

// POST /api/auth - Iniciar sesión
router.post('/', 
    authController.authUser
);

// GET /api/auth - Obtener usuario autenticado
router.get('/', 
    auth,
    authController.getUser
);

export default router;