import express from 'express';
import { check } from 'express-validator';
import tagDescriptorController from '../controllers/tagDescriptorController.js';
import auth from '../middlewares/auth.js';

const router = express.Router();

router.post('/',
    auth,
    [
        check('tagname','El tagname no puede estar vacío').not().isEmpty()
    ],
    tagDescriptorController.createTagDescriptor) ;

router.get('/',
    auth,
    tagDescriptorController.getTagsDescriptors) ;
    router.get('/all',
    auth,
    tagDescriptorController.getAllTagsDescriptors) ;

router.get('/related/:id',
    auth,
    tagDescriptorController.getTagsDescriptors_Related) ;
router.put('/:id',
    auth,
    tagDescriptorController.updateTagDescriptor)

router.delete('/:id',
    auth,
    tagDescriptorController.deleteTagDescriptor)
    
export default router;