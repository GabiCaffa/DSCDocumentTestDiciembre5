//ServidorActualizado/routes/users.js
//Rutas para crear usuarios
import express from 'express';
import { check, body } from 'express-validator';
import userController from '../controllers/userController.js';
import auth from '../middlewares/auth.js';

const router = express.Router();

// crea un usuario 
// api/usuarios
router.post('/', 
    [
        check('name', 'El nombre es obligatorio').not().isEmpty(),
        check('email', 'El mail no es válido').isEmail(),
        check('domain', 'El dominio es obligatorio').not().isEmpty(),
        // Validación condicional de contraseña
        body('password').custom((value, { req }) => {
            const domain = req.body.domain;
            if (domain && domain.toLowerCase() !== 'prd') {
                if (!value || value.trim() === '') {
                    throw new Error('La contraseña es obligatoria para usuarios que no son del dominio PRD');
                }
                if (value.length < 6) {
                    throw new Error('La contraseña tiene que tener al menos 6 caracteres');
                }
            }
            return true;
        })
    ],
    userController.createUser);

router.get('/',
    auth,
    userController.getUsers) ;

router.put('/changeState/:id',
    auth,
    userController.updateUser) ;

router.put('/changePassword/',
    auth,
    userController.changePassword) ;

router.delete('/:id',
    auth,
    userController.deleteUser) ;

export default router;