import express from 'express';
import networkController from '../controllers/networkController.js';
import auth from '../middlewares/auth.js';

const router = express.Router();

/*
router.post('/',
    auth,
    [
        check('nodeName','El nombre del nodo no puede estar vacío').not().isEmpty(),
        check('asset','El asset no puede estar vacío').not().isEmpty()
    ],
    networkController.addNetworkNode) ;
*/
router.get('/',
    auth,
    networkController.getAreas) ;

router.get('/:id',
    auth,
    networkController.getAreaById) ;
/*
router.put('/:id',
    auth,
    networkController.updateNetworkNode) ;

router.delete('/:id',
    auth,
    networkController.deleteNetworkNode) ;
*/    

export default router;