import express from 'express';
import { check } from 'express-validator';
import systemController from '../controllers/systemController.js';
import auth from '../middlewares/auth.js';

const router = express.Router();

router.post('/',
    auth,
    [
        check('name','El nombre del system no puede estar vacío').not().isEmpty(),
        check('asset','El asset no puede estar vacío').not().isEmpty()
    ],
    systemController.addSystem) ;

router.get('/',
    auth,
    systemController.getSystems) ;
    router.get('/:id',
    auth,
    systemController.getSystemAndAssetById) ;
router.put('/:id',
    auth,
    systemController.updateSystem) ;

router.delete('/:id',
    auth,
    systemController.deleteSystems) ;
    
export default router;