//Rutas para crear usuarios
import express from 'express';
import { check } from 'express-validator';
import connectionController from '../controllers/connectionController.js';
import auth from '../middlewares/auth.js';

const router = express.Router();

// crea un usuario 
// api/usuarios
router.post('/', 
connectionController.createConnection);

router.get('/',
    auth,
    connectionController.getConnections) ;

router.delete('/:id',
    auth,
    connectionController.deleteConnection) ;

export default router;