//ServidorActualizado/routes/tree.js
import express from 'express';
import { check } from 'express-validator';
import treeController from '../controllers/treeController.js';
import auth from '../middlewares/auth.js';

const router = express.Router();

router.get('/',
    auth,
    treeController.getTree) ;

export default router;