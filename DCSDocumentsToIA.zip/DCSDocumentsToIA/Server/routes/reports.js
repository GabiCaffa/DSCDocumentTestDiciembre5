// ServidorActualizado/routes/reports.js
import express from 'express';
import { check } from 'express-validator';
import reportController from '../controllers/reportController.js';

const router = express.Router();

// Crear un nuevo reporte
router.post(
  '/',
  [
    check('name', 'El nombre es obligatorio').not().isEmpty(),
    check('user', 'El usuario es obligatorio').not().isEmpty(),
    check('password', 'La contraseña es obligatoria').not().isEmpty(),
    check('datasource', 'El datasource es obligatorio').not().isEmpty(),
    check('query', 'La consulta es obligatoria').not().isEmpty()
  ],
  reportController.addReport
);

// Actualizar un reporte existente
router.put(
  '/:id',
  [
    check('name', 'El nombre es obligatorio').not().isEmpty(),
    check('user', 'El usuario es obligatorio').not().isEmpty(),
    check('password', 'La contraseña es obligatoria').not().isEmpty(),
    check('datasource', 'El datasource es obligatorio').not().isEmpty(),
    check('query', 'La consulta es obligatoria').not().isEmpty()
  ],
  reportController.updateReport
);

// Obtener todos los reportes
router.get('/', reportController.getReports);

// NUEVO: Ejecutar reporte CON parámetros
router.post('/execute/:name', reportController.executeReportWithParams);

// Ejecutar reporte SIN parámetros (query original)
router.get('/execute/:name', reportController.executeReport);

// Obtener un reporte por nombre
router.get('/name/:reportName', reportController.getReportByName);

// Obtener un reporte por ID
router.get('/:id', reportController.getReport);

// Eliminar un reporte
router.delete('/:id', reportController.deleteReport);

export default router;