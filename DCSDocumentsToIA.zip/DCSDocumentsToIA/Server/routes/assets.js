import express from 'express';
import { check } from 'express-validator';
import assetController from '../controllers/assetController.js';
import auth from '../middlewares/auth.js';

const router = express.Router();

router.post('/',
    auth,
    [
        check('name','El nombre del Asset no puede estar vacío').not().isEmpty()
    ],
    assetController.createAsset) ;

router.get('/',
    auth,
    assetController.getAssets) ;


router.put('/:id',
     auth,
     assetController.updateAsset) ;

router.delete('/:id',
    auth,
    assetController.deleteAsset) ;
    
export default router;