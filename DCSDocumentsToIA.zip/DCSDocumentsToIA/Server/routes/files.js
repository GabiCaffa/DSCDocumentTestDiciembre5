import express from 'express';
import { check } from 'express-validator';
import fileController from '../controllers/fileController.js';
import auth from '../middlewares/auth.js';

const router = express.Router();

router.post('/',
    auth,
    fileController.processFile) ;


export default router;