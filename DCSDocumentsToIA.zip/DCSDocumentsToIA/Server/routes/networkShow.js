// routes/networkShow.js
import express from 'express';
import { check } from 'express-validator';
import networkController from '../controllers/networkController.js';
import auth from '../middlewares/auth.js';

const router = express.Router();
    
router.get('/',
    auth,
    networkController.createNetworkNodeShowRun) ;

export default router;