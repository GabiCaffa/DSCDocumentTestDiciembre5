import express from 'express';
import { check } from 'express-validator';
import tagDescriptorController from '../controllers/tagDescriptorController.js';
import auth from '../middlewares/auth.js';

const router = express.Router();

router.get('/',
    auth,
    tagDescriptorController.createDocument) ;

export default router;