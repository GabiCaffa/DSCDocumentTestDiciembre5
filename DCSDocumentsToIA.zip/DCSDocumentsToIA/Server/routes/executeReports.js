import express from 'express';
import reportController from '../controllers/reportController.js';
import auth from '../middlewares/auth.js';

const router = express.Router();

// Ejecutar un reporte por ID
/*router.get('/:id', 

    reportController.executeReport 
);

export default router;*/