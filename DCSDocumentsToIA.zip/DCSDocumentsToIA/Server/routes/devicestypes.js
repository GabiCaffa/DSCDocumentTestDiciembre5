import express from 'express';
import { check } from 'express-validator';
import deviceController from '../controllers/deviceController.js';
import auth from '../middlewares/auth.js';

const router = express.Router();

router.get('/',
    auth,
    deviceController.getDeviceTypes) ;

router.get('/:id',
    auth,
    deviceController.getDeviceTypesByID) ;
/*
router.put('/:id',
    auth,
    networkController.updateNetworkNode) ;

router.delete('/:id',
    auth,
    networkController.deleteNetworkNode) ;
*/    

export default router;