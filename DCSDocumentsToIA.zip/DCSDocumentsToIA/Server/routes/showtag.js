import express from 'express';
import tagDescriptorController from '../controllers/tagDescriptorController.js';

const router = express.Router();

router.get('/:id',
    tagDescriptorController.getTagDescriptor) ;

export default router;