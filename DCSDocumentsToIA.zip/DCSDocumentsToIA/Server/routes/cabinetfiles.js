import express from 'express';
import { check } from 'express-validator';
import fileCabController from '../controllers/fileCabinetController.js';
import auth from '../middlewares/auth.js';

const router = express.Router();

router.post('/:id',
    auth,
    fileCabController.uploadFile);

// router.get('/',
//     roomController.getRooms) ;


// router.put('/:id',
//      roomController.updateRoom) ;

router.delete('/:id',
    fileCabController.deleteFile);

export default router;