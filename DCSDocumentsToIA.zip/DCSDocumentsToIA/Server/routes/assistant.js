// routes/assistant.js
import express from 'express';
import assistantController from '../controllers/assistantController.js';
import optionalAuth from '../middlewares/optionalAuth.js';

const router = express.Router();

// Endpoint principal del chat
// Usa optionalAuth para permitir acceso con o sin login
router.post('/chat', optionalAuth, assistantController.chat);

// Endpoint para obtener contexto
// También con autenticación opcional
router.get('/context', optionalAuth, assistantController.getContext);

export default router;