//Rutas para crear autenticar
import express from 'express';
import tagDescriptorController from '../controllers/tagDescriptorController.js';
import auth from '../middlewares/auth.js';

const router = express.Router();

// Iniciar sesión
// api/auth
/*router.post('/', 
    authController.authUser
    );
*/
// loguea un usuario
router.get('/:id', 
    //auth,
    tagDescriptorController.getAlarmasyEventos);

export default router;