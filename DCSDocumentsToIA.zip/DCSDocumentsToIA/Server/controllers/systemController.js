//controllers/systemController.js
import { validationResult } from 'express-validator';
import System from '../models/System.js';
import Asset from '../models/Asset.js';
import TagDescriptor from '../models/TagDescriptor.js';

export const addSystem = async (req, res) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    try {
        const asset_updated = await Asset.findById(req.body.asset);
        if (!asset_updated) {
            return res.status(404).send("No existe el asset");
        }

        const new_systems = new System(req.body);
        await new_systems.save();

        res.json({ new_systems });

    } catch (error) {
        console.log(error);
        res.status(500).send({ msg: "No se pudo crear el sistema, contacte a un administrador" });
    }
};

export const updateSystem = async (req, res) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    try {
        const asset_updated = await Asset.findById(req.body.asset);
        if (!asset_updated) {
            return res.status(404).send({ msg: "No existe el asset" });
        }

        let systems_updated = await System.findById(req.params.id);
        if (!systems_updated) {
            return res.status(404).send({ msg: "No existe el sistema" });
        }

        const { name, active } = req.body;

        if (name !== undefined) systems_updated.name = name;
        if (active !== undefined) systems_updated.active = active;

        systems_updated = await System.findByIdAndUpdate(
            req.params.id,
            { name: systems_updated.name, active: systems_updated.active },
            { new: true }
        );

        res.json({ systems_updated });

    } catch (error) {
        console.log(error);
        res.status(500).send({ msg: "Error actualizando el sistema" });
    }
};

export const getSystems = async (req, res) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    try {
        const { asset } = req.query;

        const asset_updated = await Asset.findById(asset);
        if (!asset_updated) {
            return res.status(404).send({ res: "No existe el asset" });
        }

        const systems = await System.find({ asset: asset_updated._id }).sort({ creado: -1 });
        res.json({ systems });

    } catch (error) {
        console.log(error);
        res.status(500).send({ msg: "No se pudo obtener los sistemas para este asset" });
    }
};

export const getSystemAndAssetById = async (req, res) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    try {
        const { idSystem } = req.query;
        const system = await System.findById(idSystem);

        if (!system) {
            return res.status(404).send({ res: "No existe el system" });
        }

        const asset = await Asset.findById(system.asset);
        if (!asset) {
            return res.status(404).send({ res: "No existe el asset" });
        }

        const resp = {
            systemName: system.name,
            assetName: asset.name
        };

        res.json({ resp });

    } catch (error) {
        console.log(error);
        res.status(500).send({ msg: "No se pudo obtener los datos del sistema" });
    }
};


export const deleteSystems = async (req, res) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    try {
        const { idAsset } = req.query;

        const asset_updated = await Asset.findById(idAsset);
        if (!asset_updated) {
            return res.status(404).send("No existe el asset");
        }

        const tagdescriptors = await TagDescriptor.find({ system: req.params.id });
        for (const tg of tagdescriptors) {
            await TagDescriptor.findByIdAndDelete(tg._id);
        }

        await System.findByIdAndDelete(req.params.id);

        res.json({ msg: "Sistema eliminado" });

    } catch (error) {
        console.log(error);
        res.status(500).send({ msg: "No se pudo eliminar el sistema, contacte a un administrador" });
    }
};
export default {
  addSystem,
  updateSystem,
  getSystems,
  getSystemAndAssetById,
  deleteSystems
};