//controllers/userController.js
import { validationResult } from 'express-validator';
import bcryptjs from 'bcryptjs';
import jwt from 'jsonwebtoken';
import ActiveDirectory from 'activedirectory';
import User from '../models/User.js';

const createUser = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { name, email, password, rol, domain } = req.body;

  try {
    const existingUserByEmail = await User.findOne({ email });
    if (existingUserByEmail) {
      return res.status(400).json({ msg: 'Ya existe un usuario con este email' });
    }

    const existingUserByName = await User.findOne({ name });
    if (existingUserByName) {
      return res.status(400).json({ msg: 'Ya existe un usuario con este nombre' });
    }

    if (domain.toUpperCase() === 'PRD') {    
      try {
        const newUser = new User({
          name,
          email,
          password: null, 
          rol,
          domain: 'PRD'
        });

        await newUser.save();
        return res.json({ 
          msg: 'Usuario del dominio PRD creado correctamente (sin contraseña)',
          user: {
            _id: newUser._id,
            name: newUser.name,
            email: newUser.email,
            rol: newUser.rol,
            domain: newUser.domain,
            state: newUser.state
          }
        });
      } catch (saveError) {
        console.error('Error guardando usuario PRD:', saveError);
        return res.status(500).json({ msg: 'Error guardando el usuario PRD en la base de datos' });
      }
    }

    if (!password || password.trim() === '') {
      return res.status(400).json({ msg: 'La contraseña es obligatoria para usuarios locales' });
    }

    const newUser = new User({ 
      name, 
      email, 
      password, 
      rol, 
      domain: domain.toUpperCase() 
    });

    const salt = await bcryptjs.genSalt(10);
    newUser.password = await bcryptjs.hash(password, salt);

    await newUser.save();

    res.json({ 
      msg: 'Usuario local creado correctamente',
      user: {
        _id: newUser._id,
        name: newUser.name,
        email: newUser.email,
        rol: newUser.rol,
        domain: newUser.domain,
        state: newUser.state
      }
    });

  } catch (error) {
    console.error('Error en createUser:', error);
    res.status(500).send("Hubo un error en la creación del usuario");
  }
};

const getUsers = async (req, res) => {
  try {
    const users = await User.find().sort({ createddate: 1 });
    res.json({ users });
  } catch (error) {
    console.log(error);
    res.status(500).send({ msg: "No se pudo obtener la lista de usuarios" });
  }
};

const updateUser = async (req, res) => {
  try {
    let user_updated = await User.findById(req.body._id);
    if (!user_updated) {
      return res.status(404).send({ msg: "No existe el usuario" });
    }

    if (req.user.id.toString() === user_updated._id.toString()) {
      return res.status(400).send({ msg: "No se puede deshabilitar el usuario con el que estás logueado" });
    }

    const { state } = req.body;
    if (state !== null) {
      user_updated.state = state;
    }

    user_updated = await User.findOneAndUpdate({ _id: user_updated._id }, user_updated, { new: true });
    res.json({ user_updated });

  } catch (error) {
    console.log(error);
    res.status(500).send({ msg: "Error actualizando el usuario" });
  }
};

const changePassword = async (req, res) => {
  try {
    let user = await User.findById(req.user.id);

    if (!user) {
      return res.status(404).send({ msg: "No existe el usuario" });
    }

    if (user.domain === 'PRD') {
      return res.status(400).send({ msg: "No se puede cambiar la contraseña de un usuario de dominio PRD desde aquí" });
    }

    const { password } = req.body;

    if (password) {
      const salt = await bcryptjs.genSalt(10);
      user.password = await bcryptjs.hash(password, salt);
    }

    user = await User.findOneAndUpdate({ _id: user._id }, user, { new: true });
    res.json({ user });

  } catch (error) {
    console.log(error);
    res.status(500).send({ msg: "Error cambiando la contraseña" });
  }
};

const deleteUser = async (req, res) => {
  try {
    const { id } = req.params;
        
    const user = await User.findById(id);

    if (!user) {
      return res.status(404).json({ msg: "No existe el usuario" });
    }

    // Opcional: Prevenir auto-eliminación
    if (req.user && req.user.id.toString() === user._id.toString()) {
      return res.status(400).json({ msg: "No puedes eliminar tu propio usuario" });
    }

    await User.findByIdAndDelete(user._id);
    
    res.json({ msg: "Usuario eliminado correctamente" });

  } catch (error) {
    res.status(500).json({ msg: "No se pudo eliminar el usuario", error: error.message });
  }
};

export default {
  createUser,
  getUsers,
  updateUser,
  changePassword,
  deleteUser
};