//controllers/networkController.js
import { validationResult } from 'express-validator';
import System from '../models/System.js';
import Asset from '../models/Asset.js';
import TagDescriptor from '../models/TagDescriptor.js';
import NetworkNode from '../models/NetworkNode.js';
import NetworkNodeModel from '../models/NetworkNodeModel.js';
import Area from '../models/Area.js';
import Connection from '../models/Connection.js';
import Device from '../models/Device.js';
import DeviceType from '../models/DeviceType.js';

import {
    getSNMP, 
    getSNMP_Sync, 
    connectSSHShow,         
    connectSSHShowTech      
} from './commController.js';

export const addNetworkNode = async (req, res) => {
    const errors = validationResult(req);
    
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    try {
        const asset_updated = await Asset.findById(req.body.asset);
        if (!asset_updated) {
            console.log("No existe el asset");
            return res.status(404).send("No existe el asset");
        }

        const new_networkNode = new NetworkNode(req.body);
        await new_networkNode.save();

        res.json({ new_networkNode });

    } catch ({ error }) {
        console.log(error);
        res.status(500).send({ msg: "No se pudo crear el nodo de red, contacte a un administrador" });
    }
};

export const updateNetworkNode = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    try {
        const asset_updated = await Asset.findById(req.body.asset);
        if (!asset_updated) {
            console.log("No existe el asset");
            return res.status(404).send({ msg: "No existe el asset" });
        }

        let networkNodeUpdated = await NetworkNode.findById(req.params.id);
        if (!networkNodeUpdated) {
            console.log("No existe el sistema");
            return res.status(404).send({ msg: "No existe el nodo de red" });
        }

        const { nodeName, nodeDescription, nodeModel, nodeIP, area } = req.body;
        if (nodeName !== null) {
            networkNodeUpdated.nodeName = nodeName;
        }
        if (nodeDescription !== null) {
            networkNodeUpdated.nodeDescription = nodeDescription;
        }
        if (nodeModel !== null) {
            networkNodeUpdated.nodeModel = nodeModel;
        }
        if (nodeIP !== null) {
            networkNodeUpdated.nodeIP = nodeIP;
        }
        if (area !== null) {
            networkNodeUpdated.area = area;
        }

        networkNodeUpdated = await NetworkNode.findOneAndUpdate({ _id: req.params.id }, networkNodeUpdated, { new: true });
        res.json({ networkNodeUpdated });

    } catch ({ error }) {
        console.log(error);
        res.status(500).send({ msg: "Error actualizando el nodo de red" });
    }
};

export const getNetworkNodes = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    try {
        const { asset } = req.query;
        const asset_updated = await Asset.findById(asset);
        if (!asset_updated) {
            console.log("No existe el asset");
            return res.status(404).send({ res: "No existe el asset" });
        }

        const networkNodes = await NetworkNode.find({ asset: asset_updated._id }).sort({ creado: -1 });
        res.json({ networkNodes });

    } catch ({ error }) {
        console.log(error);
        res.status(500).send({ msg: "No se pudo obtener los nodos de red para este asset" });
    }
};

export const getNetworkNodesAll = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    try {
        const networkNodes = await NetworkNode.find().sort({ creado: -1 });
        res.json({ networkNodes });

    } catch ({ error }) {
        console.log(error);
        res.status(500).send({ msg: "No se pudo obtener los nodos de red para este asset" });
    }
};

export const getNetworkNodeModels = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    try {
        const networkNodeModels = await NetworkNodeModel.find();
        res.json({ networkNodeModels });

    } catch ({ error }) {
        console.log(error);
        res.status(500).send({ msg: "No se pudo obtener los modelos de los nodos" });
    }
};

export const getNetworkModelByID = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    try {
        const idModelo = req.params.id;
        const networkModel_get = await NetworkNodeModel.findById(idModelo);
        
        if (!networkModel_get) {
            console.log("No existe el modelo del nodo de red");
            return res.status(404).send("No existe el modelo del nodo de red");
        }
        
        res.json({ networkModel_get });

    } catch ({ error }) {
        console.log(error);
        res.status(500).send({ msg: "No se pudo procesar el modelo del nodo de red, contacte a un administrador" });
    }
};

export const getNetworkNode = async (req, res) => {
    const errors = validationResult(req);
    
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    try {
        const community = "PM";
        //revisar el id
        const idNodo = req.params.id;
        //console.log('El ID es: ',idNodo)
        const network_node = await NetworkNode.findById(idNodo);
        const network_model = await NetworkNodeModel.findById(network_node.nodeModel);
        console.log('El netrwork node es: ', network_node);
        
        if (!network_node) {
            console.log("No existe el nodo de red");
            return res.status(404).send("No existe el nodo de red");
        }
       
        let network_get = network_node.toObject();
        network_get.status = [];
        /*let item = {
            interface: "",
            description: "",
            state: "",
            vlan: "",
            speed: "",
            duplex: "full-duplex",
            type: "1000BaseTX"
        }
        let oid_name;
        let oid_desc;
        let oid_state;
        let oid_speed;
        let oid_vlan;
        let oid_duplex;
        let x = 9
        //console.log("1")
        while (x<=network_model.port_fast+network_model.port_giga+8){
            //if (x > 9){
                oid_name="1.3.6.1.2.1.31.1.1.1.1." + x
                oid_desc="1.3.6.1.2.1.31.1.1.1.18." + x
                oid_state="1.3.6.1.2.1.2.2.1.8." + x
                oid_speed="1.3.6.1.2.1.2.2.1.5." + x
                oid_vlan="1.3.6.1.4.1.9.9.68.1.2.2.1.2." + x
                oid_alias="1.3.6.1.2.1.31.1.1.1.18." + x
                oid_duplex="1.3.6.1.2.1.10.7.2.1.19." + x
            /*}else{
                oid_name="1.3.6.1.2.1.31.1.1.1.1.1010"  + x
                oid_desc="1.3.6.1.2.1.31.1.1.1.18.1010" + x
                oid_state="1.3.6.1.2.1.2.2.1.8.1010" + x
                oid_speed="1.3.6.1.2.1.2.2.1.5.1000" + x
                oid_vlan="1.3.6.1.4.1.9.9.68.1.2.2.1.2.1010" + x
                oid_alias="1.3.6.1.2.1.31.1.1.1.18.1010" + x
                oid_duplex="1.3.6.1.2.1.10.7.2.1.19.1010" + x
            }
            //console.log(x + "--" + await getSNMP_Sync(network_get.nodeIP,community,["1.3.6.1.2.1.2.2.1.5.2"]));
            //console.log(network_get.nodeIP,community,[oid_name])
            item.interface = await getSNMP_Sync(network_get.nodeIP,community,[oid_name])
            //console.log(item.interface)
            item.description = await getSNMP_Sync(network_get.nodeIP,community,[oid_desc])
            item.state = await getSNMP_Sync(network_get.nodeIP,community,[oid_state])
            item.state === "1" ? item.state = "up" : item.state = "down"
            item.speed = await getSNMP_Sync(network_get.nodeIP,community,[oid_speed])
            item.speed = parseInt(item.speed)/1000000
            
            item.vlan = await getSNMP_Sync(network_get.nodeIP,community,[oid_vlan])
            item.duplex = await getSNMP_Sync(network_get.nodeIP,community,[oid_duplex])
            //console.log("termine consultas snmp")
            //console.log(x + " - " + item.speed)
            x+=1
            network_get.status.push(item);
            item = {
                interface: "",
                description: "",
                state: "",
                vlan: "",
                speed: "",
                duplex: ""
            }
            
        }
        //console.log(2)
        //x = 1
        /*while (x<=network_model.port_giga){
            if (x > 9){
                oid_name="1.3.6.1.2.1.31.1.1.1.1." + x
                oid_desc="1.3.6.1.2.1.31.1.1.1.18." + x
                oid_state="1.3.6.1.2.1.2.2.1.8." + x
                oid_speed="1.3.6.1.2.1.2.2.1.5." + x
                oid_vlan="1.3.6.1.4.1.9.9.68.1.2.2.1.2." + x
                oid_alias="1.3.6.1.2.1.31.1.1.1.18.101" + x
                oid_duplex="1.3.6.1.2.1.10.7.2.1.19.101" + x
            }else{
                oid_name="1.3.6.1.2.1.31.1.1.1.1.1010"  + x
                oid_desc="1.3.6.1.2.1.31.1.1.1.18.1010" + x
                oid_state="1.3.6.1.2.1.2.2.1.8.1010" + x
                oid_speed="1.3.6.1.2.1.2.2.1.5.1010" + x
                oid_vlan="1.3.6.1.4.1.9.9.68.1.2.2.1.2.1010" + x
                oid_alias="1.3.6.1.2.1.31.1.1.1.18.1010" + x
                oid_duplex="1.3.6.1.2.1.10.7.2.1.19.1010" + x
            }

            item.interface = await getSNMP_Sync(network_get.nodeIP,community,[oid_name])
            item.description = await getSNMP_Sync(network_get.nodeIP,community,[oid_desc])
            item.state = await getSNMP_Sync(network_get.nodeIP,community,[oid_state])
            item.state === "1" ? item.state = "up" : item.state = "down"
            item.speed = await getSNMP_Sync(network_get.nodeIP,community,[oid_speed])
            
            item.speed = parseInt(item.speed)/1000000

            item.vlan = await getSNMP_Sync(network_get.nodeIP,community,[oid_vlan])
            item.duplex = await getSNMP_Sync(network_get.nodeIP,community,[oid_duplex])
            
            x+=1
            network_get.status.push(item);
            item = {
                interface: "",
                description: "",
                state: "",
                vlan: "",
                speed: "",
                duplex: ""
            }
        }*/
        //console.log(network_get)
        res.json({ network_get });

    } catch ({ error }) {
        //console.log("error")
        console.log(error);
        res.status(500).send({ msg: "No se pudo eliminar el nodo de red, contacte a un administrador" });
    }
};

export const deleteNetworkNode = async (req, res) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    try {
        const idNodo = req.params.id;
        const network_deleted = await NetworkNode.findById(idNodo);
        if (!network_deleted) {
            console.log("No existe el nodo de red");
            return res.status(404).send("No existe el nodo de red");
        }
        
        await NetworkNode.findByIdAndDelete(network_deleted._id);
        
        res.json({ msg: "Nodo de red eliminado correctamente" });

    } catch (error) {
        res.status(500).json({ msg: "No se pudo eliminar el nodo de red", error: error.message });
    }
}

export const createNetworkNodeShowRun = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    try {
        const { data } = req.query;
        const { ip, tipo } = JSON.parse(data);
        const community = "PM";

        const networkNode = await NetworkNode.findOne({ nodeIP: ip });
        
        let nodeName;
        if (networkNode) {
            nodeName = networkNode.nodeName;
            console.log(`Nodo encontrado en BD: ${nodeName} (${ip})`);
        } else {
            let hostname = await getSNMP_Sync(ip, community, ['1.3.6.1.2.1.1.5.0']);
            
            if (!hostname || hostname === '') {
                console.log("No se pudo obtener hostname via SNMP y no existe en BD, usando IP");
                nodeName = `switch-${ip.replace(/\./g, '-')}`;
            } else {
                nodeName = hostname.split(".")[0]; 
            }
            console.log(`Nodo NO encontrado en BD, usando: ${nodeName}`);
        }

        console.log(`Iniciando conexión SSH a ${nodeName} (${ip}) para comando: show ${tipo}`);

        let show_run;
        if (tipo.toLowerCase() === 'tech' || tipo.toLowerCase() === 'tech-support') {
            show_run = await connectSSHShowTech(nodeName, ip, tipo);
        } else {
            show_run = await connectSSHShow(nodeName, ip, tipo);
        }
        
        console.log(`SSH exitoso para ${nodeName}, archivo generado: ${show_run}`);
        return res.json({ filename: show_run });
           
    } catch (error) {
        console.error('Error en createNetworkNodeShowRun SSH:', error.message);
        res.status(500).send({
            msg: `No se pudo obtener la configuración del nodo de red via SSH: ${error.message}. Contacte a un administrador`
        });
    }
};

export const getArchitectureNodes = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    try {
        const networkNodes = await NetworkNode.find();

        let nodes = [];
        for (const nn of networkNodes) {
            let newNn = {};
            newNn.id = nn.nodeName;
            newNn.node = nn.nodeName;
            newNn.area = nn.area;
            const networkModel = await NetworkNodeModel.findById(nn.nodeModel);
            newNn.url = networkModel.url;
            newNn.devicetype = "Switch";
            nodes.push(newNn);
        }
        
        const connectionsArray = await Connection.find({ type: 'core' });
        let connections = [];

        for (const cc of connectionsArray) {
            let new_connection = {};
            new_connection.ids = cc.source;
            new_connection.idt = cc.target;
            new_connection.description = cc.description;
            connections.push(new_connection);
        }
        
        let coreArchitecture = {};
        coreArchitecture.nodes = nodes;
        coreArchitecture.connections = connections;
        res.json({ coreArchitecture });
        
    } catch ({ error }) {
        console.log(error);
        res.status(500).send({ msg: "No se pudo obtener los nodos y conexiones del core de la red" });
    }
};

export const getArchitectureDevices = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    try {
        const { networkNode } = req.query;
        const connectionsArray = await Connection.find({ source: networkNode, type: 'access' });
        
        let nodes = [];
        let connections = [];
        let new_connection = {};

        let newNn = {}; 
        newNn.id = networkNode;
        newNn.idMongo = networkNode;
        newNn.node = networkNode;
        newNn.level = 2;
        const nNode = await NetworkNode.find({ nodeName: networkNode });
        const networkModel = await NetworkNodeModel.findById(nNode[0].nodeModel);
        newNn.url = networkModel.url;
        newNn.devicetype = "Switch";
        nodes.push(newNn);

        for (const cc of connectionsArray) {
            newNn = {};
            let nn = await Device.find({ deviceName: cc.target });
            
            if (nn[0]) {
                newNn.idMongo = nn[0]._id;
                newNn.id = nn[0].deviceName;
                newNn.node = nn[0].deviceName;
                let tipodevice = await DeviceType.findById(nn[0].deviceType);
                newNn.devicetype = tipodevice.type;
                newNn.url = tipodevice.url;
                newNn.level = 1;
                nodes.push(newNn);
                nn = null;
                
                if (tipodevice.type === 'CF9') {
                    let connectionsArray0 = await Connection.find({ source: newNn.node });
                    newNn = null;
                    newNn = {};
                    
                    for (const cc of connectionsArray0) {
                        nn = await Device.find({ deviceName: cc.target });
                        if (nn[0]) {
                            newNn.id = nn[0].deviceName;
                            newNn.idMongo = nn[0]._id;
                            newNn.node = nn[0].deviceName;
                            tipodevice = await DeviceType.findById(nn[0].deviceType);
                            newNn.devicetype = tipodevice.type;
                            newNn.url = tipodevice.url;
                            newNn.level = 0;
                            nodes.push(newNn);
                            newNn = null;
                            newNn = {};
                            nn = null;
                        }
                        
                        new_connection = {};
                        new_connection.ids = cc.source;
                        new_connection.idt = cc.target;
                        new_connection.description = cc.description;
                        connections.push(new_connection);
                    }
                }

                new_connection = {};
                new_connection.ids = cc.source;
                new_connection.idt = cc.target;
                new_connection.description = cc.description;
                connections.push(new_connection);
            }
        }
        
        let accessArchitecture = {};
        accessArchitecture.nodes = nodes;
        accessArchitecture.connections = connections;
        res.json({ accessArchitecture });

    } catch ({ error }) {
        console.log(error);
        res.status(500).send({ msg: "No se pudo obtener los nodos de red para este asset" });
    }
};

export const getAreas = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    try {
        const areas = await Area.find();
        res.json({ areas });

    } catch ({ error }) {
        console.log(error);
        res.status(500).send({ msg: "No se pudo obtener los modelos de los nodos" });
    }
};

export const getAreaById = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    try {
        const idArea = req.params.id;
        const area = await Area.findById(idArea);
        
        if (!area) {
            console.log("No existe el area");
            return res.status(404).send("No existe el area");
        }
        
        res.json({ area });

    } catch ({ error }) {
        console.log(error);
        res.status(500).send({ msg: "No se pudo procesar el modelo del nodo de red, contacte a un administrador" });
    }
};

export const getNetworkNodeID = async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    
    try {
        const { networknode } = req.query;
        const idnetworknodeconsulta = await NetworkNode.find({ nodeName: networknode });
        
        if (!idnetworknodeconsulta || idnetworknodeconsulta.length === 0) {
            console.log("No existe el nodo");
            return res.status(404).send("No existe el nodo");
        }
        
        const idnetworknode = idnetworknodeconsulta[0]._id;
        res.json({ idnetworknode });

    } catch ({ error }) {
        console.log(error);
        res.status(500).send({ msg: "No se pudo procesar el nodo de red, contacte a un administrador" });
    }
};

export default {
    addNetworkNode,
    updateNetworkNode,
    getNetworkNodes,
    getNetworkNodesAll,
    getNetworkNodeModels,
    getNetworkModelByID,
    getNetworkNode,
    deleteNetworkNode,
    createNetworkNodeShowRun,
    getArchitectureNodes,
    getArchitectureDevices,
    getAreas,
    getAreaById,
    getNetworkNodeID
};
//end export default