//ServidorActualizado/controllers/authController.js
import User from '../models/User.js';
import bcryptjs from 'bcryptjs';
import { validationResult } from 'express-validator';
import jwt from 'jsonwebtoken';
import ActiveDirectory from 'activedirectory';

//  Config común para el dominio PRD
const adBaseConfig = {
  url: 'ldap://10.10.1.200:389',
  baseDN: 'dc=PRD,dc=local'
};

const authUser = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(400).json({ msg: 'No existe el usuario registrado' });
    }

    if (user.state === 'INACTIVE') {
      return res.status(400).json({ msg: 'El usuario no está activo' });
    }

    if (user.domain && user.domain.toUpperCase() === 'PRD') {
      const usernameAD = user.email;
      
      const adConfig = {
        ...adBaseConfig,
        username: usernameAD,
        password: password
      };

      const ad = new ActiveDirectory(adConfig);

      ad.authenticate(usernameAD, password, (err, auth) => {
        if (err) {
          console.error('Error LDAP:', err);
          return res.status(500).json({ msg: 'Error al conectar con el dominio' });
        }

        if (!auth) {
          return res.status(400).json({ msg: 'Credenciales inválidas para el dominio PRD' });
        }

        const payload = {
          user: {
            id: user.id
          }
        };

        jwt.sign(payload, process.env.CERTIFICADO, {
          expiresIn: '8h' // Cambiado a 8 horas
        }, (error, token) => {
          if (error) throw error;
          res.json({ token });
        });
      });

    } else {
      if (!user.password || user.password.trim() === '') {
        return res.status(400).json({ msg: 'Este usuario no tiene contraseña configurada' });
      }

      const passwordOk = await bcryptjs.compare(password, user.password);

      if (!passwordOk) {
        return res.status(400).json({ msg: 'Contraseña incorrecta' });
      }

      const payload = {
        user: {
          id: user.id
        }
      };

      jwt.sign(payload, process.env.CERTIFICADO, {
        expiresIn: '8h' // Cambiado a 8 horas
      }, (error, token) => {
        if (error) throw error;
        res.json({ token });
      });
    }

  } catch (error) {
    console.log('Error en login:', error);
    res.status(500).json({ msg: 'Error del servidor' });
  }
};

const getUser = async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password');
    res.json({ user });
  } catch (error) {
    console.log('Error al obtener usuario:', error);
    res.status(500).json({ msg: 'Error del servidor' });
  }
};

export default {
  authUser,
  getUser
};