//controllers/treeController.js
import { validationResult } from 'express-validator';
import Asset from '../models/Asset.js';
import System from '../models/System.js';

export const getTree = async (req, res) => {
    //valido errores
    const errors = validationResult(req);
        
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    try {
        const assets = await Asset.aggregate([{
            $lookup: {
                from: 'systems',
                localField: '_id',
                foreignField: 'asset',
                as: 'nodes'
            }
        }]);
        
        res.json({ assets });
    } catch (error) {
        console.log(error);
        res.status(500).send({ msg: "Error en obtener el tree assets" });
    }
};

export default {
  getTree
};