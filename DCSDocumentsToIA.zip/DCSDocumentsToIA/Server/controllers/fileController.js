//controllers/fileController.js
import multer from 'multer';
import shortid from 'shortid';
import fs from 'fs';
import readXlsxFile from 'read-excel-file/node';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import NetworkNode from '../models/NetworkNode.js';
import TagDescriptor from '../models/TagDescriptor.js';
import Device from '../models/Device.js';
import Connection from '../models/Connection.js';
import Cabinet from '../models/Cabinet.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const multerConfiguration = {
    limits: { fileSize: 20 * 1024 * 1024 },
    storage: multer.diskStorage({
        destination: (req, file, cb) => {
            cb(null, '../servidor/files')
        }, 
        filename: (req, file, cb) => {
            const extension = "xls";
            cb(null, `file_to_process.${extension}`);
        }
    })
};

const upload = multer(multerConfiguration).single('fileToProcess');

export const processFile = async (req, res) => {
    try {
        upload(req, res, async (error) => {
            if (!error) {
                const dataSheet1 = await readXlsxFile('../servidor/files/file_to_process.xls', { sheet: 1 });
                const model = dataSheet1[0][1];
                const dataSheet2 = await readXlsxFile('../servidor/files/file_to_process.xls', { sheet: 2 });
                let headers = true;
                for (const row in dataSheet2) {
                    if (headers) {
                        headers = false;
                    } else {
                        try {
                            await processRow(model, dataSheet2[0], dataSheet2[row]);
                        } catch (error) {
                            const errorMsg = `${error.message} (fila ${row})`;
                            res.status(500).send({ msg: errorMsg });
                            return;
                        }
                    }
                }
                res.json({ msg: "se procesó el archivo correctamente" });
                return;
            }
        });
    }
    catch (error) {
        res.status(500).send({ msg: error.message });
    }
};

const processRow = async (model, headers, values) => {
    var obj = {};
    headers.forEach((header, i) => obj[header] = values[i]);

    if (model === "networknodes") {
        const new_networkNode = new NetworkNode(obj);
        await new_networkNode.save();
    }
    if (model === "devices") {
        const new_device = new Device(obj);
        await new_device.save();
    }
    if (model === "connections") {
        const new_connection = new Connection(obj);
        await new_connection.save();
    }
    if (model === "TagDescriptor") {
        let tagdescriptor = new TagDescriptor(obj);
        if (tagdescriptor.tagname) {
            tagdescriptor.tagname = tagdescriptor.tagname.toUpperCase();
        }
        const tagdescriptor_validation = await TagDescriptor.find({ tagname: tagdescriptor.tagname }).sort({ creado: -1 });
        if (tagdescriptor_validation.length > 0) {
            throw new Error('Ya existe un descriptor con ese tagname');
        }

        await tagdescriptor.save();
    }
    if (model === "cabinets") {
        let files_append = [];
        obj.files.split(",").forEach((img_src) => files_append.push(img_src));
        obj.files = files_append.reverse();
        const new_Cabinet = new Cabinet(obj);
        await new_Cabinet.save();
    }
};

export default {
  processFile
};