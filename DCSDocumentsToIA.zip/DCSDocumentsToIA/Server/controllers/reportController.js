// controllers/reportController.js
import { validationResult } from 'express-validator';
import crypto from 'crypto';
import sql from 'mssql';
import Report from '../models/Report.js';
import System from '../models/System.js';

const algorithm = 'aes-256-cbc';
const key = Buffer.from('23cff8209fd8937ac50ee090d5f56d46');
const iv = Buffer.from('62f92b68285443c0');

function encrypt(text) {
  const cipher = crypto.createCipheriv(algorithm, key, iv);
  const encrypted = Buffer.concat([cipher.update(text, 'utf8'), cipher.final()]);
  return { iv: iv.toString('hex'), content: encrypted.toString('hex') };
}

function decrypt(encrypted) {
  if (!encrypted || !encrypted.iv || !encrypted.content) {
    throw new Error('Datos de encriptación inválidos');
  }
  const decipher = crypto.createDecipheriv(
    algorithm,
    key,
    Buffer.from(encrypted.iv, 'hex')
  );
  const decrypted = Buffer.concat([
    decipher.update(Buffer.from(encrypted.content, 'hex')),
    decipher.final()
  ]);
  return decrypted.toString('utf8');
}

// Crear un nuevo reporte
export const addReport = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  let { user, password, name, datasource, query, system, parameters } = req.body;
  try {
    const existingReport = await Report.findOne({ name });
    if (existingReport) {
      return res.status(400).json({ msg: 'Ya existe un reporte con ese nombre' });
    }

    const passwordHashed = encrypt(password);
    const { iv, content } = passwordHashed;
    name = name.toUpperCase();

    // Limpiar parámetros: eliminar los que tienen campos vacíos
    let cleanParameters = [];
    if (Array.isArray(parameters)) {
      cleanParameters = parameters.filter(param => 
        param.name && 
        param.name.trim() !== '' && 
        param.label && 
        param.label.trim() !== '' && 
        param.type && 
        param.sqlField && 
        param.sqlField.trim() !== ''
      );
    }

    const newReport = new Report({
      user,
      password: content,
      iv,
      name,
      datasource,
      query,
      parameters: cleanParameters,
      system
    });

    await newReport.save();

    const reportObj = newReport.toObject();
    delete reportObj.password;

    res.json({ report: [reportObj] });
  } catch (error) {
    console.error('Error al crear reporte:', error);
    res.status(500).send({ msg: 'No se pudo crear el reporte, contacte al administrador' });
  }
};

// Actualizar un reporte existente
export const updateReport = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  let { user, password, name, datasource, query, parameters } = req.body;

  try {
    const report = await Report.findById(req.params.id);
    if (!report) {
      return res.status(404).send({ msg: 'No existe el reporte' });
    }

    if (name !== report.name) {
      const existingReport = await Report.findOne({ name });
      if (existingReport) {
        return res.status(400).json({ msg: 'Ya existe un reporte con ese nombre' });
      }
    }

    const passwordHashed = encrypt(password);
    const { iv, content } = passwordHashed;

    // Limpiar parámetros: eliminar los que tienen campos vacíos
    let cleanParameters = [];
    if (Array.isArray(parameters)) {
      cleanParameters = parameters.filter(param => 
        param.name && 
        param.name.trim() !== '' && 
        param.label && 
        param.label.trim() !== '' && 
        param.type && 
        param.sqlField && 
        param.sqlField.trim() !== ''
      );
    }

    report.user = user;
    report.password = content;
    report.iv = iv;
    report.name = name;
    report.datasource = datasource;
    report.query = query;
    report.parameters = cleanParameters;

    await report.save();

    const reportObj = report.toObject();
    delete reportObj.password;

    res.json({ report: [reportObj] });
  } catch (error) {
    console.error('Error al actualizar reporte:', error);
    res.status(500).send({ msg: 'Error actualizando el reporte' });
  }
};

// Obtener un reporte por ID
export const getReport = async (req, res) => {
  try {
    const report = await Report.findById(req.params.id.trim());
    if (!report) {
      return res.status(404).send({ msg: 'No existe el reporte' });
    }

    const reportObj = report.toObject();
    const passwordHashed = { iv: reportObj.iv, content: reportObj.password };
    reportObj.password = decrypt(passwordHashed);

    res.json({ report: [reportObj] });
  } catch (error) {
    console.error(error);
    res.status(500).send('Hubo un error');
  }
};

// Obtener todos los reportes
export const getReports = async (req, res) => {
  try {
    const { system } = req.query;
    const system_updated = await System.findById(system);
    if (!system_updated) {
      return res.status(404).send("No existe el sistema");
    }

    const reports = await Report.find({ system: system_updated._id }).sort({ creado: -1 });
    const reportsSanitized = reports.map(rep => {
      const obj = rep.toObject();
      const passwordHashed = { iv: obj.iv, content: obj.password };
      obj.password = decrypt(passwordHashed);
      return obj;
    });

    res.json({ reports: reportsSanitized });
  } catch (error) {
    console.error(error);
    res.status(500).send('Hubo un error');
  }
};

// NUEVO: Ejecutar reporte CON parámetros
export const executeReportWithParams = async (req, res) => {
  try {
    const reportName = req.params.name.trim();
    const { parameters } = req.body;

    const report = await Report.findOne({ name: reportName.toUpperCase() });
    if (!report) {
      return res.status(404).json({ msg: 'Reporte no encontrado' });
    }

    // Construir la query con los parámetros
    const modifiedQuery = buildQueryWithParameters(report.query, parameters, report.parameters);
    
    // Solo mostrar la query generada
    console.log(`[${reportName}] Query ejecutada:`, modifiedQuery);
    
    const result = await runReportQuery(report, modifiedQuery);
    res.json({ result });
  } catch (error) {
    console.error('Error ejecutando reporte con parámetros:', error);
    res.status(500).json({ msg: 'Error al ejecutar el reporte', error: error.message });
  }
};

// Ejecutar reporte SIN parámetros (query original)
export const executeReport = async (req, res) => {
  try {
    const reportName = req.params.name.trim();
    const report = await Report.findOne({ name: reportName.toUpperCase() });
    if (!report) {
      return res.status(404).json({ msg: 'Reporte no encontrado' });
    }
    
    console.log(`[${reportName}] Query ejecutada:`, report.query);
    
    const result = await runReportQuery(report, report.query);
    res.json({ result });
  } catch (error) {
    console.error(error);
    res.status(500).json({ msg: 'Error al ejecutar el reporte', error: error.message });
  }
};

// Eliminar un reporte
export const deleteReport = async (req, res) => {
  try {
    const report = await Report.findById(req.params.id);
    if (!report) {
      return res.status(404).send({ msg: 'No existe el reporte' });
    }
    await Report.findByIdAndDelete(req.params.id);
    res.json({ msg: 'Reporte eliminado' });
  } catch (error) {
    console.error(error);
    res.status(500).send('Hubo un error');
  }
};

// Función para escapar valores SQL y prevenir SQL injection
const escapeSqlValue = (value) => {
  if (value === null || value === undefined) return 'NULL';
  
  // Convertir a string
  let strValue = String(value).trim();
  
  // Si el usuario ya puso comillas, quitarlas
  if (strValue.startsWith("'") && strValue.endsWith("'")) {
    strValue = strValue.slice(1, -1);
  }
  
  // Escapar comillas simples internas
  return strValue.replace(/'/g, "''");
};
// En controllers/reportController.js

const getReportByName = async (req, res) => {
    try {
        const { reportName } = req.params;
        
        // Buscar el reporte por nombre
        const report = await Report.findOne({ name: reportName });
        
        if (!report) {
            return res.status(404).json({ msg: 'Reporte no encontrado' });
        }
        
        res.json({ report });
    } catch (error) {
        console.log('Error en getReportByName:', error);
        res.status(500).json({ msg: 'Error del servidor' });
    }
};



// Función para construir query con parámetros
const buildQueryWithParameters = (baseQuery, userParameters, reportParameters) => {
  if (!userParameters || Object.keys(userParameters).length === 0) {
    return baseQuery;
  }

  const whereClauses = [];

  reportParameters.forEach(param => {
    const value = userParameters[param.name];
    
    // Saltar si el valor está vacío
    if (value === undefined || value === null || value === '') {
      return;
    }

    let clause = '';

    switch (param.operator) {
      case 'BETWEEN':
        if (Array.isArray(value) && value.length === 2) {
          const val1 = escapeSqlValue(value[0]);
          const val2 = escapeSqlValue(value[1]);
          clause = `${param.sqlField} BETWEEN '${val1}' AND '${val2}'`;
        }
        break;
        
      case 'IN':
        if (Array.isArray(value) && value.length > 0) {
          const values = value.map(v => `'${escapeSqlValue(v)}'`).join(',');
          clause = `${param.sqlField} IN (${values})`;
        } else if (!Array.isArray(value)) {
          // Si no es array pero debería serlo, convertirlo
          clause = `${param.sqlField} IN ('${escapeSqlValue(value)}')`;
        }
        break;
        
      case 'LIKE':
        const likeValue = escapeSqlValue(value);
        clause = `${param.sqlField} LIKE '%${likeValue}%'`;
        break;
        
      default:
        // Para operadores normales (=, !=, >, <, >=, <=)
        const escapedValue = escapeSqlValue(value);
        clause = `${param.sqlField} ${param.operator} '${escapedValue}'`;
    }

    if (clause && clause.trim() !== '') {
      whereClauses.push(clause);
    }
  });

  if (whereClauses.length === 0) {
    return baseQuery;
  }

  // Agregar WHERE o AND según la query existente
  const hasWhere = /\bwhere\b/i.test(baseQuery);
  const connector = hasWhere ? ' AND ' : ' WHERE ';
  
  return baseQuery + connector + whereClauses.join(' AND ');
};

// Función auxiliar para ejecutar query en SQL Server
const runReportQuery = async (report, customQuery = null) => {
  const passwordDecrypted = decrypt({ iv: report.iv, content: report.password });

  const database = report.datasource.split(',')[0].split('=')[1];
  const domain = report.datasource.split(',')[1].split('=')[1];
  const server = report.datasource.split(',')[2].split('=')[1];

  const config = {
    server: server + '\\SQLEXPRESS',
    database: database,
    user: report.user,
    password: passwordDecrypted,
    options: { 
      enableArithAbort: true,
      encrypt: true,                    
      trustServerCertificate: true      
    },
    connectionTimeout: 15000,
    requestTimeout: 15000
  };

  const pool = await sql.connect(config);
  const queryToExecute = customQuery || report.query;
  const result = await pool.request().query(queryToExecute);
  pool.close();
  return result.recordset;
};

export default {
  addReport,
  updateReport,
  getReport,
  getReports,
  executeReport,
  getReportByName,
  executeReportWithParams,
  deleteReport
};