//servidor20251007/controllers/commController.js
import { NodeSSH } from 'node-ssh';
import { promises as fs } from 'fs';
import path from 'path';
import snmp from 'net-snmp';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

// Para usar __dirname en ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const defaultSSHConfig = {
  port: 22,
  readyTimeout: 30000,
  keepaliveInterval: 30000,
  keepaliveCountMax: 3,
  algorithms: {
    kex: [
      'diffie-hellman-group-exchange-sha256',
      'diffie-hellman-group14-sha1',
      'diffie-hellman-group-exchange-sha1',
      'diffie-hellman-group1-sha1',
    ],
    cipher: [
      'aes128-ctr',
      'aes128-cbc',
      'aes192-cbc',
      'aes256-cbc',
      '3des-cbc',
    ],
    hmac: ['hmac-sha2-256', 'hmac-sha1', 'hmac-sha1-96'],
    serverHostKey: ['ssh-rsa', 'ssh-dss'],
  },
  tryKeyboard: true,
};

const getSSHCredentials = (ip = null) => {
  return {
    username: 'admin',
    password: 'admin123',
  };
};

const connectSSHShow = async (hostname, ip, tipo = 'running-config') => {
  const ssh = new NodeSSH();
  let command;

  switch (tipo.toLowerCase()) {
    case 'run':
    case 'running-config':
      command = 'show running-config';
      break;
    case 'startup':
    case 'startup-config':
      command = 'show startup-config';
      break;
    case 'version':
      command = 'show version';
      break;
    case 'interfaces':
      command = 'show interfaces';
      break;
    case 'ip':
      command = 'show ip interface brief';
      break;
    case 'vlan':
      command = 'show vlan';
      break;
    case 'mac':
      command = 'show mac address-table';
      break;
    default:
      command = `show ${tipo}`;
  }

  try {
    console.log(`SSH: Conectando a ${hostname} (${ip}) para comando: ${command}`);

    const credentials = getSSHCredentials(ip);
    const sshConfig = {
      host: ip,
      ...credentials,
      ...defaultSSHConfig
    };

    await ssh.connect(sshConfig);

    if (ssh.connection) {
      ssh.connection.on('error', (err) => {
        console.error(`SSH: Error detectado en ${hostname}:`, err.message);
      });
    }
    
    console.log(`SSH: Conectado a ${hostname}`);

    const result = await ssh.execCommand(command, {
      options: {
        pty: true,
        execTimeout: 60000,
      }
    });

    console.log(`SSH: Comando ejecutado con código: ${result.code}`);

    if (result.code !== 0) {
      throw new Error(`Comando SSH falló con código ${result.code}: ${result.stderr}`);
    }

    const timenow = new Date();
    const filename_now = `${hostname}-show_${tipo}_${Date.now()}.txt`;
    
    const publicDir = path.join(__dirname, '..', '..', 'tagdescriptions', 'public', 'files');
    await fs.mkdir(publicDir, { recursive: true });

    const filePath = path.join(publicDir, filename_now);
    
    const fileContent = `# Cisco Switch Configuration via SSH
# Hostname: ${hostname}
# IP Address: ${ip}
# Command: ${command}
# Generated: ${new Date().toISOString()}
# Connection: SSH
# ================================================

${result.stdout}

# ================================================
# End of configuration
`;

    await fs.writeFile(filePath, fileContent, 'utf8');
    
    console.log(`SSH: Archivo guardado: ${publicDir}/${filename_now} a la hora ${timenow}`);

    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      if (ssh.connection) {
        ssh.connection.removeAllListeners('error');
        ssh.connection.on('error', (err) => {
          console.warn(`SSH: Error durante cierre (ignorado): ${err.message}`);
        });
      }
      ssh.dispose();
      console.log(`SSH: Conexión cerrada a ${hostname}`);
    } catch (closeError) {
      console.warn(`SSH: Error cerrando conexión (no crítico): ${closeError.message}`);
    }

    return filename_now;

  } catch (error) {
    console.error(`SSH Error en ${hostname} (${ip}):`, error.message);

    try {
      if (ssh.connection) {
        ssh.connection.removeAllListeners('error');
        ssh.connection.on('error', () => { });
      }
      ssh.dispose();
    } catch (disposeError) {
      console.warn('Error cerrando conexión SSH tras fallo (ignorado):', disposeError.message);
    }

    throw error;
  }
};

const connectSSHShowTech = async (hostname, ip, tipo = 'tech') => {
  const ssh = new NodeSSH();

  const techCommands = [
    'show version',
    'show running-config',
    'show interfaces',
    'show ip interface brief',
    'show vlan',
    'show spanning-tree',
    'show mac address-table',
    'show arp',
    'show cdp neighbors detail',
    'show inventory',
    'show environment',
    'show processes cpu',
    'show memory',
    'show logging',
  ];

  try {
    console.log(`SSH Tech: Conectando a ${hostname} (${ip}) para show tech-support`);

    const credentials = getSSHCredentials(ip);
    const sshConfig = {
      host: ip,
      ...credentials,
      ...defaultSSHConfig
    };

    await ssh.connect(sshConfig);
    console.log(`SSH Tech: Conectado a ${hostname}`);

    let allOutput = '';
    let executedCommands = 0;

    console.log('SSH Tech: Ejecutando comandos individuales para consistencia...');
    
    for (const command of techCommands) {
      try {
        console.log(`SSH Tech: Ejecutando ${command}...`);
        const result = await ssh.execCommand(command, {
          options: {
            pty: true,
            execTimeout: 30000,
          }
        });

        if (result.code === 0) {
          allOutput += `\n\n# ================================================\n`;
          allOutput += `# Command: ${command}\n`;
          allOutput += `# ================================================\n\n`;
          allOutput += result.stdout;
          executedCommands++;
        } else {
          console.warn(`SSH Tech: Comando falló: ${command} (código: ${result.code})`);
        }
      } catch (cmdError) {
        console.warn(`SSH Tech: Error ejecutando ${command}:`, cmdError.message);
      }
    }

    if (executedCommands === 0) {
      throw new Error('No se pudo ejecutar ningún comando tech');
    }

    const timenow = new Date();
    const filename_now = `${hostname}-show_${tipo}_${Date.now()}.txt`;
    
    const publicDir = path.join(__dirname, '..', '..', 'tagdescriptions', 'public', 'files');
    await fs.mkdir(publicDir, { recursive: true });

    const filePath = path.join(publicDir, filename_now);
    
    const fileContent = `# Cisco Switch Tech Support via SSH
# Hostname: ${hostname}
# IP Address: ${ip}
# Generated: ${new Date().toISOString()}
# Connection: SSH
# Commands executed: ${executedCommands}
# ================================================

${allOutput}

# ================================================
# End of tech support
`;

    await fs.writeFile(filePath, fileContent, 'utf8');
    
    console.log(`SSH Tech: Archivo guardado: ${publicDir}/${filename_now} a la hora ${timenow}`);

    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      if (ssh.connection) {
        ssh.connection.removeAllListeners('error');
        ssh.connection.on('error', (err) => {
          console.warn(`SSH Tech: Error durante cierre (ignorado): ${err.message}`);
        });
      }
      ssh.dispose();
      console.log(`SSH Tech: Conexión cerrada a ${hostname}`);
    } catch (closeError) {
      console.warn(`SSH Tech: Error cerrando conexión (no crítico): ${closeError.message}`);
    }

    return filename_now;

  } catch (error) {
    console.error(`SSH Tech Error en ${hostname} (${ip}):`, error.message);

    try {
      if (ssh.connection) {
        ssh.connection.removeAllListeners('error');
        ssh.connection.on('error', () => { });
      }
      ssh.dispose();
    } catch (disposeError) {
      console.warn('Error cerrando conexión SSH Tech tras fallo (ignorado):', disposeError.message);
    }

    throw error;
  }
};

const getSNMP = (host, community, oids) => {
  return new Promise((resolve, reject) => {
    const trySession = (version) => {
      const options = { version, timeout: 5000, retries: 1 };
      const session = snmp.createSession(host, community, options);

      session.get(oids, (error, varbinds) => {
        if (error) {
          session.close();
          if (version === snmp.Version2c) {
            console.warn(`SNMP v2c falló en ${host}, probando v1...`);
            trySession(snmp.Version1);
          } else {
            reject(error);
          }
        } else {
          let results = [];
          for (let i = 0; i < varbinds.length; i++) {
            if (snmp.isVarbindError(varbinds[i])) {
              console.warn(`SNMP: OID ${oids[i]} no disponible en ${host}`);
              results.push(null);
            } else {
              results.push(varbinds[i].value.toString());
            }
          }
          session.close();
          resolve(results);
        }
      });
    };

    trySession(snmp.Version2c);
  });
};

const getSNMP_Sync = async (host, community, oids) => {
  try {
    const results = await getSNMP(host, community, oids);
    return results[0] || '';
  } catch (error) {
    console.error(`SNMP Error for ${host} (OID: ${oids.join(', ')}):`, error.message);
    return '';
  }
};

const testSSHConnection = async (ip, credentials = null) => {
  const ssh = new NodeSSH();

  try {
    console.log(`Test SSH: Conectando a ${ip}...`);
    const creds = credentials || getSSHCredentials(ip);
    const sshConfig = {
      host: ip,
      ...creds,
      ...defaultSSHConfig
    };

    await ssh.connect(sshConfig);

    const result = await ssh.execCommand('show clock', {
      options: {
        pty: true,
        execTimeout: 10000,
      }
    });

    ssh.dispose();

    return {
      success: result.code === 0,
      output: result.stdout,
      error: result.stderr,
      ip: ip
    };

  } catch (error) {
    try {
      ssh.dispose();
    } catch (disposeError) { }
    return {
      success: false,
      error: error.message,
      ip: ip
    };
  }
};

// Aliases para Telnet 
const connectTelnetShow = connectSSHShow;
const connectTelnetShowTech = connectSSHShowTech;

// Exportación ES6
export {
  connectSSHShow,
  connectSSHShowTech,
  testSSHConnection,
  getSNMP,
  getSNMP_Sync,
  getSSHCredentials,
  defaultSSHConfig,
  connectTelnetShow,
  connectTelnetShowTech
};