//servidor20251007/controllers/assistantController.js
import { GoogleGenerativeAI } from '@google/generative-ai';
import appContext from '../config/appContext.js';
import { databaseFunctions, ejecutarFuncion } from '../functions/databaseFunctions.js';
import { navigationFunctions, ejecutarNavegacion } from '../functions/navigationFunctions.js';
import { pdfFunctions, ejecutarFuncionPDF } from '../functions/pdfFunctions.js';
import { getUnauthenticatedInstructions, getAuthenticatedInstructions } from '../config/assistantInstructions.js';

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

const MODELS_TO_TRY = [
  'gemini-2.5-flash-preview-09-2025', 
  'gemini-2.5-flash',
];

let workingModel = null;

const LOG_CONFIG = {
  showModelSelection: false,
  showFunctionCalls: false,     
  showFunctionResults: false,   
  showErrors: true              
};

export const chat = async (req, res) => {
  const { message, conversationHistory = [] } = req.body;
  
  const isAuthenticated = req.user ? true : false;
  const userInfo = req.user || null;

  if (!message) {
    return res.status(400).json({ 
      success: false, 
      message: 'El mensaje es requerido' 
    });
  }

  for (const modelName of MODELS_TO_TRY) {
    if (workingModel && modelName !== workingModel) {
      continue;
    }
    
    try {
      if (!workingModel && LOG_CONFIG.showModelSelection) {
        console.log(`[ASSISTANT] Intentando con modelo: ${modelName}`);
      }
      
      const systemInstruction = isAuthenticated 
        ? getAuthenticatedInstructions(userInfo)
        : getUnauthenticatedInstructions();

      const generationConfig = {
        temperature: 0.1,
        topP: 0.8,
        topK: 40,
        maxOutputTokens: 4096,
      };
      
      const model = genAI.getGenerativeModel({ 
        model: modelName,
        generationConfig,
        systemInstruction,
      });

      const cleanedHistory = conversationHistory.filter(msg => 
        msg && msg.content && String(msg.content).trim().length > 0
      );

      let chatHistory = cleanedHistory.map(msg => ({
        role: msg.role === 'user' ? 'user' : 'model',
        parts: [{ text: String(msg.content) }]
      }));
      
      while (chatHistory.length > 0 && chatHistory[0].role !== 'user') {
        chatHistory.shift();
      }

      for (let i = 1; i < chatHistory.length; i++) {
        const expectedRole = (i % 2 === 1) ? 'model' : 'user';
        if (chatHistory[i].role !== expectedRole) {
          chatHistory = chatHistory.slice(0, i);
          break;
        }
      }

      const chatConfig = {
        history: chatHistory
      };
      
      if (isAuthenticated) {
        chatConfig.tools = [{ 
          functionDeclarations: [
            ...databaseFunctions,
            ...navigationFunctions,
            ...pdfFunctions
          ]
        }];
      }

      const chat = model.startChat(chatConfig);

      let result = await chat.sendMessage(message);
      let response = result.response;
      
      let navigationData = null;

      if (isAuthenticated && response.candidates[0]?.content?.parts) {
        while (response.candidates[0].content.parts.some(part => part.functionCall)) {
          const functionCall = response.candidates[0].content.parts.find(part => part.functionCall).functionCall;
          
          if (LOG_CONFIG.showFunctionCalls) {
            console.log(`[ASSISTANT] Función llamada: ${functionCall.name}`, functionCall.args);
          }
          
          let functionResult;
          
          if (functionCall.name === 'navegarSeccion') {
            functionResult = await ejecutarNavegacion(functionCall.name, functionCall.args, isAuthenticated);
            
            if (functionResult.shouldNavigate) {
              navigationData = {
                path: functionResult.navigateTo,
                sectionName: functionResult.sectionName
              };
            }
          } else if (['listarPDFs', 'leerPDF', 'buscarEnPDFs'].includes(functionCall.name)) {
              functionResult = await ejecutarFuncionPDF(functionCall.name, functionCall.args);
                } else {
                   functionResult = await ejecutarFuncion(functionCall.name, functionCall.args);
                }
          
          if (LOG_CONFIG.showFunctionResults) {
            console.log(`[ASSISTANT] Resultado:`, functionResult);
          }
          
          result = await chat.sendMessage([{
            functionResponse: {
              name: functionCall.name,
              response: functionResult
            }
          }]);
          
          response = result.response;
        }
      }

      let finalResponse = response.candidates?.[0]?.content?.parts?.[0]?.text || '';
      
      if (finalResponse.trim().length === 0) {
        if (response.promptFeedback?.blockReason) {
          throw new Error(`Contenido bloqueado. Reformula tu pregunta.`);
        }
        throw new Error('Respuesta vacía del modelo');
      }

      if (!workingModel) {
        workingModel = modelName;
        if (LOG_CONFIG.showModelSelection) {
          console.log(`[ASSISTANT] Modelo establecido: ${modelName}`);
        }
      }

      return res.json({
        success: true,
        response: finalResponse.trim(),
        navigation: navigationData,
        isAuthenticated: isAuthenticated,
        user: isAuthenticated ? {
          name: userInfo.name || userInfo.username,
          role: userInfo.role
        } : null,
        timestamp: new Date()
      });

    } catch (error) {
      if (LOG_CONFIG.showErrors) {
        console.error(`[ASSISTANT] Error con modelo ${modelName}:`, error.message);
      }
      
      if (error.message?.includes('API key')) {
        return res.status(401).json({
          success: false,
          message: 'Error de autenticación con Gemini API.'
        });
      }

      if (modelName === MODELS_TO_TRY[MODELS_TO_TRY.length - 1]) {
        return res.status(500).json({
          success: false,
          message: 'Error al procesar tu mensaje.'
        });
      }
      
      continue;
    }
  }
};

 const getContext = (req, res) =>{
  res.json({
    success: true,
    context: appContext,
    isAuthenticated: req.user ? true : false
  });
};

export default {
  chat,
  getContext
};