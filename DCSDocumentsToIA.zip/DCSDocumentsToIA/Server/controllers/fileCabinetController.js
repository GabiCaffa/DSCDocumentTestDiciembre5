//controllers/fileCabinetController.js
import multer from 'multer';
import { nanoid } from 'nanoid';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import Cabinet from '../models/Cabinet.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const multerConfiguration = {
    limits: { fileSize: 20 * 1024 * 1024 },
    storage: multer.diskStorage({
        destination: (req, file, cb) => {
            cb(null, './cabinetsFiles')
        }, 
        filename: (req, file, cb) => {
            const extension = file.mimetype.split('/')[1];
            cb(null, `${nanoid(10)}.${extension}`);
        }
    })
};

const upload = multer(multerConfiguration).single('cabinetsFiles');

export const uploadFile = async (req, res, next) => {
    try {
        const idCabinet = req.params.id;
        let cabinetDB = await Cabinet.findById(idCabinet);
        
        upload(req, res, async (error) => {
            if (!error) {
                console.log("No hay error");
                cabinetDB.files.push(req.file.filename);
                const cabinet = await Cabinet.findByIdAndUpdate({ _id: idCabinet }, { $set: cabinetDB }, { new: true });
                res.json({
                    ok: true,
                    message: 'Archivo subido correctamente',
                    file: req.file
                });
            } else {
                console.log(error.message);
                res.status(500).send({ msg: "Hubo un error al subir el archivo" });
                return next();
            }
        });
    } catch (error) {
        console.log(error);
        res.status(500).send({ msg: 'Hubo un error al subir el archivo' });
    }
};

export const deleteFile = async (req, res, next) => {
    try {
        const idCabinet = req.params.id;
        let cabinetDB = await Cabinet.findById(idCabinet);
        
        try {
            fs.unlinkSync(join(__dirname, '..', 'cabinetsFiles', req.query.fileNameDeleted));
        } catch (error) {
            console.log(error);
            res.status(500).send({ msg: 'Hubo un error al eliminar el archivo' });
        }

        cabinetDB.files.splice(cabinetDB.files.indexOf(req.query.fileNameDeleted), 1);
        const cabinet = await Cabinet.findByIdAndUpdate({ _id: idCabinet }, { $set: cabinetDB }, { new: true });
        res.send(cabinet);
    } catch (error) {
        console.log(error);
        res.status(500).send({ msg: "Hubo un error al eliminar el archivo" });
    }
};

export default {
  uploadFile,
  deleteFile
};