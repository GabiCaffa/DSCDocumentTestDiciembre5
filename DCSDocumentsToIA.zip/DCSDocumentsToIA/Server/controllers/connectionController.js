//controllers/connectionController.js
import { validationResult } from 'express-validator';
import bcryptjs from 'bcryptjs';
import jwt from 'jsonwebtoken';
import Connection from '../models/Connection.js';

const createConnection = async (req, res) => {
    //valido errores
    const errors = validationResult(req);
    
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    const { source, target } = req.body;
    
    try {
        let connection = await Connection.findOne(
            {
                $and: [
                    { source: source },
                    { target: target },
                ]
            }
        );
        if (connection !== null) {
            console.log("error");
            return res.status(500).send("La conexion ya existe");
        }
        connection = new Connection(req.body);
        await connection.save();
        res.json({ connection });

    } catch (error) {
        console.log(error);
        res.status(400).send("Hubo un error en la creación de la conexión");
    }
};

const getConnections = async (req, res) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    try {
        const connections = await Connection.find().sort({ createddate: 1 });
        
        res.json({ connections });

    } catch ({ error }) {
        console.log(error);
        res.status(500).send({ msg: "No se pudo obtener las conexiones" });
    }
};

const deleteConnection = async (req, res) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }

    try {
        const connection_deleted =  await Connection.findById(req.params.id);

        if (!connection_deleted) {
            return res.status(404).send({ msg: "No existe la conexión" });
        }
        await Connection.findByIdAndDelete(connection_deleted._id);
        res.json({ msg: "Conexión eliminada" });
    } catch ({ error }) {
        console.log(error);
        res.status(500).send({ msg: "No se pudo eliminar la conexión, contacte a un administrador" });
    }
};

export default {
    createConnection,
    getConnections,
    deleteConnection
};