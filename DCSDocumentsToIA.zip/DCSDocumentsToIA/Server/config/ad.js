import ActiveDirectory from 'activedirectory';
import 'dotenv/config';

const config = {
  url: process.env.AD_URL || 'ldap://192.168.1.10',
  baseDN: process.env.AD_BASE_DN || 'dc=PRD,dc=local',
  username: process.env.AD_USERNAME || 'gabicaffa@PRD.local',
  password: process.env.AD_PASSWORD || 'Gabi2004'
};

const ad = new ActiveDirectory(config);

export default ad;
