// config/appContext.js
const appContext = {
  appName: "EstructuraMdP - Sistema DCS de Gestión de Activos y Red",
  
  sections: {
    // ==================== AUTENTICACIÓN ====================
    auth: {
      name: "Autenticación",
      description: "Inicio de sesión y registro de usuarios",
      path: "/login",
      actions: [
        {
          action: "iniciar_sesion",
          description: "Iniciar sesión en el sistema",
          steps: "En la pantalla 'Iniciar Sesión', ingresa tu Email y Password, luego haz click en el botón 'Iniciar Sesión'."
        },
        {
          action: "obtener_cuenta",
          description: "Registrarse como nuevo usuario",
          steps: "En la pantalla de login, haz click en '> Obtener cuenta'. Completa el formulario con tu Nombre, Email, Permisos (rol) y Dominio. Si seleccionas el dominio PRD (usuario de Active Directory/Windows), no necesitas ingresar contraseña ya que se autenticará contra el domain controller. Si seleccionas LOCAL, deberás ingresar y confirmar una contraseña. Finalmente, haz click en 'Registrar cuenta'."
        },
        {
          action: "volver_login",
          description: "Volver a la pantalla de login desde registro",
          steps: "En la pantalla de registro, haz click en 'Volver a Login'."
        }
      ]
    },

    // ==================== MENÚ PRINCIPAL ====================
    menu: {
      name: "Menú Principal",
      description: "Pantalla principal con acceso a todas las secciones del sistema",
      path: "/menu",
      actions: [
        {
          action: "acceder_menu",
          description: "Ver el menú principal después de iniciar sesión",
          steps: "Después de iniciar sesión correctamente, serás redirigido automáticamente al menú principal donde verás todas las secciones disponibles organizadas en tarjetas."
        },
        {
          action: "usar_busqueda_avanzada",
          description: "Usar la búsqueda avanzada del sistema",
          steps: "En la barra superior derecha del menú, haz click en 'Búsqueda Avanzada'."
        },
        {
          action: "cambiar_contrasena",
          description: "Cambiar tu contraseña",
          steps: "En la barra superior derecha, haz click en 'Cambiar contraseña' y completa el formulario con la nueva contraseña."
        },
        {
          action: "cerrar_sesion",
          description: "Salir del sistema",
          steps: "En la barra superior derecha, haz click en 'Cerrar Sesión'."
        }
      ],
      subsections: [
        "Estructura MdP",
        "Usuarios",
        "Descriptores DCS",
        "Network DCS",
        "Dispositivos DCS",
        "Conexiones",
        "Arquitectura Redes",
        "Gabinetes",
        "Tarjetas I/O",
        "Reportes"
      ]
    },

    // ==================== ESTRUCTURA MDP (ASSETS) ====================
    estructuraMdP: {
      name: "Estructura MdP",
      description: "Gestión de activos (assets) del sistema",
      path: "/assets",
      menuButton: "Estructura MdP",
      actions: [
        {
          action: "ver_assets",
          description: "Ver la lista de assets disponibles",
          steps: "Desde el menú principal, haz click en 'Estructura MdP'. En el panel izquierdo verás la lista de Assets disponibles (Aguas, HIPOCLORITO, RB, Secado, PB, FL, Networking, Devices, Cabinets, UPM)."
        },
        {
          action: "seleccionar_asset",
          description: "Seleccionar un asset específico",
          steps: "Ve a 'Estructura MdP' y en el panel izquierdo 'Assets', haz click en el nombre del asset que deseas ver (ej: Aguas, HIPOCLORITO, RB, etc.)."
        },
        {
          action: "crear_nuevo_asset",
          description: "Agregar un nuevo asset al sistema",
          steps: "Ve a 'Estructura MdP' y haz click en el botón 'Nuevo Asset' en el panel izquierdo. Ingresa el 'Nombre del asset' en el campo de texto y haz click en 'Agregar asset'."
        },
        {
          action: "agregar_sistema_asset",
          description: "Agregar un sistema a un asset existente",
          steps: "Ve a 'Estructura MdP' y selecciona un asset del panel izquierdo. En la zona central, ingresa el 'Nombre del sistema' en el campo de texto y haz click en 'Agregar sistema'."
        },
        {
          action: "ver_sistemas_asset",
          description: "Ver los sistemas asignados a un asset",
          steps: "Ve a 'Estructura MdP' y selecciona un asset del panel izquierdo. En la sección 'Sistemas asignados al asset' verás la lista de sistemas o el mensaje 'No hay sistemas asignados al asset'."
        },
        {
          action: "eliminar_asset",
          description: "Eliminar un asset del sistema",
          steps: "Ve a 'Estructura MdP' y selecciona el asset que deseas eliminar. Haz click en 'Eliminar Asset ×' y confirma la acción."
        }
      ]
    },

    // ==================== USUARIOS ====================
    usuarios: {
      name: "Usuarios",
      description: "Gestión de usuarios del sistema",
      path: "/users",
      menuButton: "Usuarios",
      actions: [
        {
          action: "ver_lista_usuarios",
          description: "Ver todos los usuarios registrados",
          steps: "Desde el menú principal, haz click en 'Usuarios'. Verás la 'Lista de usuarios' con columnas que muestran el nombre de usuario, email, rol (ENGINEER/SYSADMIN), dominio (PRD/LOCAL), estado (Activo) y un botón para eliminar."
        },
        {
          action: "identificar_roles",
          description: "Entender los roles de usuario disponibles",
          steps: "Los roles disponibles son: ENGINEER (usuario con permisos de ingeniería) y SYSADMIN (administrador del sistema con permisos completos)."
        },
        {
          action: "identificar_dominios",
          description: "Entender los dominios de usuario",
          steps: "Los dominios disponibles son: PRD (Producción, usuarios autenticados por Active Directory/Windows Domain Controller) y LOCAL (entorno local de desarrollo o pruebas, con autenticación propia del sistema)."
        },
        {
          action: "eliminar_usuario",
          description: "Eliminar un usuario del sistema",
          steps: "Ve a 'Usuarios', busca el usuario que deseas eliminar en la lista, haz click en el botón 'Eliminar' de ese usuario y confirma la acción."
        }
      ]
    },

    // ==================== DESCRIPTORES DCS ====================
    descriptoresDCS: {
      name: "Descriptores DCS",
      description: "Gestión de tag descriptors del sistema de control",
      path: "/tagsdescriptors",
      menuButton: "Descriptores DCS",
      actions: [
        {
          action: "buscar_tag_descriptor",
          description: "Buscar un tag descriptor específico",
          steps: "Ve a 'Descriptores DCS' y en el campo 'buscar tag descriptor' de la parte superior, escribe el nombre del tag. Los resultados se filtrarán automáticamente."
        },
        {
          action: "crear_nuevo_tag",
          description: "Crear un nuevo tag descriptor",
          steps: "Ve a 'Descriptores DCS' y haz click en el botón 'Nuevo tag descriptor'. El sistema creará un nuevo tag."
        },
        {
          action: "generar_documento",
          description: "Generar documento de tags",
          steps: "Ve a 'Descriptores DCS' y haz click en el botón 'Generar documento'. El sistema generará un documento con los tags del sistema seleccionado."
        },
        {
          action: "ver_tags_por_asset",
          description: "Ver tags descriptors filtrados por asset",
          steps: "Ve a 'Descriptores DCS'. En el panel izquierdo 'Assets', selecciona el asset deseado (ej: Aguas, HIPOCLORITO). Si el asset tiene subsistemas (ej: Presurizacion, Dosificacion), haz click en el '+' para expandir y selecciona el subsistema específico. Verás 'Tags descriptors del sistema: [Nombre]' con la lista correspondiente."
        },
        {
          action: "ver_alarmas_tag",
          description: "Ver alarmas asociadas a un tag",
          steps: "Ve a 'Descriptores DCS', navega hasta el tag deseado en la lista y haz click en el botón 'Alarmas' del tag."
        },
        {
          action: "editar_tag",
          description: "Editar un tag descriptor existente",
          steps: "Ve a 'Descriptores DCS', localiza el tag en la lista, haz click en el botón 'Editar', modifica los campos necesarios y guarda los cambios."
        },
        {
          action: "eliminar_tag",
          description: "Eliminar un tag descriptor",
          steps: "Ve a 'Descriptores DCS', encuentra el tag en la lista, haz click en 'Eliminar' y confirma la eliminación."
        }
      ]
    },

    // ==================== NETWORK DCS ====================
    networkDCS: {
      name: "Network DCS",
      description: "Gestión de nodos de red del sistema de control",
      path: "/network",
      menuButton: "Network DCS",
      actions: [
        {
          action: "ver_nodos_red",
          description: "Ver los nodos de red por asset",
          steps: "Ve a 'Network DCS'. En el panel izquierdo 'Assets', selecciona el asset deseado. Verás 'Nodos de red para el asset: [Nombre]' con la lista de nodos o el mensaje 'No hay nodos de red asociados el asset seleccionado'."
        },
        {
          action: "crear_nuevo_nodo",
          description: "Agregar un nuevo nodo de red",
          steps: "Ve a 'Network DCS' y haz click en el botón 'Nuevo Nodo' en la parte superior. Se abrirá un formulario para configurar el nodo. Completa la información requerida y guarda el nodo."
        },
        {
          action: "navegar_assets_network",
          description: "Navegar entre diferentes assets en Network",
          steps: "Ve a 'Network DCS' y usa el panel izquierdo 'Assets' para seleccionar entre: Aguas, HIPOCLORITO, RB, Secado, PB, FL, Networking, Devices, Cabinets, UPM."
        }
      ]
    },

    // ==================== DISPOSITIVOS DCS ====================
    dispositivosDCS: {
      name: "Dispositivos DCS",
      description: "Gestión de dispositivos del sistema de control",
      path: "/devices",
      menuButton: "Dispositivos DCS",
      actions: [
        {
          action: "buscar_dispositivo",
          description: "Buscar un dispositivo específico",
          steps: "Ve a 'Dispositivos DCS' y en el campo 'buscar device' de la parte superior, escribe el nombre o código del dispositivo. Los resultados se filtrarán automáticamente."
        },
        {
          action: "crear_nuevo_dispositivo",
          description: "Agregar un nuevo dispositivo",
          steps: "Ve a 'Dispositivos DCS', haz click en el botón 'Nuevo Dispositivo', completa el formulario con la información del dispositivo y guarda."
        },
        {
          action: "ver_dispositivos_por_asset",
          description: "Ver dispositivos filtrados por asset",
          steps: "Ve a 'Dispositivos DCS'. En el panel izquierdo 'Assets', selecciona el asset (ej: Secado). Verás 'Dispositivos para el asset: [Nombre]' con la lista o mensaje 'No hay nodos de red asociados el asset seleccionado'."
        }
      ]
    },

    // ==================== CONEXIONES ====================
    conexiones: {
      name: "Conexiones",
      description: "Gestión de conexiones entre dispositivos del sistema",
      path: "/connections",
      menuButton: "Conexiones",
      actions: [
        {
          action: "ver_conexiones",
          description: "Ver lista de conexiones existentes",
          steps: "Ve a 'Conexiones' desde el menú principal. Verás la lista de conexiones con columnas: Origen, Destino y botón Eliminar."
        },
        {
          action: "crear_conexion",
          description: "Crear una nueva conexión entre dispositivos",
          steps: "Ve a 'Conexiones'. En los campos superiores: 'Seleccione un origen', 'Seleccione un destino', 'Description', 'Seleccione un tipo', completa todos los campos requeridos y haz click en 'Crear conexión'."
        },
        {
          action: "buscar_conexion",
          description: "Buscar conexiones existentes",
          steps: "Ve a 'Conexiones' y en el campo 'Buscar conexiones' escribe el término de búsqueda. La lista se filtrará automáticamente."
        },
        {
          action: "eliminar_conexion",
          description: "Eliminar una conexión existente",
          steps: "Ve a 'Conexiones', localiza la conexión en la lista, haz click en el botón 'Eliminar' y confirma la acción."
        }
      ]
    },

    // ==================== ARQUITECTURA REDES ====================
    arquitecturaRedes: {
      name: "Arquitectura Redes",
      description: "Visualización de la arquitectura de red del sistema",
      path: "/architecture",
      menuButton: "Arquitectura Redes",
      actions: [
        {
          action: "ver_diagrama_red",
          description: "Ver el diagrama de arquitectura de red",
          steps: "Ve a 'Arquitectura Redes' desde el menú principal. Verás un diagrama visual con todos los switches y dispositivos de red del sistema. Cada dispositivo muestra su nombre (ej: PMSWSE221A, PMSWSY001A) y botones 'Connections' y 'Status'."
        },
        {
          action: "ver_conexiones_dispositivo",
          description: "Ver conexiones de un dispositivo específico en el diagrama",
          steps: "Ve a 'Arquitectura Redes', localiza el dispositivo en el diagrama y haz click en el botón 'Connections' del dispositivo."
        },
        {
          action: "ver_status_dispositivo",
          description: "Ver el estado de un dispositivo en el diagrama",
          steps: "Ve a 'Arquitectura Redes', localiza el dispositivo en el diagrama y haz click en el botón 'Status' del dispositivo."
        },
        {
          action: "navegar_diagrama",
          description: "Navegar y hacer zoom en el diagrama de red",
          steps: "Ve a 'Arquitectura Redes'. Usa los controles '+' y '-' en la esquina inferior izquierda para hacer zoom. Usa el ícono de pantalla completa para expandir la vista. Puedes arrastrar el diagrama para moverte por él."
        }
      ]
    },

    // ==================== GABINETES ====================
    gabinetes: {
      name: "Gabinetes",
      description: "Gestión de gabinetes físicos del sistema",
      path: "/cabinets",
      menuButton: "Gabinetes",
      actions: [
        {
          action: "ver_gabinetes",
          description: "Ver lista de gabinetes por asset",
          steps: "Ve a 'Gabinetes' desde el menú principal. En el panel izquierdo 'Assets', selecciona el asset deseado (ej: RB). Verás 'Lista de Gabinetes para el Asset: [Nombre]' o el mensaje 'No hay gabinetes asociados el asset seleccionado'."
        },
        {
          action: "crear_nuevo_gabinete",
          description: "Agregar un nuevo gabinete",
          steps: "Ve a 'Gabinetes', haz click en el botón 'Nuevo Gabinete' en la parte superior, completa la información del gabinete y guarda."
        },
        {
          action: "navegar_assets_gabinetes",
          description: "Cambiar entre assets para ver sus gabinetes",
          steps: "Ve a 'Gabinetes' y en el panel izquierdo, selecciona el asset: Aguas, HIPOCLORITO, RB, Secado, PB, FL, Networking, Devices, Cabinets, UPM."
        }
      ]
    },

    // ==================== TARJETAS I/O ====================
    tarjetasIO: {
      name: "Tarjetas I/O",
      description: "Gestión de tarjetas de entrada/salida (I/O Cards)",
      path: "/iocards",
      menuButton: "Tarjetas I/O",
      actions: [
        {
          action: "ver_tarjetas_io",
          description: "Ver tarjetas I/O por asset",
          steps: "Ve a 'Tarjetas I/O' desde el menú principal. En el panel izquierdo 'Assets', selecciona el asset (ej: RB). Verás 'IOCard en el asset: [Nombre]'."
        },
        {
          action: "crear_nueva_tarjeta",
          description: "Agregar una nueva tarjeta I/O",
          steps: "Ve a 'Tarjetas I/O' y haz click en 'Nueva Tarjeta' en la parte superior. Completa el formulario con: IO tagname, Seleccione el Controlador asociado, Seleccione el tipo de tarjeta IO, Seleccione el IO Link, Device Index, Seleccione el Gabinete, Location. Finalmente, haz click en 'Agregar IO'."
        },
        {
          action: "configurar_tarjeta_io",
          description: "Entender los campos de configuración de una tarjeta I/O",
          steps: "Al crear una tarjeta I/O necesitas: IO tagname (identificador único), Controlador asociado (dispositivo que controla la tarjeta), Tipo de tarjeta IO (modelo/tipo), IO Link (enlace de comunicación), Device Index (índice del dispositivo), Gabinete (ubicación física), Location (posición exacta)."
        }
      ]
    },

    // ==================== REPORTES ====================
    reportes: {
      name: "Reportes DCS",
      description: "Gestión y ejecución de reportes del sistema",
      path: "/reports",
      menuButton: "Reportes",
      actions: [
        {
          action: "buscar_reporte",
          description: "Buscar un reporte específico",
          steps: "Ve a 'Reportes' desde el menú principal, luego elige el asset que desees y en el campo 'Buscar reporte' de la parte superior, escribe el nombre del reporte. Los resultados se filtrarán automáticamente."
        },
        {
          action: "crear_nuevo_reporte",
          description: "Crear un nuevo reporte",
          steps: "Ve a 'Reportes' desde el menú principal, luego elige el asset en el que desees crear un reporte y haz click en el botón 'Nuevo reporte' en la parte superior, completa el formulario con la configuración del reporte, que es un nombre que le quieras dar al reporte, el nombre de usuario de SQL server, la contraseña de SQL server del usuario, el datasource que es la conexion a una base de datos, la consulta SQL que quieras realizar y guarda."
        },
        {
          action: "ver_reportes_por_asset",
          description: "Ver reportes organizados por asset",
          steps: "Ve a 'Reportes'. En el panel izquierdo 'Assets', expande el asset deseado (ej: Aguas > HIPOCLORITO > Presurizacion, Dosificacion) y selecciona el subsistema específico. Verás 'Reportes del sistema: [Nombre]' con la lista de reportes disponibles."
        },
        {
          action: "ejecutar_reporte",
          description: "Ejecutar un reporte existente",
          steps: "Ve a 'Reportes', navega hasta el reporte deseado usando el árbol de Assets, localiza el reporte en la lista (ej: PRUEBA) y haz click en el botón 'Ejecutar Reporte'. El reporte se ejecutará y mostrará los resultados."
        },
        {
          action: "editar_reporte",
          description: "Modificar un reporte existente",
          steps: "Ve a 'Reportes', localiza el reporte en la lista, haz click en el botón 'Editar', modifica los campos necesarios y guarda los cambios."
        },
        {
          action: "eliminar_reporte",
          description: "Eliminar un reporte del sistema",
          steps: "Ve a 'Reportes', encuentra el reporte en la lista, haz click en el botón 'Eliminar' y confirma la eliminación."
        }
      ]
    }
  },

  // ==================== NAVEGACIÓN GENERAL ====================
  generalHelp: {
    navegacion: "El sistema usa un menú principal con tarjetas para acceder a cada sección. Usa el menú de navegación superior con tu nombre de usuario (ej: 'Hola gabi') donde encontrarás opciones de 'Búsqueda Avanzada', 'Cambiar contraseña' y 'Cerrar Sesión'.",
    
    panelIzquierdo: "La mayoría de secciones tienen un panel lateral izquierdo con la lista de Assets para filtrar información: Aguas, HIPOCLORITO, RB, Secado, PB, FL, Networking, Devices, Cabinets, UPM. Algunos assets tienen subsistemas que se expanden con el símbolo '+'.",
    
    busqueda: "Muchas secciones tienen un campo de búsqueda en la parte superior para filtrar resultados rápidamente.",
    
    paginacion: "Las listas largas tienen controles de paginación ('<' y '>') en la parte inferior para navegar entre páginas.",
    
    permisos: "El sistema tiene dos roles principales: ENGINEER (Ingeniería) y SYSADMIN (Administrador). Algunas funciones requieren permisos específicos.",
    
    dominios: "El sistema maneja dos dominios: PRD (Producción) y LOCAL (Desarrollo/Pruebas)."
  },

  // ==================== PREGUNTAS FRECUENTES ====================
  commonQuestions: [
    {
      question: "¿Cómo me registro en el sistema?",
      answer: "En la pantalla de login, haz click en '> Obtener cuenta' y completa el formulario de registro con tu nombre, email, rol y dominio."
    },
    {
      question: "¿Cómo veo los reportes?",
      answer: "Ve a la sección 'Reportes' desde el menú principal. Usa el panel izquierdo para navegar por Assets y subsistemas, luego podrás ver, crear y ejecutar reportes."
    },
    {
      question: "¿Cómo agrego un nodo de red?",
      answer: "Ve a 'Network DCS', haz click en 'Nuevo Nodo' y completa el formulario con la información del nodo."
    },
    {
      question: "¿Dónde veo la arquitectura de la red?",
      answer: "Ve a 'Arquitectura Redes' desde el menú principal. Verás un diagrama interactivo con todos los switches y dispositivos de red."
    },
    {
      question: "¿Cómo gestiono los tags descriptors?",
      answer: "Ve a 'Descriptores DCS', selecciona un asset y subsistema del panel izquierdo, y podrás crear, editar o eliminar tags."
    },
    {
      question: "¿Cómo creo un asset nuevo?",
      answer: "Ve a 'Estructura MdP', haz click en 'Nuevo Asset', ingresa el nombre y haz click en 'Agregar asset'."
    },
    {
      question: "¿Qué son las tarjetas I/O?",
      answer: "Las tarjetas I/O son tarjetas de entrada/salida que conectan los dispositivos físicos al sistema de control. Se gestionan en la sección 'Tarjetas I/O'."
    },
    {
      question: "¿Cómo creo una conexión entre dispositivos?",
      answer: "Ve a 'Conexiones', selecciona el origen y destino, completa la descripción y tipo, luego haz click en 'Crear conexión'."
    },
    {
      question: "¿Puedo cambiar mi contraseña?",
      answer: "Sí, en la barra superior derecha haz click en 'Cambiar contraseña' junto a tu nombre de usuario."
    },
    {
      question: "¿Dónde veo los usuarios del sistema?",
      answer: "Ve a 'Usuarios' desde el menú principal para ver la lista completa de usuarios con sus roles y dominios."
    }
  ]
};

export default appContext;