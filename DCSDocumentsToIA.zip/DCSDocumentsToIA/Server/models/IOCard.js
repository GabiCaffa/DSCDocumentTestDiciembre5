import mongoose from "mongoose";

const IOCardSchema = new mongoose.Schema({
  tagname: {
    type: String,
    required: true,
    trim: true
  },
  type: {
    // 1 = AI, 2 = AO, 3 = DI, 4 = DO
    type: mongoose.Schema.Types.ObjectId,
    required: true
  },
  controller: {
    type: String,
    required: true,
    trim: true
  },
  iolink: {
    type: Number, // iolink 1 o 2
    required: true
  },
  deviceIndex: {
    type: Number,
    required: true
  },
  cabinet: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Cabinet"
  },
  location: {
    type: String,
    required: true,
    trim: true
  },
  sideLocation: {
    type: String,
    required: true,
    trim: true
  },
  posLocation: {
    type: Number,
    required: true
  },
  asset: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Asset"
  },
  controllerA: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "ControllerA",
    required: true
  },
  controllerB: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "ControllerB",
    required: false
  }
});

export default mongoose.model("IOCard", IOCardSchema);
