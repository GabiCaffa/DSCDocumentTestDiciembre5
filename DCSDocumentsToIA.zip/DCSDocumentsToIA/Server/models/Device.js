import mongoose from "mongoose";

const DeviceSchema = new mongoose.Schema({
  deviceName: {
    type: String,
    required: true,
    trim: true
  },
  deviceDescription: {
    type: String,
    required: true,
    trim: true
  },
  deviceType: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "DeviceType"
  },
  deviceIP: {
    type: String,
    required: true,
    trim: true
  },
  deviceURLOPC: {
    type: String
  },
  createddate: {
    type: Date,
    default: Date.now
  },
  asset: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Asset"
  }
});

export default mongoose.model("Device", DeviceSchema);
