import mongoose from "mongoose";

const ConnectionSchema = new mongoose.Schema({
  source: {
    type: String,
    required: true,
    trim: true
  },
  source_port: {
    type: String,
    required: true
  },
  target: {
    type: String,
    required: true,
    trim: true
  },
  target_port: {
    type: String,
    required: true
  },
  description: {
    type: String,
    trim: true
  },
  type: {
    type: String,
    required: true,
    trim: true
  },
  createddate: {
    type: Date,
    default: Date.now
  }
});

export default mongoose.model("Connection", ConnectionSchema);
