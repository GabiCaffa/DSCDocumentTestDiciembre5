import mongoose from "mongoose";

const AreaSchema = new mongoose.Schema({
  area: {
    type: Number,
    required: true
  },
  description: {
    type: String,
    required: true,
    trim: true
  }
});

export default mongoose.model("Area", AreaSchema);
