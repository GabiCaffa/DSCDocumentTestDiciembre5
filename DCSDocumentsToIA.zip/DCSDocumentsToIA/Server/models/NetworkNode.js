// models/NetworkNode.js
import mongoose from "mongoose";
const NetworkNodeSchema = new mongoose.Schema({
    nodeName: {
        type: String,
        required: true,
        trim: true
    },
    nodeDescription: {
        type: String,
        required: true,
        trim: true
    },
    nodeModel: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'NetworkNodeModel',
        required: true
    },
    area: {
        type: Number,
        required: false
    },
    nodeIP: {
        type: String,
        required: true,
        trim: true
    },
    createddate: {
        type: Date,
        default: Date.now
    },
    asset: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Asset',
        required: false
    },
    deviceType: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'DeviceType',
        required: false
    }
}, {
    timestamps: false // o true si querés createdAt / updatedAt automáticos
});
export default mongoose.model("NetworkNode", NetworkNodeSchema);
