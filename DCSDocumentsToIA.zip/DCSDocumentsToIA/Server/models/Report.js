// ServidorActualizado/models/Report.js
import mongoose from 'mongoose';

// Esquema para los parámetros configurables
const ParameterSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  label: {
    type: String,
    required: true,
    trim: true
  },
  type: {
    type: String,
    enum: ['text', 'number', 'date', 'select', 'multiselect'],
    required: true
  },
  sqlField: {
    type: String,
    required: true,
    trim: true
  },
  operator: {
    type: String,
    enum: ['=', '!=', '>', '<', '>=', '<=', 'LIKE', 'IN', 'BETWEEN'],
    default: '='
  },
  required: {
    type: Boolean,
    default: false
  },
  options: [{
    label: String,
    value: String
  }],
  defaultValue: {
    type: mongoose.Schema.Types.Mixed
  }
}, { _id: false });

const ReportSchema = new mongoose.Schema({
  user: {
    type: String,
    required: [true, 'El nombre de usuario es obligatorio'],
    trim: true,
  },
  password: {
    type: String,
    required: [true, 'La contraseña es obligatoria'],
    trim: true
  },
  iv: {
    type: String,
    trim: true
  },
  name: {
    type: String,
    required: [true, 'El nombre del reporte es obligatorio'],
    trim: true,
    unique: true
  },
  datasource: {
    type: String,
    required: [true, 'El origen de datos es obligatorio'],
    trim: true
  },
  query: {
    type: String,
    required: [true, 'La consulta SQL es obligatoria']
  },
  parameters: [ParameterSchema],
  system: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'System'
  }
}, {
  timestamps: true
});

export default mongoose.model('Report', ReportSchema);