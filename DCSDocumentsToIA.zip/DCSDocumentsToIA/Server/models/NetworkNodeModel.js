// models/NetworkNodeModel.js
import mongoose from 'mongoose';
const NetworkNodeModelSchema = new mongoose.Schema({
    model: {
        type: String,
        required: true,
        trim: true
    },
    url: {
        type: String,
        required: true,
        trim: true
    },
    port_fast: {
        type: Number,
        required: true
    },
    port_giga: {
        type: Number,
        required: true
    }
});

export default mongoose.model('NetworkNodeModel', NetworkNodeModelSchema);