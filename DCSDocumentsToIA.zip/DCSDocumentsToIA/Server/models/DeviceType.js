import mongoose from "mongoose";

const DeviceTypeSchema = new mongoose.Schema({
  type: {
    type: String,
    required: true
  },
  url: {
    type: String,
    required: true,
    trim: true
  }
});

export default mongoose.model("DeviceType", DeviceTypeSchema);
