import mongoose from "mongoose";

const CabinetSchema = new mongoose.Schema({
  cabinetName: {
    type: String,
    required: true,
    unique: true,
    trim: true
  },
  cabinetDescription: {
    type: String,
    required: true,
    trim: true
  },
  cabinetLatitude: {
    type: String,
    required: true
  },
  cabinetLongitude: {
    type: String,
    required: true
  },
  cabinetSize: {
    type: Number,
    required: true
  },
  area: {
    type: Number
  },
  asset: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Asset"
  },
  files: {
    type: [String]
  },
  createddate: {
    type: Date,
    default: Date.now
  }
});

export default mongoose.model("Cabinet", CabinetSchema);
