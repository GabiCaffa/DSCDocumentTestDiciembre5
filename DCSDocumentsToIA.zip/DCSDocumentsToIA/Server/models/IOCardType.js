import mongoose from "mongoose";

const IOCardTypeSchema = new mongoose.Schema({
  type: {
    type: String,
    required: true,
    trim: true
  },
  size: {
    type: Number,
    required: true
  }
});

export default mongoose.model("IOCardType", IOCardTypeSchema);
