// ServidorActualizado/models/User.js
import mongoose from 'mongoose';
const UserSchema = new mongoose.Schema({
  name: {
    type: String, // nombre de usuario de Windows (ej: gabicaffa)
    required: true,
    trim: true,
    unique: true // No se permiten nombres duplicados
  },
  email: {
    type: String, // se usa para loguearse
    required: true,
    trim: true,
    unique: true
  },
  password: {
    type: String,
    required: function () {
      // Solo se requiere contraseña si NO es del dominio PRD
      return this.domain?.toUpperCase() !== 'PRD';
    },
    trim: true
  },
  rol: {
    type: String,
    required: true,
    trim: true
  },
  domain: {
    type: String,
    required: true,
    trim: true,
    uppercase: true 
  },
  state: {
    type: String,
    default: 'INACTIVE',
    enum: ['ACTIVE', 'INACTIVE']
  },
  createddate: {
    type: Date,
    default: Date.now
  }
});

export default mongoose.model('User', UserSchema);