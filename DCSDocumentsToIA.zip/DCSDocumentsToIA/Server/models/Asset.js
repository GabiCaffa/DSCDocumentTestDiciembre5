import mongoose from "mongoose";

const AssetSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  createddate: {
    type: Date,
    default: Date.now
  }
});

export default mongoose.model("Asset", AssetSchema);
