import mongoose from 'mongoose';
const SystemSchema = new mongoose.Schema({
    name:{
        type:String,
        require:true,
        trim:true
    },
    active:{
        type:Boolean,
        default:false
    },
    asset:{
        type:mongoose.Schema.Types.ObjectId,
        ref: 'Asset'
    }
})

export default mongoose.model('System', SystemSchema);