// config/databaseFunctions.js
import mongoose from 'mongoose';

// Mapeo de campos comunes con sus posibles variantes
const CAMPO_VARIANTES = {
  nombre: ['nombre', 'name', 'username', 'userName', 'user_name', 'nombreUsuario', 'nodeName', 'tagname', 'tagName', 'reportName'],
  descripcion: ['descripcion', 'description', 'desc', 'detalle', 'details', 'nodeDescription'],
  email: ['email', 'correo', 'mail', 'emailAddress'],
  rol: ['rol', 'role', 'permisos', 'permissions', 'permission', 'permiso'],
  dominio: ['dominio', 'domain', 'tipo', 'type'],
  tag: ['tag', 'tagname', 'tagName', 'tag_name', 'nombre', 'name'],
  nodo: ['nodeName', 'name', 'nombre', 'networkNodeName', 'node_name'],
  interlock: ['interlock', 'interlocks', 'interbloqueo', 'interbloqueos']
};

// Define las funciones que Gemini puede llamar
const databaseFunctions = [
  {
    name: "buscarPorId",
    description: "Busca un documento por su ObjectId de MongoDB (_id). CRÍTICO: Usa esto SIEMPRE que tengas un ObjectId y necesites obtener la información del documento referenciado. Por ejemplo, si un NetworkNode tiene un campo 'asset' con un ObjectId, usa esta función para obtener el nombre del asset.",
    parameters: {
      type: "object",
      properties: {
        coleccion: {
          type: "string",
          description: "Nombre del modelo donde buscar",
          enum: ["User", "Asset", "System", "TagDescriptor", "NetworkNode", "Device", "DeviceType", "Connection", "Cabinet", "IOCard", "IOCardType", "Report", "Area", "NetworkNodeModel"]
        },
        id: {
          type: "string",
          description: "El ObjectId de MongoDB (24 caracteres hexadecimales, ejemplo: '612e7051eb108355cd30fc7f')"
        },
        camposRetornar: {
          type: "array",
          description: "Campos específicos a retornar (opcional, por defecto retorna todo)",
          items: {
            type: "string"
          }
        }
      },
      required: ["coleccion", "id"]
    }
  },
  {
    name: "busquedaInteligente",
    description: "Búsqueda inteligente que automáticamente detecta los campos correctos de la colección. Usa esto para búsquedas por nombre, descripción, o cualquier campo de texto cuando no estés 100% seguro del nombre exacto del campo.",
    parameters: {
      type: "object",
      properties: {
        coleccion: {
          type: "string",
          description: "Nombre del modelo",
          enum: ["User", "Asset", "System", "TagDescriptor", "NetworkNode", "Device", "DeviceType", "Connection", "Cabinet", "IOCard", "IOCardType", "Report", "Area", "NetworkNodeModel"]
        },
        tipoBusqueda: {
          type: "string",
          description: "Tipo de búsqueda",
          enum: ["nombre", "descripcion", "email", "rol", "dominio", "tag", "nodo", "custom"]
        },
        valor: {
          type: "string",
          description: "Valor a buscar"
        },
        campoCustom: {
          type: "string",
          description: "Solo si tipoBusqueda es 'custom'"
        },
        tipoCoindicencia: {
          type: "string",
          description: "Tipo de coincidencia",
          enum: ["exacta", "empieza", "contiene"]
        },
        limite: {
          type: "number",
          description: "Límite de resultados"
        }
      },
      required: ["coleccion", "tipoBusqueda", "valor"]
    }
  },
  {
    name: "contarInteligente",
    description: "Cuenta documentos usando búsqueda inteligente.",
    parameters: {
      type: "object",
      properties: {
        coleccion: {
          type: "string",
          enum: ["User", "Asset", "System", "TagDescriptor", "NetworkNode", "Device", "DeviceType", "Connection", "Cabinet", "IOCard", "IOCardType", "Report", "Area", "NetworkNodeModel"]
        },
        tipoBusqueda: {
          type: "string",
          enum: ["nombre", "descripcion", "email", "rol", "dominio", "tag", "nodo", "todos", "custom"]
        },
        valor: {
          type: "string"
        },
        campoCustom: {
          type: "string"
        },
        tipoCoindicencia: {
          type: "string",
          enum: ["exacta", "empieza", "contiene"]
        }
      },
      required: ["coleccion", "tipoBusqueda"]
    }
  },
  {
    name: "obtenerEjemplo",
    description: "Obtiene UN ejemplo de documento de una colección para ver su estructura y campos reales.",
    parameters: {
      type: "object",
      properties: {
        coleccion: {
          type: "string",
          enum: ["User", "Asset", "System", "TagDescriptor", "NetworkNode", "Device", "DeviceType", "Connection", "Cabinet", "IOCard", "IOCardType", "Report", "Area", "NetworkNodeModel"]
        }
      },
      required: ["coleccion"]
    }
  },
  {
    name: "buscarPorCampo",
    description: "Busca un documento por un campo específico (tagname, nodeName, nombre, email, etc). Usa esto cuando el usuario menciona un identificador específico.",
    parameters: {
      type: "object",
      properties: {
        coleccion: {
          type: "string",
          enum: ["User", "Asset", "System", "TagDescriptor", "NetworkNode", "Device", "DeviceType", "Connection", "Cabinet", "IOCard", "IOCardType", "Report", "Area", "NetworkNodeModel"]
        },
        campo: {
          type: "string",
          description: "Nombre exacto del campo"
        },
        valor: {
          type: "string",
          description: "Valor a buscar"
        },
        camposRetornar: {
          type: "array",
          items: {
            type: "string"
          }
        }
      },
      required: ["coleccion", "campo", "valor"]
    }
  },
  {
    name: "buscarDocumentos",
    description: "Busca documentos con filtros avanzados de MongoDB.",
    parameters: {
      type: "object",
      properties: {
        coleccion: {
          type: "string",
          enum: ["User", "Asset", "System", "TagDescriptor", "NetworkNode", "Device", "DeviceType", "Connection", "Cabinet", "IOCard", "IOCardType", "Report", "Area", "NetworkNodeModel"]
        },
        filtros: {
          type: "object"
        },
        limite: {
          type: "number"
        },
        campos: {
          type: "array",
          items: {
            type: "string"
          }
        },
        ordenar: {
          type: "object"
        }
      },
      required: ["coleccion"]
    }
  },
  {
    name: "contarDocumentos",
    description: "Cuenta documentos en una colección.",
    parameters: {
      type: "object",
      properties: {
        coleccion: {
          type: "string",
          enum: ["User", "Asset", "System", "TagDescriptor", "NetworkNode", "Device", "DeviceType", "Connection", "Cabinet", "IOCard", "IOCardType", "Report", "Area", "NetworkNodeModel"]
        },
        filtros: {
          type: "object"
        }
      },
      required: ["coleccion"]
    }
  }
];

// Ejecutor de funciones
async function ejecutarFuncion(nombreFuncion, parametros) {
  try {
    console.log(`[DB_FUNCTION] Ejecutando: ${nombreFuncion}`, JSON.stringify(parametros, null, 2));
    
    let resultado;
    switch(nombreFuncion) {
      case "buscarPorId":
        resultado = await buscarPorId(parametros);
        break;
      case "busquedaInteligente":
        resultado = await busquedaInteligente(parametros);
        break;
      case "contarInteligente":
        resultado = await contarInteligente(parametros);
        break;
      case "obtenerEjemplo":
        resultado = await obtenerEjemplo(parametros);
        break;
      case "buscarDocumentos":
        resultado = await buscarDocumentos(parametros);
        break;
      case "contarDocumentos":
        resultado = await contarDocumentos(parametros);
        break;
      case "buscarPorCampo":
        resultado = await buscarPorCampo(parametros);
        break;
      default:
        throw new Error(`Función ${nombreFuncion} no existe`);
    }
    
    console.log(`[DB_FUNCTION] Resultado de ${nombreFuncion}:`, JSON.stringify(resultado).substring(0, 200) + '...');
    return resultado;
    
  } catch (error) {
    console.error(`[DB_FUNCTION] Error en ${nombreFuncion}:`, error.message);
    return { 
      error: error.message,
      funcion: nombreFuncion,
      parametros 
    };
  }
}

// Implementación: Buscar por ObjectId
async function buscarPorId({ coleccion, id, camposRetornar = null }) {
  const modelo = mongoose.model(coleccion);
  
  console.log(`[DB] Buscando en ${coleccion} con _id = "${id}"`);
  
  // Validar que sea un ObjectId válido
  if (!mongoose.Types.ObjectId.isValid(id)) {
    return {
      coleccion,
      id,
      error: `"${id}" no es un ObjectId válido de MongoDB`,
      encontrado: false
    };
  }
  
  let query = modelo.findById(id);
  
  if (camposRetornar && camposRetornar.length > 0) {
    query = query.select(camposRetornar.join(' '));
  }
  
  const documento = await query.lean();
  
  console.log(`[DB] Documento ${documento ? 'encontrado' : 'NO encontrado'} en ${coleccion}`);
  
  return {
    coleccion,
    id,
    encontrado: !!documento,
    documento,
    mensaje: documento ? null : `No se encontró ningún documento con _id = "${id}"`
  };
}

// Función para detectar el campo correcto en un modelo
async function detectarCampo(coleccion, tipoBusqueda) {
  try {
    const modelo = mongoose.model(coleccion);
    const ejemplo = await modelo.findOne().lean();
    
    if (!ejemplo) {
      return null;
    }
    
    const camposDisponibles = Object.keys(ejemplo);
    const variantes = CAMPO_VARIANTES[tipoBusqueda] || [tipoBusqueda];
    
    for (const variante of variantes) {
      if (camposDisponibles.includes(variante)) {
        console.log(`[SMART_SEARCH] Campo detectado: ${variante} para tipo '${tipoBusqueda}'`);
        return variante;
      }
    }
    
    for (const variante of variantes) {
      const campoEncontrado = camposDisponibles.find(campo => 
        campo.toLowerCase() === variante.toLowerCase()
      );
      if (campoEncontrado) {
        console.log(`[SMART_SEARCH] Campo detectado (case-insensitive): ${campoEncontrado} para tipo '${tipoBusqueda}'`);
        return campoEncontrado;
      }
    }
    
    console.log(`[SMART_SEARCH] No se encontró campo para '${tipoBusqueda}' en ${coleccion}. Campos disponibles:`, camposDisponibles);
    return null;
  } catch (error) {
    console.error(`[SMART_SEARCH] Error detectando campo:`, error.message);
    return null;
  }
}

// Implementación: Búsqueda inteligente
async function busquedaInteligente({ coleccion, tipoBusqueda, valor, campoCustom = null, tipoCoindicencia = 'exacta', limite = 20 }) {
  const limiteSeguro = Math.min(limite, 100);
  const modelo = mongoose.model(coleccion);
  
  let campo;
  if (tipoBusqueda === 'custom' && campoCustom) {
    campo = campoCustom;
  } else {
    campo = await detectarCampo(coleccion, tipoBusqueda);
  }
  
  if (!campo) {
    return {
      error: `No se pudo detectar el campo para '${tipoBusqueda}' en la colección ${coleccion}`,
      coleccion,
      tipoBusqueda,
      sugerencia: "Usa obtenerEjemplo para ver los campos disponibles"
    };
  }
  
  let filtro;
  if (tipoCoindicencia === 'exacta') {
    filtro = { [campo]: valor };
  } else if (tipoCoindicencia === 'empieza') {
    filtro = { [campo]: { $regex: `^${valor}`, $options: 'i' } };
  } else if (tipoCoindicencia === 'contiene') {
    filtro = { [campo]: { $regex: valor, $options: 'i' } };
  }
  
  console.log(`[SMART_SEARCH] Buscando en ${coleccion}.${campo} con filtro:`, filtro);
  
  const documentos = await modelo
    .find(filtro)
    .limit(limiteSeguro)
    .lean();
  
  console.log(`[SMART_SEARCH] Encontrados ${documentos.length} documentos`);
  
  return {
    coleccion,
    tipoBusqueda,
    campoUtilizado: campo,
    filtro,
    total: documentos.length,
    documentos,
    mensaje: documentos.length === 0 ? `No se encontraron resultados para ${campo} = "${valor}"` : null
  };
}

// Implementación: Contar inteligente
async function contarInteligente({ coleccion, tipoBusqueda, valor = null, campoCustom = null, tipoCoindicencia = 'exacta' }) {
  const modelo = mongoose.model(coleccion);
  
  if (tipoBusqueda === 'todos') {
    const total = await modelo.countDocuments({});
    return {
      coleccion,
      tipoBusqueda: 'todos',
      total,
      mensaje: `Hay ${total} documento${total !== 1 ? 's' : ''} en total`
    };
  }
  
  let campo;
  if (tipoBusqueda === 'custom' && campoCustom) {
    campo = campoCustom;
  } else {
    campo = await detectarCampo(coleccion, tipoBusqueda);
  }
  
  if (!campo) {
    return {
      error: `No se pudo detectar el campo para '${tipoBusqueda}' en la colección ${coleccion}`,
      coleccion,
      tipoBusqueda
    };
  }
  
  let filtro;
  if (!valor) {
    filtro = { [campo]: { $exists: true, $ne: null, $ne: '' } };
  } else if (tipoCoindicencia === 'exacta') {
    filtro = { [campo]: valor };
  } else if (tipoCoindicencia === 'empieza') {
    filtro = { [campo]: { $regex: `^${valor}`, $options: 'i' } };
  } else if (tipoCoindicencia === 'contiene') {
    filtro = { [campo]: { $regex: valor, $options: 'i' } };
  }
  
  const total = await modelo.countDocuments(filtro);
  
  return {
    coleccion,
    tipoBusqueda,
    campoUtilizado: campo,
    filtro,
    total,
    mensaje: `Se encontraron ${total} documento${total !== 1 ? 's' : ''}`
  };
}

// Implementación: Obtener ejemplo
async function obtenerEjemplo({ coleccion }) {
  const modelo = mongoose.model(coleccion);
  const documento = await modelo.findOne().lean();
  
  if (!documento) {
    return {
      coleccion,
      campos: [],
      mensaje: `No hay documentos en la colección ${coleccion}`
    };
  }
  
  const campos = Object.keys(documento);
  
  return {
    coleccion,
    campos,
    ejemplo: documento,
    mensaje: `La colección ${coleccion} tiene ${campos.length} campos`
  };
}

// Implementación: Buscar documentos
async function buscarDocumentos({ coleccion, filtros = {}, limite = 20, campos = null, ordenar = null }) {
  const limiteSeguro = Math.min(limite, 100);
  const modelo = mongoose.model(coleccion);
  
  let query = modelo.find(filtros);
  
  if (campos && campos.length > 0) {
    query = query.select(campos.join(' '));
  }
  
  if (ordenar) {
    query = query.sort(ordenar);
  }
  
  const documentos = await query.limit(limiteSeguro).lean();
  
  return {
    coleccion,
    filtros,
    total: documentos.length,
    documentos,
    mensaje: documentos.length === 0 ? 'No se encontraron documentos con esos filtros' : null
  };
}

// Implementación: Contar documentos
async function contarDocumentos({ coleccion, filtros = {} }) {
  const modelo = mongoose.model(coleccion);
  const total = await modelo.countDocuments(filtros);
  
  return {
    coleccion,
    filtros,
    total,
    mensaje: `Se encontraron ${total} documento${total !== 1 ? 's' : ''}`
  };
}

// Implementación: Buscar por campo específico
async function buscarPorCampo({ coleccion, campo, valor, camposRetornar = null }) {
  const modelo = mongoose.model(coleccion);
  
  let query = modelo.findOne({ [campo]: valor });
  
  if (camposRetornar && camposRetornar.length > 0) {
    query = query.select(camposRetornar.join(' '));
  }
  
  const documento = await query.lean();
  
  return {
    coleccion,
    campo,
    valor,
    encontrado: !!documento,
    documento,
    mensaje: documento ? null : `No se encontró ningún documento con ${campo} = "${valor}"`
  };
}

export {
  databaseFunctions,
  ejecutarFuncion
};