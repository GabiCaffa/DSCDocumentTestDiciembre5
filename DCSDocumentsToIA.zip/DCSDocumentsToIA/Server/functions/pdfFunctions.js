//functions/pdfFunctions.js

import fs from 'fs/promises';
import path from 'path';
import PDFParser from 'pdf2json';
import { fileURLToPath } from 'url';

// __dirname para ES Modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Carpeta donde están los PDFs
const PDF_DIRECTORY = path.join(__dirname, '../documents/pdfs');

export const pdfFunctions = [
  {
    name: "listarPDFs",
    description: "Lista todos los PDFs disponibles en el sistema para que el usuario sepa qué documentos puede consultar",
    parameters: {
      type: "object",
      properties: {},
      required: []
    }
  },
  {
    name: "leerPDF",
    description: "Lee y extrae el contenido completo de un PDF específico.",
    parameters: {
      type: "object",
      properties: {
        nombreArchivo: {
          type: "string",
          description: "Nombre exacto del archivo PDF (con extensión .pdf)"
        }
      },
      required: ["nombreArchivo"]
    }
  },
  {
    name: "buscarEnPDFs",
    description: "Busca un texto específico en todos los PDFs disponibles.",
    parameters: {
      type: "object",
      properties: {
        textoBusqueda: {
          type: "string",
          description: "Texto a buscar en los PDFs"
        }
      },
      required: ["textoBusqueda"]
    }
  }
];

function parsePDFToText(pdfData) {
  let text = '';
  if (pdfData.Pages) {
    pdfData.Pages.forEach(page => {
      if (page.Texts) {
        page.Texts.forEach(textItem => {
          if (textItem.R) {
            textItem.R.forEach(run => {
              if (run.T) {
                text += decodeURIComponent(run.T) + ' ';
              }
            });
          }
        });
      }
      text += '\n';
    });
  }
  return text;
}

function parsePDF(rutaArchivo) {
  return new Promise((resolve, reject) => {
    const pdfParser = new PDFParser();

    pdfParser.on('pdfParser_dataError', errData => {
      reject(new Error(errData.parserError));
    });

    pdfParser.on('pdfParser_dataReady', pdfData => {
      const texto = parsePDFToText(pdfData);
      resolve({
        texto,
        paginas: pdfData.Pages?.length ?? 0,
        metadata: pdfData.Meta || {}
      });
    });

    pdfParser.loadPDF(rutaArchivo);
  });
}

export async function ejecutarFuncionPDF(nombreFuncion, parametros) {
  try {
    console.log(`[PDF_FUNCTION] Ejecutando: ${nombreFuncion}`, JSON.stringify(parametros, null, 2));

    let resultado;

    switch (nombreFuncion) {
      case "listarPDFs":
        resultado = await listarPDFs();
        break;
      case "leerPDF":
        resultado = await leerPDF(parametros);
        break;
      case "buscarEnPDFs":
        resultado = await buscarEnPDFs(parametros);
        break;
      default:
        throw new Error(`Función ${nombreFuncion} no existe`);
    }

    console.log(`[PDF_FUNCTION] Resultado de ${nombreFuncion}:`, JSON.stringify(resultado).slice(0, 200) + '...');
    return resultado;

  } catch (error) {
    console.error(`[PDF_FUNCTION] Error en ${nombreFuncion}:`, error.message);
    return {
      error: error.message,
      funcion: nombreFuncion,
      parametros
    };
  }
}

async function listarPDFs() {
  try {
    const archivos = await fs.readdir(PDF_DIRECTORY);
    const pdfs = archivos.filter(a => a.toLowerCase().endsWith('.pdf'));

    return {
      total: pdfs.length,
      archivos: pdfs,
      mensaje:
        pdfs.length === 0
          ? 'No hay PDFs disponibles en el sistema'
          : `Hay ${pdfs.length} PDF${pdfs.length !== 1 ? 's' : ''} disponibles`
    };
  } catch (error) {
    return {
      error: `Error al listar PDFs: ${error.message}`,
      archivos: []
    };
  }
}

async function leerPDF({ nombreArchivo }) {
  try {
    const rutaCompleta = path.join(PDF_DIRECTORY, nombreArchivo);

    try {
      await fs.access(rutaCompleta);
    } catch {
      return {
        error: `El archivo "${nombreArchivo}" no existe`,
        encontrado: false
      };
    }

    const resultado = await parsePDF(rutaCompleta);

    return {
      nombreArchivo,
      encontrado: true,
      paginas: resultado.paginas,
      contenido: resultado.texto,
      metadata: resultado.metadata,
      mensaje: `PDF leído correctamente: ${resultado.paginas} página${resultado.paginas !== 1 ? 's' : ''}`
    };

  } catch (error) {
    return {
      error: `Error al leer el PDF: ${error.message}`,
      nombreArchivo,
      encontrado: false
    };
  }
}

async function buscarEnPDFs({ textoBusqueda }) {
  try {
    const archivos = await fs.readdir(PDF_DIRECTORY);
    const pdfs = archivos.filter(a => a.toLowerCase().endsWith('.pdf'));

    const resultados = [];

    for (const pdf of pdfs) {
      try {
        const rutaCompleta = path.join(PDF_DIRECTORY, pdf);
        const resultado = await parsePDF(rutaCompleta);

        const textoLower = resultado.texto.toLowerCase();
        const busquedaLower = textoBusqueda.toLowerCase();

        if (textoLower.includes(busquedaLower)) {
          const lineas = resultado.texto.split('\n').filter(l => l.trim().length > 0);
          const coincidencias = lineas.filter(l => l.toLowerCase().includes(busquedaLower));

          resultados.push({
            archivo: pdf,
            coincidencias: coincidencias.length,
            fragmentos: coincidencias.slice(0, 5)
          });
        }

      } catch (error) {
        console.error(`Error al procesar ${pdf}:`, error.message);
      }
    }

    return {
      textoBusqueda,
      totalArchivosRevisados: pdfs.length,
      archivosConCoincidencias: resultados.length,
      resultados,
      mensaje:
        resultados.length === 0
          ? `No se encontró "${textoBusqueda}" en ningún PDF`
          : `Se encontró "${textoBusqueda}" en ${resultados.length} PDF${resultados.length !== 1 ? 's' : ''}`
    };

  } catch (error) {
    return {
      error: `Error al buscar en PDFs: ${error.message}`,
      resultados: []
    };
  }
}
