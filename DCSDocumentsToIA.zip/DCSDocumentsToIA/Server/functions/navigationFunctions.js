const navigationFunctions = [
  {
    name: "navegarSeccion",
    description: `Navega a una sección específica del sistema SOLO cuando el usuario explícitamente pide ir a algún lugar.
    
    Ejemplos de pedidos VÁLIDOS que deben usar esta función:
    - "llevame a usuarios"
    - "ir a reportes" 
    - "quiero ver los assets"
    - "andá a network"
    - "mostrame los dispositivos"
    - "ir a ver las conexiones"
    - "llevame al menú"
    
    Ejemplos que NO deben usar esta función:
    - "¿cómo funciona X?" (solo explicar)
    - "¿qué puedo hacer en Y?" (solo informar)
    - "cuéntame sobre Z" (solo describir)
    
    IMPORTANTE: Esta función SOLO funciona si el usuario está autenticado.`,
    parameters: {
      type: "object",
      properties: {
        seccion: {
          type: "string",
          description: `Nombre de la sección a la que se desea navegar. Acepta tanto nombres técnicos como coloquiales:
          - "menu" o "menú" → Menú Principal
          - "assets" o "estructura" → Estructura MdP
          - "users" o "usuarios" → Usuarios
          - "tagsdescriptors", "descriptores", "tags" → Descriptores DCS
          - "network", "red" → Network DCS
          - "devices", "dispositivos" → Dispositivos DCS
          - "connections", "conexiones" → Conexiones
          - "architecture", "arquitectura" → Arquitectura Redes
          - "cabinets", "gabinetes" → Gabinetes
          - "iocards", "tarjetas" → Tarjetas I/O
          - "reports", "reportes" → Reportes`,
          enum: [
            "menu",
            "assets", 
            "users",
            "tagsdescriptors",
            "network",
            "devices",
            "connections",
            "architecture",
            "cabinets",
            "iocards",
            "reports"
          ]
        }
      },
      required: ["seccion"]
    }
  }
];

const routeMap = {
  menu: {
    path: "/menu",
    name: "Menú Principal",
    aliases: ["menú", "inicio", "home"]
  },
  assets: {
    path: "/assets",
    name: "Estructura MdP",
    aliases: ["estructura", "activos"]
  },
  users: {
    path: "/users",
    name: "Usuarios",
    aliases: ["usuarios", "user"]
  },
  tagsdescriptors: {
    path: "/tagsdescriptors",
    name: "Descriptores DCS",
    aliases: ["descriptores", "tags", "descriptor"]
  },
  network: {
    path: "/network",
    name: "Network DCS",
    aliases: ["red", "redes"]
  },
  devices: {
    path: "/devices",
    name: "Dispositivos DCS",
    aliases: ["dispositivos", "device", "equipo", "equipos"]
  },
  connections: {
    path: "/connections",
    name: "Conexiones",
    aliases: ["conexiones", "connection"]
  },
  architecture: {
    path: "/architecture",
    name: "Arquitectura Redes",
    aliases: ["arquitectura", "arq"]
  },
  cabinets: {
    path: "/cabinets",
    name: "Gabinetes",
    aliases: ["gabinetes", "cabinet", "gabinete"]
  },
  iocards: {
    path: "/iocards",
    name: "Tarjetas I/O",
    aliases: ["tarjetas", "iocard", "io", "tarjeta"]
  },
  reports: {
    path: "/reports",
    name: "Reportes",
    aliases: ["reportes", "report", "reporte"]
  }
};

function normalizarSeccion(seccionInput) {
  const seccionLower = seccionInput.toLowerCase().trim();
  
  if (routeMap[seccionLower]) {
    return seccionLower;
  }
  
  for (const [key, value] of Object.entries(routeMap)) {
    if (value.aliases.includes(seccionLower)) {
      return key;
    }
  }
  
  return null;
}

async function ejecutarNavegacion(nombreFuncion, parametros, isAuthenticated = false) {
  try {
    if (!isAuthenticated) {
      return {
        error: "No estás autenticado",
        shouldNavigate: false,
        message: "Para navegar por el sistema necesitás iniciar sesión primero. ¿Te ayudo con el login?"
      };
    }
    
    switch(nombreFuncion) {
      case "navegarSeccion":
        return navegarSeccion(parametros);
      default:
        throw new Error(`Función de navegación ${nombreFuncion} no existe`);
    }
  } catch (error) {
    console.error(`Error ejecutando navegación ${nombreFuncion}:`, error);
    return { 
      error: error.message,
      shouldNavigate: false
    };
  }
}

function navegarSeccion({ seccion }) {
  const seccionNormalizada = normalizarSeccion(seccion);
  
  if (!seccionNormalizada) {
    return {
      error: `No encontré la sección "${seccion}"`,
      shouldNavigate: false,
      message: `No pude encontrar la sección "${seccion}". Las secciones disponibles son: ${Object.values(routeMap).map(r => r.name).join(', ')}`
    };
  }
  
  const route = routeMap[seccionNormalizada];
  
  return {
    shouldNavigate: true,
    navigateTo: route.path,
    sectionName: route.name,
    message: `Perfecto! Te estoy llevando a ${route.name}...`
  };
}

export {
  navigationFunctions,
  ejecutarNavegacion,
  routeMap,
  normalizarSeccion
};