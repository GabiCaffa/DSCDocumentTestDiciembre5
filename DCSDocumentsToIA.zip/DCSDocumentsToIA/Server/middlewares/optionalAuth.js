import jwt from "jsonwebtoken";

// Middleware que intenta autenticar pero NO bloquea si falla
export default function optionalAuth(req, res, next) {
  // Leer el token del header
  const token = req.header("x-auth-token");

  // Si no hay token, continuar sin usuario
  if (!token) {
    req.user = null;
    return next();
  }

  // Si hay token, intentar validarlo
  try {
    const cifrado = jwt.verify(token, process.env.CERTIFICADO);
    req.user = cifrado.user;
    next();
  } catch (error) {
    console.log("Token inválido en optionalAuth:", error.message);
    req.user = null;
    next();
  }
}
